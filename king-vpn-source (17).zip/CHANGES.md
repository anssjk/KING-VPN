# تغییرات — رفع خطای build (v1.9.2)

## خطای دیده‌شده
در GitHub Actions، مرحله‌ی **Build the APK** پس از حدود ۸ دقیقه:
```
BUILD FAILED in 8m 15s
Error: Process completed with exit code 1.
```

## علت دقیق
`hev-socks5-tunnel.aar` (کتابخانه‌ی نیتیو پل TUN→SOCKS5) در manifest خود
`minSdkVersion=29` اعلام می‌کند:
```
hev.aar → <uses-sdk android:minSdkVersion="29"/>
```
اما پیش‌فرض Expo SDK 57 برای پروژه `minSdkVersion=24` است. تضاد «۲۴ در برابر ۲۹»
در مرحله‌ی **manifest merger** باعث توقف بیلد می‌شود.

## اصلاح
`minSdkVersion` پروژه روی ۲۹ تنظیم شد:

`app.json` → `plugins`:
```json
[
  "expo-build-properties",
  { "android": { "minSdkVersion": 29 } }
]
```
و `expo-build-properties@~57.0.23` به `package.json` اضافه شد.

## چرا دیگر تکرار نمی‌شود
`expo-build-properties` مقدار `android.minSdkVersion=29` را در
`android/gradle.properties` می‌نویسد؛ اکپو آن را به `rootProject.ext.minSdkVersion`
می‌دهد و پلاگین Gradle اکپو روی همه‌ی ماژول‌های نیتیو اعمال می‌کند. پس عدد ۲۴
دیگر در زنجیره نیست و تضاد manifest از بین می‌رود.

## فایل‌های تغییریافته
- `app.json` — پلاگین `expo-build-properties` با `minSdkVersion: 29`؛ نسخه ۱.۹.۲، versionCode 13
- `package.json` — افزودن `expo-build-properties`
- `package-lock.json` — به‌روزرسانی lockfile

## تست‌شده در همین محیط
- `npm ci` → ۵۸۸ پکیج، بدون خطا
- `npx expo config --type prebuild` → بدون خطا، پلاگین حاضر
- `npx expo export --platform android` → باندل JS کامپایل شد (exit 0)

## تست‌نشده (سیاست sandbox)
`expo prebuild` و `gradlew` در این محیط اجرا نمی‌شوند؛ مرحله‌ی Gradle اینجا
«تست‌شده» حساب نمی‌شود.
