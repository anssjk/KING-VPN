# KING VPN panel — Railway deployment

This folder is the backend the app talks to. It issues tokens and publishes the server
groups the app shows. It is a plain Node/Express service with a JSON file for storage, so
it deploys to Railway with no database.

## Deploy

1. Push this repository to GitHub (or run `railway up` from this folder).
2. On [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**.
3. Set the service's **Root Directory** to `server`.
4. Railway detects Node and runs `npm start` (see `package.json`).
5. Add a **Volume** mounted at `/data` (so tokens and servers survive a redeploy).
6. Set these variables on the service:

   | Variable    | Value                                   |
   |-------------|-----------------------------------------|
   | `DATA_DIR`  | `/data`                                 |
   | `ADMIN_KEY` | a long random string you choose         |

   `PORT` is provided by Railway automatically.

7. Open the service's public URL. `/health` should return `{"ok":true,...}`.

## Use

- **`/token`** — create a token by hand. This is the page the app's
  “Open the token page on the panel” button opens.
- **`/admin`** — add and remove servers. Paste a `vless://`, `vmess://`, `trojan://` or
  `ss://` link, pick its group, and save. The **first** server of a group (lowest `order`)
  is what “Fastest country” and that group's button connect to.
- **`/api/servers`** — what the app reads, with the caller's token in `x-api-token`.

## Point the app at it

In the app's build environment set:

```
EXPO_PUBLIC_API_URL=https://<your-service>.up.railway.app
```

Then rebuild the APK. The app asks the panel for a token on first launch and stores it on
the device; the user never types one.

## API

| Method | Path                     | Auth        | Purpose                          |
|--------|--------------------------|-------------|----------------------------------|
| GET    | `/health`                | —           | liveness                         |
| POST   | `/api/token`             | —           | issue a token                    |
| GET    | `/api/token/:token`      | —           | is this token valid?             |
| GET    | `/api/servers`           | token       | the server list, best first      |
| GET    | `/api/admin/servers`     | admin key   | full list with ids               |
| POST   | `/api/admin/servers`     | admin key   | add a server                     |
| DELETE | `/api/admin/servers/:id` | admin key   | remove a server                  |
