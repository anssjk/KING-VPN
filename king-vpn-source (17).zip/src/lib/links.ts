/**
 * Public links shown in the app. These are the only places the app sends the user to,
 * besides the panel itself.
 */
export const TELEGRAM_CHANNEL = 'https://t.me/kingpannel758';
export const TELEGRAM_OWNER = 'https://t.me/LoadingTURK';
export const OWNER_HANDLE = '@LoadingTURK';
export const CHANNEL_HANDLE = '@kingpannel758';
