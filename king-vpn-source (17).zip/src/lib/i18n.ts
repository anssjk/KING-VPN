/**
 * Bilingual dictionary (English / Persian). Every user-visible string in the app comes
 * from here, so switching the language in the Settings tab changes the whole app at once.
 */
export type Lang = 'en' | 'fa';

export const strings = {
  en: {
    appName: 'KING VPN',
    tagline: 'Fast, private, effortless.',

    // Tabs
    tabHome: 'Home',
    tabSettings: 'Settings',
    tabThird: 'Panel',

    // Home
    fastestCountry: 'Fastest country',
    fastestCountryHint: 'One tap — the panel picks the best server for you',
    groups: 'Server groups',
    groupsHint: 'Pick a group to connect through',
    groupTrojan: 'Trojan',
    groupVless: 'VLESS',
    groupVmess: 'VMess',
    groupVlessHu: 'VLESS HU',
    connecting: 'Connecting…',
    connected: 'Connected',
    disconnected: 'Disconnected',
    disconnect: 'Disconnect',
    tapToConnect: 'Tap to connect',
    secureSession: 'Secure session active',
    activeServer: 'Active server',
    noServers: 'No servers yet',
    noServersHint: 'Pull down to refresh, or check the panel.',
    refresh: 'Refresh',
    loading: 'Loading…',
    errorTitle: 'Something went wrong',
    tunnelUnavailable:
      'This build has no native VPN module. Install a development or release APK — Expo Go cannot create a VPN.',
    vpnPermissionNeeded: 'Tap to allow the VPN connection',
    received: 'Received',
    sent: 'Sent',
    handshake: 'Handshake',
    handshakeOk: 'OK',
    handshakePending: 'Pending',

    // Servers page
    serversTitle: 'Servers',
    serversSubtitle: 'Every server the panel publishes, grouped by protocol',
    serverCount: '{n} servers',
    connect: 'Connect',
    selected: 'Active',
    brokenTitle: 'Unreadable entries',
    brokenHint: 'The panel sent these, but they could not be parsed',

    // Settings
    settingsTitle: 'Settings',
    settingsSubtitle: 'Channel, owner and appearance',
    channel: 'Channel',
    channelHint: 'Updates, configs and announcements',
    owner: 'Owner',
    ownerHint: 'Questions, feedback and support',
    preferences: 'Preferences',
    language: 'Language',
    theme: 'Theme',
    dark: 'Black',
    light: 'White',
    account: 'Account',
    token: 'Panel token',
    tokenHint: 'Issued by the panel and stored on this device only',
    tokenMissing: 'No token yet',
    getToken: 'Get a token',
    newToken: 'Request a new token',
    tokenPage: 'Open the token page on the panel',
    tokenPageHint: 'Create a token on the Railway panel',
    version: 'Version',
    open: 'Open',
    tapToOpen: 'Tap to open',
    copy: 'Copy',
    copied: 'Copied',
  },
  fa: {
    appName: 'KING VPN',
    tagline: 'سریع، خصوصی، ساده.',

    // Tabs
    tabHome: 'خانه',
    tabSettings: 'تنظیمات',
    tabThird: 'پنل',

    // Home
    fastestCountry: 'سریع‌ترین کشور',
    fastestCountryHint: 'با یک لمس — پنل بهترین سرور را برایتان انتخاب می‌کند',
    groups: 'گروه‌های سرور',
    groupsHint: 'یک گروه را برای اتصال انتخاب کنید',
    groupTrojan: 'تورجان',
    groupVless: 'ویلس',
    groupVmess: 'ویمس',
    groupVlessHu: 'ویلس HU',
    connecting: 'در حال اتصال…',
    connected: 'متصل',
    disconnected: 'قطع',
    disconnect: 'قطع اتصال',
    tapToConnect: 'برای اتصال بزنید',
    secureSession: 'نشست امن فعال است',
    activeServer: 'سرور فعال',
    noServers: 'هنوز سروری نیست',
    noServersHint: 'برای به‌روزرسانی پایین بکشید یا پنل را بررسی کنید.',
    refresh: 'به‌روزرسانی',
    loading: 'در حال بارگذاری…',
    errorTitle: 'مشکلی پیش آمد',
    tunnelUnavailable:
      'این نسخه ماژول بومی VPN ندارد. نسخه‌ی توسعه یا APK نهایی را نصب کنید — Expo Go نمی‌تواند VPN بسازد.',
    vpnPermissionNeeded: 'برای اجازه‌ی اتصال VPN بزنید',
    received: 'دریافت',
    sent: 'ارسال',
    handshake: 'دست‌دهی',
    handshakeOk: 'برقرار',
    handshakePending: 'در انتظار',

    // Servers page
    serversTitle: 'سرورها',
    serversSubtitle: 'همه‌ی سرورهایی که پنل منتشر می‌کند، گروه‌بندی‌شده بر اساس پروتکل',
    serverCount: '{n} سرور',
    connect: 'اتصال',
    selected: 'فعال',
    brokenTitle: 'موارد ناخوانا',
    brokenHint: 'پنل این‌ها را فرستاد، اما قابل خواندن نبودند',

    // Settings
    settingsTitle: 'تنظیمات',
    settingsSubtitle: 'کانال، مالک و ظاهر',
    channel: 'کانال',
    channelHint: 'به‌روزرسانی‌ها، کانفیگ‌ها و اطلاعیه‌ها',
    owner: 'مالک',
    ownerHint: 'پرسش، بازخورد و پشتیبانی',
    preferences: 'تنظیمات',
    language: 'زبان',
    theme: 'تم',
    dark: 'سیاه',
    light: 'سفید',
    account: 'حساب',
    token: 'توکن پنل',
    tokenHint: 'توسط پنل صادر می‌شود و فقط روی همین دستگاه ذخیره می‌شود',
    tokenMissing: 'هنوز توکنی نیست',
    getToken: 'دریافت توکن',
    newToken: 'درخواست توکن جدید',
    tokenPage: 'باز کردن صفحه‌ی توکن در پنل',
    tokenPageHint: 'ساخت توکن روی پنل Railway',
    version: 'ورژن',
    open: 'بازکردن',
    tapToOpen: 'برای بازکردن بزنید',
    copy: 'کپی',
    copied: 'کپی شد',
  },
} as const;

export type StringKey = keyof typeof strings.en;

export function translate(lang: Lang, key: StringKey): string {
  return strings[lang][key] ?? strings.en[key];
}
