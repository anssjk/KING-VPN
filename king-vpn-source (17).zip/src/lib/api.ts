/**
 * Client for the KING VPN panel backend (deployed on Railway).
 *
 * The app no longer asks the user for a token. It asks the panel for one, keeps it on the
 * device, and uses it for every later call. The panel is the only place a token is
 * created, so the "create token" link in the app points at the panel's own page.
 *
 * Nothing here invents data: if the panel is unreachable the call throws and the UI says
 * so, instead of showing a fake list.
 */
import { API_URL, hasBackend } from '@/lib/config';

/** One server as the panel stores it: a group plus the share link it was added from. */
export type RemoteServer = {
  id: string;
  group: ServerGroup;
  link: string;
  name?: string;
};

export type ServerGroup = 'trojan' | 'vless' | 'vmess' | 'vless-hu';

export const SERVER_GROUPS: ServerGroup[] = ['trojan', 'vless', 'vmess', 'vless-hu'];

export type TokenResponse = {
  token: string;
  createdAt: number;
};

/** The panel's base URL, without a trailing slash. */
export function apiBase(): string {
  return API_URL;
}

/** True when the build was given a panel address. */
export function hasPanel(): boolean {
  return hasBackend;
}

/** The page on the panel where a token is created. */
export function tokenPageUrl(): string {
  return hasBackend ? `${API_URL}/token` : '';
}

async function request<T>(path: string, init: RequestInit = {}, token?: string | null): Promise<T> {
  if (!hasBackend) {
    throw new Error('No panel address is configured in this build.');
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(`${API_URL}${path}`, {
      ...init,
      signal: controller.signal,
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { 'x-api-token': token } : {}),
        ...(init.headers ?? {}),
      },
    });
    const text = await res.text();
    const body = text ? (JSON.parse(text) as unknown) : null;
    if (!res.ok) {
      const message =
        body && typeof body === 'object' && 'error' in body
          ? String((body as { error: unknown }).error)
          : `The panel answered ${res.status}.`;
      throw new Error(message);
    }
    return body as T;
  } finally {
    clearTimeout(timer);
  }
}

/** Ask the panel for a token. The panel creates it; the app only stores it. */
export async function createToken(label?: string): Promise<TokenResponse> {
  return request<TokenResponse>('/api/token', {
    method: 'POST',
    body: JSON.stringify({ label: label ?? 'king-vpn-app' }),
  });
}

/** Check that a stored token is still accepted by the panel. */
export async function verifyToken(token: string): Promise<boolean> {
  try {
    const res = await request<{ valid: boolean }>(`/api/token/${encodeURIComponent(token)}`);
    return Boolean(res.valid);
  } catch {
    return false;
  }
}

/** The servers the panel publishes for this token. */
export async function fetchServers(token: string): Promise<RemoteServer[]> {
  const res = await request<{ servers: RemoteServer[] }>('/api/servers', {}, token);
  return Array.isArray(res.servers) ? res.servers : [];
}
