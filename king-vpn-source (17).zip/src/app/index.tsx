import { Redirect } from 'expo-router';

/**
 * Entry point: straight into the three-tab panel.
 *
 * There is no onboarding and no permission gate any more — the token is issued by the
 * panel, and Android asks for the VPN permission itself at connect time.
 */
export default function Index() {
  return <Redirect href="/(tabs)" />;
}
