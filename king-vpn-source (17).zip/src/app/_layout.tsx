import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';

import { View } from 'react-native';
import * as Notifications from 'expo-notifications';

import { AppProvider } from '@/lib/app-context';
import { SettingsProvider, useSettings } from '@/lib/settings-context';
import { useColors } from '@/constants/theme';

/**
 * Show notifications even while the app is in the foreground, so a dropped tunnel is
 * never silent. Registered once at module scope, which is where expo-notifications
 * expects the handler.
 */
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

function ThemedStack() {
  const { theme } = useSettings();
  const colors = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: 'transparent' },
          animation: 'fade',
        }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="+not-found" options={{ headerShown: true, title: 'Not found' }} />
      </Stack>
      <StatusBar style={theme === 'dark' ? 'light' : 'dark'} />
    </View>
  );
}

export default function RootLayout() {
  return (
    <SettingsProvider>
      <AppProvider>
        <ThemedStack />
      </AppProvider>
    </SettingsProvider>
  );
}
