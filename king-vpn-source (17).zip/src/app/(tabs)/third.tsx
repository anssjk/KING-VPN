import { HomePanel } from '@/components/home-panel';

/**
 * Page 3 — the same panel as page 1 (fastest country + the four group buttons).
 *
 * It is a separate route so the tab bar can show it as its own page, but it renders the
 * exact same component, so the two pages can never drift apart.
 */
export default function ThirdScreen() {
  return <HomePanel />;
}
