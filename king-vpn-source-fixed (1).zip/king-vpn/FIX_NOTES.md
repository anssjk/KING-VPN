# گزارش رفع خطای بیلد APK — KING VPN

## خطای اصلی (علت شکست بیلد)

بیلد در مرحله‌ی Gradle با خطای **manifest merger** شکست می‌خورد:

```
Manifest merger failed : uses-sdk:minSdkVersion 24 cannot be smaller than
version 29 declared in library [.../hev.aar]
```

### چرا؟

- کتابخانه‌ی `hev.aar` (hev-socks5-tunnel 2.20.0) در `AndroidManifest.xml` خودش
  `minSdkVersion="29"` اعلام می‌کند.
- پروژه هیچ‌جا `minSdkVersion` را تعیین نکرده بود، پس Expo/React Native مقدار
  پیش‌فرض **24** را می‌گذاشت (از `node_modules/react-native/gradle/libs.versions.toml`).
- Android اجازه نمی‌دهد اپ با minSdk پایین‌تر از یک کتابخانه‌ی وابسته بیلد شود →
  بیلد متوقف می‌شد.

## اصلاحات انجام‌شده

### ۱) `app.json` — بالا بردن minSdk به 29

پلاگین `expo-build-properties` اضافه شد تا `android.minSdkVersion = 29` در
`gradle.properties` نوشته شود و کل زنجیره (اپ + همه‌ی ماژول‌ها) با 29 بیلد شود:

```json
"plugins": [
  "expo-router",
  ["expo-build-properties", { "android": { "minSdkVersion": 29 } }],
  ...
]
```

> این تنها راه درست است: `minSdkVersion` در `app.json` به‌تنهایی توسط Expo
> خوانده نمی‌شود؛ باید از طریق `expo-build-properties` اعمال شود.

### ۲) `package.json` — هم‌تراز کردن نسخه‌ها با Expo SDK 57

سه وابستگی با SDK 57 ناسازگار بودند (طبق `bundledNativeModules.json`):

| پکیج | قبل | بعد (درست برای SDK 57) |
|---|---|---|
| `expo-clipboard` | `~8.0.7` (نسخه‌ی SDK 52) | `~57.0.2` |
| `expo-constants` | `~57.0.23` | `~57.0.24` |
| `@expo/vector-icons` | `^15.1.1` | `^15.0.2` |

`expo-clipboard@8.x` برای هسته‌ی قدیمی ساخته شده بود و با `expo-modules-core@57`
هم‌خوان نبود؛ نسخه‌ی 57.x همان API را با هسته‌ی جدید ارائه می‌دهد.

همچنین `expo-build-properties@~57.0.23` به وابستگی‌ها اضافه شد.

### ۳) `package-lock.json` — بازتولید شد

ورک‌فلو با `npm ci` نصب می‌کند و `npm ci` اگر lockfile با `package.json`
هم‌خوان نباشد **با خطا متوقف می‌شود**. lockfile با نسخه‌های جدید بازتولید شد.

## بررسی‌هایی که انجام شد

- ✅ `npm ci --dry-run` → بدون خطا (lockfile هم‌خوان است)
- ✅ `npx tsc --noEmit` → بدون خطا (کد TypeScript سالم است)
- ✅ `npx expo config` → پلاگین‌ها درست resolve می‌شوند و `minSdkVersion: 29` خوانده می‌شود
- ✅ باندل JS اندروید با Metro ساخته شد (۱۳۹۱ ماژول، بدون خطا)
- ✅ SHA-256 هر دو کتابخانه‌ی بومی (`libv2ray.aar` و `hev.aar`) با مقادیر پین‌شده در
  ورک‌فلو مطابقت دارد
- ✅ کد Kotlin ماژول `king-vpn-tunnel` با API واقعی کتابخانه‌ها (WireGuard،
  libv2ray، hev، expo-modules-core 57) تطبیق داده شد — بدون ناسازگاری

## نکته‌ی مهم درباره‌ی ساخت APK

APK در این محیط ساخته نمی‌شود (هیچ گوشی/ابزار اندرویدی اینجا نیست). فایل
اصلاح‌شده را در GitHub آپلود کنید؛ ورک‌فلوی `.github/workflows/build-apk.yml`
خودش APK را می‌سازد و در بخش Releases قرار می‌دهد.

> **توجه:** با minSdk = 29، اپ روی اندروید ۱۰ (API 29) و بالاتر نصب می‌شود.
> اگر پشتیبانی از اندروید پایین‌تر لازم است، باید `hev.aar` با نسخه‌ای که
> minSdk پایین‌تری دارد جایگزین شود — که در این پروژه استفاده نشده است.
