# ساخت APK کینگ وی‌پی‌ان فقط با مرورگر گوشی

این راهنما برای کسی نوشته شده که **کامپیوتر ندارد** و می‌خواهد فقط با مرورگر گوشی، فایل
نصب‌شدنی (APK) اپ **KING VPN** را بسازد. همه‌ی کار روی سرورهای گیت‌هاب انجام می‌شود و
هیچ برنامه‌ای روی گوشی نصب نمی‌کنید.

**زمان لازم:** حدود ۱۵ تا ۲۵ دقیقه (بیشترش صف ساخت است).
**هزینه:** صفر. حساب رایگان گیت‌هاب کافی است.

**چیزهایی که لازم دارید:**
- یک گوشی با مرورگر (کروم یا سافاری)
- یک آدرس ایمیل
- فایل `king-vpn-source.zip` (همراه همین راهنما تحویل داده شده)

---

## قدم ۱ — ساخت حساب گیت‌هاب

1. در مرورگر گوشی به این آدرس بروید: **https://github.com/signup**
2. ایمیل خود را وارد کنید → **Continue**
3. یک رمز عبور بگذارید → **Continue**
4. یک نام کاربری انتخاب کنید (فقط حروف انگلیسی و خط تیره، مثلاً `ali-vpn`) → **Continue**
5. سؤال «آیا ایمیلت خبرنامه بخواهد؟» را با `n` رد کنید → **Continue**
6. یک پازل ساده حل کنید → **Submit**
7. کد ۶ رقمی که به ایمیلتان می‌آید را وارد کنید.

حساب شما آماده است. اگر پرسید پلن، **Free** را انتخاب کنید.

---

## قدم ۲ — ساخت ریپازیتوری (پوشه‌ی پروژه)

1. به **https://github.com/new** بروید.
2. در کادر **Repository name** بنویسید: `king-vpn`
3. گزینه‌ی **Public** را انتخاب کنید.
   > ریپازیتوری عمومی، دقیقه‌های ساخت رایگان بیشتری می‌دهد. کد اپ شما محرمانه نیست، پس
   > عمومی بودن مشکلی ندارد.
4. تیک **Add a README file** را بزنید.
5. دکمه‌ی سبز **Create repository** را بزنید.

حالا صفحه‌ی خالی پروژه‌ی شما باز می‌شود.

---

## قدم ۳ — آپلود سورس‌کد

1. در همان صفحه، دکمه‌ی **Add file** (بالا سمت راست) → **Upload files** را بزنید.
2. دکمه‌ی **choose your files** را بزنید و از گوشی فایل **`king-vpn-source.zip`** را انتخاب کنید.
3. کمی صبر کنید تا نام فایل در لیست ظاهر شود.
4. پایین صفحه دکمه‌ی سبز **Commit changes** را بزنید.

> ⚠️ فایل زیپ را **از حالت زیپ خارج نکنید**. خودِ گیت‌هاب موقع ساخت آن را باز می‌کند.

---

## قدم ۴ — اضافه‌کردن فایل تنظیمات ساخت

این فایل به گیت‌هاب می‌گوید چطور APK بسازد. یک بار برای همیشه اضافه می‌شود.

1. در صفحه‌ی پروژه، دکمه‌ی **Add file** → **Create new file** را بزنید.
2. در کادر بالای صفحه (جایی که نوشته *Name your file...*) **دقیقاً** این را تایپ کنید:

   ```
   .github/workflows/build-apk.yml
   ```

   > به محض تایپ اولین `/`، گیت‌هاب خودش پوشه می‌سازد. اگر اشتباه تایپ شد، صفحه را ببندید و
   > از نو با همین نام شروع کنید.

3. حالا کادر بزرگ متن را لمس کنید و محتوای فایل **`build-apk.yml`** را کامل داخلش بچسبانید.
   این فایل داخل زیپ، در مسیر `.github/workflows/build-apk.yml` هست. اگر باز کردن زیپ روی
   گوشی سخت است، همین فایل را جداگانه هم برایتان فرستاده‌ام.
4. پایین صفحه دکمه‌ی سبز **Commit changes** را بزنید.

---

## قدم ۵ — اجرای ساخت

1. بالای صفحه‌ی پروژه، تب **Actions** را بزنید.
2. اگر پیامی دیدید با متن *Workflows aren't being run on this forked repository* یا
   *I understand my workflows, go ahead and enable them*، دکمه‌ی تأیید را بزنید.
3. در ستون چپ روی **Build KING VPN APK** بزنید.
4. سمت راست، دکمه‌ی **Run workflow** را بزنید → شاخه‌ی `main` را انتخاب کنید →
   دوباره **Run workflow** را بزنید.
5. صفحه را رفرش کنید. یک ردیف با دایره‌ی **زرد** (در حال اجرا) ظاهر می‌شود. روی آن بزنید تا
   مراحل را زنده ببینید.

> اگر فایل زیپ را در قدم ۳ آپلود کرده باشید، ساخت معمولاً **خودش** هم شروع می‌شود و لازم
> نیست دکمه را بزنید. تب Actions را چک کنید.

**مراحل ساخت به ترتیب:** گرفتن سورس → پیدا کردن پوشه‌ی اپ → نصب Node و جاوا → نصب
وابستگی‌ها → ساخت پروژه‌ی اندروید → کامپایل APK → آپلود فایل.

وقتی دایره **سبز** شد، APK آماده است. اگر **قرمز** شد، به بخش «اگر ساخت خطا داد» بروید.

---

## قدم ۶ — دانلود فایل APK

دو راه هست؛ هر کدام راحت‌تر بود:

### راه اول — از Releases (ساده‌تر)

1. به صفحه‌ی اصلی پروژه برگردید (تب **Code**).
2. در ستون راست، بخش **Releases** را ببینید.
3. روی آخرین نسخه بزنید — مثلاً `KING VPN APK (build 3)`.
4. زیر **Assets** روی **`king-vpn.apk`** بزنید. دانلود شروع می‌شود.

### راه دوم — از تب Actions

1. تب **Actions** → روی آخرین اجرای سبز بزنید.
2. پایین صفحه، بخش **Artifacts** → روی **`king-vpn-apk`** بزنید.
3. یک فایل zip دانلود می‌شود. با برنامه‌ی فایل‌منیجر گوشی بازش کنید تا `king-vpn.apk`
   بیرون بیاید.

---

## قدم ۷ — نصب روی گوشی

1. فایل `king-vpn.apk` را در گوشی لمس کنید.
2. اندروید می‌گوید نصب از این منبع مجاز نیست → **Settings** را بزنید و برای همان مرورگر یا
   فایل‌منیجر، گزینه‌ی **Allow from this source** را روشن کنید.
3. برگردید و **Install** را بزنید.
4. اگر Play Protect هشدار داد، **Install anyway** را بزنید.
   > این APK با کلید خودتان امضا شده و در گوگل‌پلی ثبت نشده، پس این هشدار طبیعی است.
5. آیکون **KING VPN** روی صفحه‌ی اپ‌ها ظاهر می‌شود. بازش کنید.

---

## اگر ساخت خطا داد

| پیام خطا | معنی | راه حل |
|---|---|---|
| `No app.json at the root and no .zip file found` | فایل زیپ در پروژه نیست | قدم ۳ را دوباره انجام دهید |
| `The zip does not contain app.json` | فایل اشتباهی آپلود شده | همان `king-vpn-source.zip` را آپلود کنید |
| `npm ci` failed | فایل `package-lock.json` در زیپ نیست | زیپ را دوباره از همین تحویل بگیرید |
| Gradle failed / out of memory | خطای موقت ساخت | یک بار دیگر **Run workflow** را بزنید |
| `DeferredUtil.unpack` / `prepareInputParameterValue` | AGP موقع snapshot ورودی‌های task یک مقدار lazy (مسیر NDK) را باز کرد و شکست | در v1.9.3 رفع شد؛ مطمئن شوید همین zip را آپلود کرده‌اید |
| `NDK not configured` / `NDK not found` | نسخه‌ی NDK روی runner نصب نیست | در v1.9.3 step «Install the pinned Android NDK» خودش نصبش می‌کند |
| ساخت بیشتر از یک ساعت طول کشید | صف شلوغ گیت‌هاب | صبر کنید یا بعداً دوباره اجرا کنید |

اگر باز هم نشد، متن خطا (یا اسکرین‌شات صفحه‌ی خطا) را برایم بفرستید تا درستش کنم.

---

## نکته‌های مهم

- **محدودیت رایگان:** حساب رایگان گیت‌هاب ماهانه ۲۰۰۰ دقیقه ساخت دارد. هر ساخت این اپ
  حدود ۱۰ تا ۱۵ دقیقه مصرف می‌کند — یعنی حدود ۱۳۰ ساخت در ماه.
- **هر بار که سورس را عوض کنید** (مثلاً نسخه‌ی جدید اپ)، فقط زیپ جدید را آپلود کنید؛ ساخت
  خودش دوباره اجرا می‌شود.
- **کلید امضا:** APK ساخته‌شده با کلید پیش‌فرض دیباگ امضا می‌شود. برای انتشار در گوگل‌پلی
  باید کلید خودتان را بسازید — جزئیات در `BUILD_GUIDE.md` بخش «گوگل پلی».
- **آیفون:** این مسیر فقط APK اندروید می‌سازد. برای آیفون به عضویت Apple Developer نیاز
  دارید (بخش «آیفون» در `BUILD_GUIDE.md`).

---

## تغییرات این نسخه (v1.9.3) — رفع خطای build

### خطای دیده‌شده

در GitHub Actions، مرحله‌ی **Build the APK** بعد از حدود ۱۳ دقیقه شکست:

```
... 72 more
BUILD FAILED in 12m 31s
579 actionable tasks: 579 executed
Error: Process completed with exit code 1.
```

انتهای stack trace:

```
org.gradle.util.internal.DeferredUtil.unpack(DeferredUtil.java:57)
org.gradle.util.internal.DeferredUtil.unpackOrNull(DeferredUtil.java:49)
org.gradle.api.internal.tasks.properties.InputParameterUtils.prepareInputParameterValue(...)
```

### علت دقیق

این stack trace یعنی: **Gradle موقع «عکس‌برداری از ورودی‌های یک task» یک مقدار lazy را باز کرد و آن مقدار throw کرد یا null بود.** پیام اصلی AGP بیرون کادر عکس بود، پس ریشه را در سورس پیدا کردیم.

ریشه در `modules/king-vpn-tunnel/android/build.gradle` بود:

```groovy
defaultConfig {
  ndk {
    abiFilters 'arm64-v8a', 'armeabi-v7a', 'x86', 'x86_64'
  }
}
```

وقتی یک **ماژول library** بلوک `ndk { abiFilters ... }` دارد، AGP آن را «ماژول با کانفیگ نیتیو» حساب می‌کند و برایش task های نیتیو می‌سازد — از جمله `stripReleaseDebugSymbols` و `mergeReleaseNativeLibs`. این task ها مسیر NDK را **lazy** resolve می‌کنند، دقیقاً در همان لحظه‌ای که Gradle ورودی‌های task را snapshot می‌کند.

و این ماژول **هیچ کد نیتیو کامپایل نمی‌کند** — فقط دو `.so` آماده از دو AAR داخلش می‌آید. پس:

1. ماژول `ndkVersion` نداشت،
2. AGP به NDK پیش‌فرض خودش برمی‌گشت (نه نسخه‌ای که ریشه‌ی پروژه پین کرده: `27.1.12297006`)،
3. آن نسخه روی runner نصب نبود،
4. provider مربوط به NDK موقع snapshot ورودی‌ها throw کرد،
5. نتیجه: همان stack trace بی‌پیام `DeferredUtil.unpack` و `exit code 1`.

### اصلاح

### ۱) `modules/king-vpn-tunnel/android/build.gradle`

- **حذف بلوک `ndk { abiFilters ... }`** — این ماژول کد نیتیو ندارد، پس اصلاً به NDK نیاز ندارد. با حذف آن، AGP دیگر برای این ماژول task نیتیو نمی‌سازد و آن provider lazy هرگز اجرا نمی‌شود. (این ABI ها در APK از `reactNativeArchitectures` در ماژول app می‌آیند، نه از اینجا.)
- **پین کردن `ndkVersion` به نسخه‌ی ریشه‌ی پروژه**:
  ```groovy
  if (rootProject.ext.has('ndkVersion')) {
    ndkVersion rootProject.ext.ndkVersion
  }
  ```
  تا اگر AGP به هر دلیلی NDK خواست، همان نسخه‌ی پین‌شده‌ی RN/Expo را بخواهد، نه پیش‌فرض خودش.

### ۲) `.github/workflows/build-apk.yml`

یک step جدید **«Install the pinned Android NDK»** اضافه شد که نسخه‌ی `27.1.12297006` (همان نسخه‌ای که RN 0.86 / Expo SDK 57 پین می‌کند) را با `sdkmanager` نصب می‌کند. اگر از قبل نصب باشد، رد می‌شود. این کار کل این دسته خطا را از بین می‌برد.

### ۳) نسخه

`app.json` → `version: 1.9.3`، `versionCode: 14`؛ `package.json` → `1.9.3`.

### چرا این بار آن خطا تکرار نمی‌شود

- **محرک حذف شد:** بدون `abiFilters`، ماژول `king-vpn-tunnel` دیگر task نیتیو ندارد؛ پس `stripReleaseDebugSymbols` برای آن اجرا نمی‌شود و آن provider lazy که throw می‌کرد، هرگز صدا زده نمی‌شود.
- **اگر باز هم NDK لازم شد:** هم ماژول به نسخه‌ی ریشه پین شده، هم ورکفلو همان نسخه را از قبل نصب می‌کند. پس «NDK پیدا نشد» دیگر ممکن نیست.
- **خطا دیگر بلعیده نمی‌شود:** `--stacktrace` هست و هیچ `||` و fallback به debug وجود ندارد؛ اگر چیز دیگری بشکند، پیام واقعی AGP در لاگ دیده می‌شود.

### اصلاحات قبلی که دست‌نخورده ماندند

- بدون `|| ./gradlew assembleDebug` — فقط `./gradlew assembleRelease --no-daemon --stacktrace`
- `EXPO_PUBLIC_API_URL: ${{ secrets.EXPO_PUBLIC_API_URL }}` در step های prebuild و build
- بدون `--non-interactive` در `expo prebuild`
- `npm ci --no-audit --no-fund || npm install --no-audit --no-fund`
- step «Configure Gradle memory» با `org.gradle.jvmargs=-Xmx4g` در `android/gradle.properties`
- `minSdkVersion: 29` از طریق `expo-build-properties` در `app.json`

### تست‌شده در همین محیط

- `npm ci` → ۵۸۹ پکیج، بدون خطا
- `npx tsc --noEmit` → ۰ خطا
- `npx expo install --check` → `Dependencies are up to date`
- `npx expo config --type prebuild --json` → exit 0، `versionCode: 14`، هر ۴ پلاگین حاضر
- `npx expo export --platform android` → باندل JS کامپایل شد (exit 0)
- اعتبار YAML ورکفلو → ۱۳ step، همه‌ی ۵ شرط حفظ‌شده
- هش SHA-256 هر دو AAR → مطابق، هر ۴ ABI موجود

### تست‌نشده (سیاست sandbox)

`expo prebuild` و `gradlew` در این محیط اجرا نمی‌شوند (ساخت اپ موبایل مسدود است). پس مرحله‌ی Gradle «تست‌شده» حساب نمی‌شود.
