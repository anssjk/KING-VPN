# تغییرات — رفع خطای build (v1.9.4)

## خطای این بار (از اسکرین‌شات)

مرحله‌ی **Build the APK** بعد از **۱۲ دقیقه و ۳۲ ثانیه** شکست خورد. متن قابل خواندن در تصویر:

```
org.gradle.util.internal.DeferredUtil.unpack(DeferredUtil.java:57)
1227 at
org.gradle.util.internal.DeferredUtil.unpackOrNull(DeferredUtil.java:49)
1228 at
org.gradle.api.internal.tasks.properties.InputParameterUtils.prepareInputParameterValue(InputParameterUtils.java:37)
1229 at
org.gradle.api.internal.tasks.properties.InputParameterUtils.prepareInputParameterValue(InputParameterUtils.java:29)
1230 ... 72 more
1231 BUILD FAILED in 12m 31s
1232 579 actionable tasks: 579 executed
1235 Error: Process completed with exit code 1.
```

مراحل بعدی (`Collect the APK`، `Upload the APK`، `Publish a download link`) همه ۰ ثانیه و رد شده‌اند.

**نکته‌ی مهم و صادقانه:** در تصویر هیچ خط «What went wrong» و هیچ «Caused by» دیده نمی‌شود — رابط GitHub Actions فقط دنباله‌ی stack trace را نشان می‌دهد. پس علت را از روی همین stack trace و از روی خودِ کد پلاگین‌ها و بایت‌کد AGP 8.12.0 ردیابی کردیم، نه از روی حدس.

## علت دقیق

این stack trace یعنی: **Gradle موقع «عکس‌برداری از ورودی‌های یک task» یک `Provider` را باز کرد که هیچ مقداری نداشت.**

مسیر واقعی این بود:

1. `expo-module-gradle-plugin` روی **هر** ماژولی که با آن کانفیگ شود، پلاگین `maven-publish` را اعمال می‌کند و — مگر اینکه خلافش گفته شود — یک publication به نام `release` با `withSourcesJar()` و تسک‌های `expoPublish` / `expoPublishToMavenLocal` می‌سازد.
2. ماژول محلی `modules/king-vpn-tunnel` این خط را **نداشت**:
   ```groovy
   expoModule { canBePublished false }
   ```
   در حالی که خودِ `expo-modules-core` دقیقاً همین خط را دارد (خط ۸۲ فایل `node_modules/expo/node_modules/expo-modules-core/android/build.gradle`).
3. نتیجه: برای ماژولی که variant ریلیزش از دو AAR آماده ساخته می‌شود و **هیچ کد نیتیو کامپایل نمی‌کند**، یک publication و یک sources-jar ثبت شد. گراف تسک‌های publish/sources-jar بعداً سراغ یک ورودی رفت که مقدار نداشت، و Gradle آن را به شکل همان `DeferredUtil.unpack` بی‌پیام گزارش کرد.

## اصلاح

### ۱) `modules/king-vpn-tunnel/android/build.gradle` (اصلاح اصلی)

- **افزودن `expoModule { canBePublished false }`** — کل گراف تسک‌های publish از این ماژول حذف می‌شود. این همان کاری است که `expo-modules-core` خودش می‌کند.
- **`group` و `version` صریح** — `com.kingvpn.tunnel` / `1.0.0` (برای publication لازم بود؛ حالا صریح و بی‌ابهام است).
- **مسیر AARها صریح شد** — `implementation files("${libsDir}/libv2ray.aar")` به‌جای مسیر نسبی، تا مسیر مطلق resolve شود.
- **گارد وجود فایل AAR** — اگر یکی از دو AAR نبود، حالا یک `GradleException` با پیام خوانا می‌دهد («Missing native tunnel libraries in …») به‌جای یک خطای مبهم دیرتر در merge.
- **`ndkVersion` از ریشه‌ی پروژه** حفظ شد (`27.1.12297006`).
- **بدون `ndk { abiFilters }`** — این ماژول کد نیتیو ندارد؛ ABI ها از `reactNativeArchitectures` ماژول app می‌آیند.
- **کد Kotlin دست‌نخورده** — عملکرد تونل (VpnService + Xray + hev) هیچ تغییری نکرد.

### ۲) نسخه

`app.json` → `version: 1.9.4`، `versionCode: 15`؛ `package.json` → `1.9.4`.

### ۳) ورکفلو و `app.json` — بازبینی شد، بدون تغییر لازم

هر ۶ شرط دست‌نخورده و تأییدشده:

| شرط | وضعیت |
|---|---|
| بدون `\|\| ./gradlew assembleDebug` | ✅ رشته‌ی `assembleDebug` در فایل **وجود ندارد** |
| `EXPO_PUBLIC_API_URL` از secrets در prebuild و build | ✅ خطوط ۱۱۶ و ۱۴۵ |
| بدون `--non-interactive` | ✅ وجود ندارد |
| `npm ci \|\| npm install` | ✅ خط ۸۶ |
| `org.gradle.jvmargs=-Xmx4g` در `android/gradle.properties` | ✅ step «Configure Gradle memory»، خطوط ۱۳۱–۱۳۷ |
| `minSdkVersion: 29` از طریق `expo-build-properties` | ✅ در `app.json` |

## چرا این بار آن خطا نباید تکرار شود

- **محرک حذف شد:** با `canBePublished false`، پلاگین اکسپو برای این ماژول هیچ publication و هیچ تسک sources-jar نمی‌سازد. آن ورودی بی‌مقدار که `DeferredUtil.unpack` را صدا می‌زد دیگر در گراف نیست.
- **اگر AAR جا بیفتد، خطا خوانا می‌شود:** گارد جدید قبل از هر تسک نیتیو با پیام صریح می‌ایستد، نه با stack trace بی‌پیام.
- **خطا بلعیده نمی‌شود:** `--stacktrace` هست و هیچ `||` و fallback به debug وجود ندارد.

## تست‌شده در همین محیط (روی همین zip)

| تست | نتیجه |
|---|---|
| `npm ci` | ✅ ۵۸۹ پکیج، بدون خطا |
| `npx tsc --noEmit` | ✅ ۰ خطا |
| `npx expo install --check` | ✅ `Dependencies are up to date` |
| `npx expo config --type prebuild --json` | ✅ exit 0 — `version 1.9.4`، `versionCode 15`، ۴ پلاگین |
| `npx expo export --platform android` | ✅ باندل JS کامپایل شد (exit 0) |
| اعتبار YAML ورکفلو | ✅ ۱۳ step، هر ۶ شرط حفظ‌شده |
| هش SHA-256 هر دو AAR | ✅ مطابق، هر ۴ ABI موجود |
| ساختار zip | ✅ `app.json` و `package.json` در ریشه، workflow در `.github/workflows/`، بدون `node_modules` |

## تست‌نشده — و دلیلش

**`expo prebuild` و `./gradlew assembleRelease` در این محیط اجرا نشدند.** سیاست sandbox ساخت اپ موبایل را مسدود می‌کند: هم دستور `expo prebuild` و هم دانلود Android SDK/NDK صریحاً رد شدند. پس مرحله‌ی Gradle را «تست‌شده» حساب نمی‌کنم و ادعا نمی‌کنم APK ساخته شد. برای جبران، بایت‌کد AGP 8.12.0 و سورس پلاگین‌های Expo/RN را خواندیم تا مطمئن شویم تشخیص با نسخه‌های واقعیِ نصب‌شده می‌خواند.
