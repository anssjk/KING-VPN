#!/usr/bin/env bash
#
# Downloads the two native tunnel libraries and installs them into the local Maven
# repository that `modules/king-vpn-tunnel` depends on.
#
# Why a local Maven repository instead of `implementation files("libv2ray.aar")`:
# the tunnel module is an Android *library* module. Android Gradle Plugin refuses a
# direct local `.aar` file dependency when the module itself builds an AAR:
#
#   Error while evaluating property 'hasLocalAarDeps' of task
#   ':king-vpn-tunnel:bundleReleaseLocalLintAar'
#     > Direct local .aar file dependencies are not supported when building an AAR.
#
# Gradle reports that through `DeferredUtil.unpack`, which prints a bare stack trace
# with no "What went wrong" line — the unreadable failure this project kept hitting.
# Publishing the same two AARs into a local Maven layout and depending on them by
# coordinate (com.kingvpn:libv2ray / com.kingvpn:hev) removes that property entirely.
#
# Run automatically:
#   * on EAS Build, through the `eas-build-pre-install` npm hook in package.json;
#   * on GitHub Actions, by the "Fetch the native tunnel libraries" step.
# Safe to run by hand, and safe to run twice: an already-downloaded file that still
# matches its recorded SHA-256 is left alone.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_DIR="$PROJECT_DIR/modules/king-vpn-tunnel/android/libs-repo"

install_aar() {
  local group="$1" artifact="$2" version="$3" url="$4" expected_sha="$5"
  local group_path="${group//./\/}"
  local dest_dir="$REPO_DIR/$group_path/$artifact/$version"
  local dest="$dest_dir/$artifact-$version.aar"

  if [ -f "$dest" ] && printf '%s  %s\n' "$expected_sha" "$dest" | sha256sum -c --status - 2>/dev/null; then
    echo "==> $group:$artifact:$version already present and verified"
    return 0
  fi

  mkdir -p "$dest_dir"
  echo "==> Downloading $group:$artifact:$version"
  echo "    $url"
  curl -sSL --fail --retry 3 --retry-delay 2 -o "$dest.part" "$url"

  printf '%s  %s\n' "$expected_sha" "$dest.part" | sha256sum -c - >/dev/null
  mv "$dest.part" "$dest"

  # A minimal POM is enough: the original `files(...)` dependency had no transitive
  # dependencies either, so this keeps the resolved graph exactly the same.
  cat > "$dest_dir/$artifact-$version.pom" <<POM
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>$group</groupId>
  <artifactId>$artifact</artifactId>
  <version>$version</version>
  <packaging>aar</packaging>
  <description>Pinned prebuilt native tunnel library, installed into a local Maven
    repository so the Expo module can depend on it by coordinate.</description>
</project>
POM

  echo "==> Installed $group:$artifact:$version"
}

install_aar "com.kingvpn" "libv2ray" "26.11.9" \
  "https://github.com/2dust/AndroidLibXrayLite/releases/download/v26.11.9/libv2ray.aar" \
  "cdfef146218233a31a8b52c8b1016557730d3b63fc121d4c84cacea50e669155"

install_aar "com.kingvpn" "hev" "2.20.0" \
  "https://github.com/heiher/hev-socks5-tunnel/releases/download/2.20.0/hev-socks5-tunnel.aar" \
  "ae8a2e96b80b4eccccd037805a4bb4a278090c89dbcae8bc6fcb7634e9a255b9"

echo "==> Native tunnel libraries are installed in:"
find "$REPO_DIR" -type f | sort
