# Native tunnel libraries

The tunnel needs two native libraries. They are **not** in the source zip, because
together they are about 60 MB — larger than GitHub's 25 MB browser-upload limit — and a
binary that size does not belong in a source archive.

`scripts/fetch-native-libs.sh` downloads them and installs them into a **local Maven
repository** at `modules/king-vpn-tunnel/android/libs-repo/`, verifying each one against
its recorded SHA-256 before installing it, so a build can never silently pick up a
different binary.

That script runs automatically on every supported build path:

- **EAS Build** — through the `eas-build-pre-install` npm hook in `package.json`
  (it runs before `npm install`, so the files are in place before prebuild);
- **GitHub Actions** — through the "Fetch the native tunnel libraries" workflow step.

| Artifact | What it is | Version | SHA-256 |
|---|---|---|---|
| `com.kingvpn:libv2ray` | Xray-core, built for Android (JNI). The multi-protocol core: VLESS, VMess, Trojan, Shadowsocks over TCP, WebSocket, gRPC, XHTTP, TLS and REALITY. | `26.11.9` | `cdfef146218233a31a8b52c8b1016557730d3b63fc121d4c84cacea50e669155` |
| `com.kingvpn:hev` | `hev-socks5-tunnel` — the TUN-to-SOCKS5 bridge that carries the device's packets to the core's local SOCKS port. | `2.20.0` | `ae8a2e96b80b4eccccd037805a4bb4a278090c89dbcae8bc6fcb7634e9a255b9` |

## Why a local Maven repository, not `files("libv2ray.aar")`

`modules/king-vpn-tunnel` is an Android **library** module, and Android Gradle Plugin
refuses a direct local `.aar` file dependency in a module that builds an AAR:

```
Error while evaluating property 'hasLocalAarDeps' of task
':king-vpn-tunnel:bundleReleaseLocalLintAar'
  > Direct local .aar file dependencies are not supported when building an AAR.
```

Gradle reports that through `DeferredUtil.unpack`, which prints a bare stack trace with
**no "What went wrong" line** — the unreadable failure this project kept hitting:

```
org.gradle.util.internal.DeferredUtil.unpack(DeferredUtil.java:57)
org.gradle.util.internal.DeferredUtil.unpackOrNull(DeferredUtil.java:49)
org.gradle.api.internal.tasks.properties.InputParameterUtils.prepareInputParameterValue(...)
... 103 more
BUILD FAILED
```

Depending on the same two AARs by coordinate from a local Maven repository removes the
`hasLocalAarDeps` property entirely, so the failure cannot happen.

## Running it by hand

```bash
bash scripts/fetch-native-libs.sh
```

Then check the two files are there:

```bash
find modules/king-vpn-tunnel/android/libs-repo -name '*.aar'
sha256sum modules/king-vpn-tunnel/android/libs-repo/com/kingvpn/*/*/*.aar
```

The two hashes must match the table above. If they do not, the download is not the build
this source was written against — do not build with it.

## Why these two

- **Xray-core** is the core the widely used Android clients are built on, and it is the
  one that actually implements the protocols and transports this app offers. It is linked
  in as a JNI library, so the protocol work happens in native code.
- **hev-socks5-tunnel** is the piece that turns "the core is running" into "the phone's
  traffic goes through the proxy". Xray exposes a SOCKS5 inbound; this library reads the
  raw IP packets from the `VpnService` TUN file descriptor and hands them to that port.
  Without it the core would be listening on a port nothing feeds.

## Minimum Android version

`hev-socks5-tunnel` declares `minSdkVersion 29` in its own manifest, so the app is pinned
to **API 29 (Android 10)** through the `expo-build-properties` plugin in `app.json`.
Without that pin the manifest merger stops the build with a minSdk conflict.
