import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { Card, FlagBadge, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { scanIps, type PingResult } from '@/lib/cloudflare';
import { tapFeedback } from '@/lib/haptics';
import { NODES, type NodeItem, type Protocol } from '@/lib/nodes';
import { useSettings } from '@/lib/settings-context';

export default function NodesScreen() {
  const colors = useColors();
  const { t, rtl } = useSettings();
  const { selectedNodeId, setSelectedNodeId, protocol, setProtocol } = useApp();

  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<PingResult[] | null>(null);

  const runScan = async () => {
    tapFeedback();
    setScanning(true);
    setProgress(0);
    setResults(null);
    try {
      const found = await scanIps(undefined, (done, total) => setProgress(done / total));
      setResults(found);
    } finally {
      setScanning(false);
    }
  };

  const selectIp = (ip: string) => {
    tapFeedback();
    const existing = NODES.find((n) => n.ip === ip);
    setSelectedNodeId(existing ? existing.id : `scan-${ip}`);
  };

  const protocolOptions: SegmentOption<Protocol>[] = [
    { value: 'ip', label: t('protoIp'), icon: 'server-outline' },
    { value: 'psiphon', label: t('protoPsiphon'), icon: 'shield-outline' },
    { value: 'warp', label: t('protoWarp'), icon: 'flash-outline' },
  ];

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('nodesTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('nodesSubtitle')}</Text>
      </View>

      {/* All nodes (WARP + Psiphon + IP nodes) in one section */}
      <SectionHeader
        title={t('allNodes')}
        badge={
          <View style={[styles.countPill, { backgroundColor: colors.cardAlt }]}>
            <Text style={[styles.countText, { color: colors.primary }]}>{NODES.length}</Text>
          </View>
        }
      />
      <View style={styles.list}>
        {NODES.map((node) => (
          <NodeRow
            key={node.id}
            node={node}
            selected={node.id === selectedNodeId}
            onPress={() => {
              tapFeedback();
              setSelectedNodeId(node.id);
            }}
          />
        ))}
      </View>

      {/* Protocols */}
      <SectionHeader title={t('protocols')} />
      <Segmented options={protocolOptions} value={protocol} onChange={setProtocol} layout="grid" />

      {/* Scanner */}
      <SectionHeader title={t('scanner')} subtitle={t('scannerSubtitle')} />
      <Card>
        <View style={[styles.scanTop, rtl && styles.rowReverse]}>
          <View style={styles.scanTextWrap}>
            <Text style={[styles.scanHint, { color: colors.muted }]}>{t('scanHint')}</Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t('scan')}
            disabled={scanning}
            onPress={runScan}
            style={({ pressed }) => [styles.scanBtn, pressed && { opacity: 0.85 }, scanning && { opacity: 0.7 }]}>
            <LinearGradient
              colors={colors.gradientBrand}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.scanBtnFill}>
              {scanning ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <Ionicons name="scan" size={16} color="#FFFFFF" />
              )}
              <Text style={styles.scanBtnText}>{scanning ? t('scanning') : t('scan')}</Text>
            </LinearGradient>
          </Pressable>
        </View>

        {scanning ? (
          <View style={styles.progressWrap}>
            <View style={[styles.progressTrack, { backgroundColor: colors.cardAlt }]}>
              <View
                style={[
                  styles.progressFill,
                  { backgroundColor: colors.primary, width: `${Math.max(4, Math.round(progress * 100))}%` },
                ]}
              />
            </View>
            <Text style={[styles.progressText, { color: colors.muted }]}>{Math.round(progress * 100)}%</Text>
          </View>
        ) : null}

        {results === null && !scanning ? (
          <View style={styles.emptyWrap}>
            <Ionicons name="radio-outline" size={26} color={colors.faint} />
            <Text style={[styles.empty, { color: colors.faint }]}>{t('scanEmpty')}</Text>
          </View>
        ) : null}

        {results !== null && results.length === 0 ? (
          <View style={styles.emptyWrap}>
            <Ionicons name="cloud-offline-outline" size={26} color={colors.faint} />
            <Text style={[styles.empty, { color: colors.faint }]}>{t('scanNone')}</Text>
          </View>
        ) : null}

        {results !== null && results.length > 0 ? (
          <View style={styles.results}>
            <Text style={[styles.foundText, { color: colors.success }]}>
              {results.length} {t('scanFound')}
            </Text>
            {results.map((r) => {
              const selected =
                selectedNodeId === `scan-${r.ip}` || NODES.find((n) => n.id === selectedNodeId)?.ip === r.ip;
              return (
                <Pressable
                  key={r.ip}
                  onPress={() => selectIp(r.ip)}
                  style={({ pressed }) => [
                    styles.resultRow,
                    {
                      backgroundColor: selected ? colors.cardAlt : 'transparent',
                      borderColor: selected ? colors.primary : colors.border,
                    },
                    pressed && { opacity: 0.75 },
                  ]}>
                  <Ionicons
                    name={selected ? 'radio-button-on' : 'radio-button-off'}
                    size={19}
                    color={selected ? colors.primary : colors.faint}
                  />
                  <Text style={[styles.resultIp, { color: colors.text }]}>{r.ip}</Text>
                  <View style={[styles.pingPill, { backgroundColor: colors.cardAlt }]}>
                    <Text style={[styles.resultPing, { color: colors.success }]}>
                      {r.ms} {t('ms')}
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </View>
        ) : null}
      </Card>
    </Screen>
  );
}

function NodeRow({ node, selected, onPress }: { node: NodeItem; selected: boolean; onPress: () => void }) {
  const colors = useColors();
  const { t, rtl } = useSettings();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.nodeRow,
        {
          backgroundColor: colors.card,
          borderColor: selected ? colors.primary : colors.border,
        },
        selected && {
          shadowColor: colors.primary,
          shadowOpacity: 0.35,
          shadowRadius: 14,
          shadowOffset: { width: 0, height: 6 },
          elevation: 6,
        },
        pressed && { opacity: 0.85 },
      ]}>
      <FlagBadge flag={node.flag} size={42} />
      <View style={styles.nodeInfo}>
        <Text style={[styles.nodeName, { color: colors.text }]} numberOfLines={1}>
          {node.name}
        </Text>
        <Text style={[styles.nodeMeta, { color: colors.faint }]} numberOfLines={1}>
          {node.country} · {node.ip}
        </Text>
      </View>
      <View style={styles.nodeRight}>
        <Text style={[styles.nodePing, { color: colors.muted }]}>
          {node.basePing} {t('ms')}
        </Text>
        {selected ? (
          <View style={[styles.selectedBadge, { backgroundColor: colors.primary }]}>
            <Ionicons name="checkmark" size={11} color="#FFFFFF" />
            <Text style={styles.selectedText}>{t('selected')}</Text>
          </View>
        ) : (
          <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={16} color={colors.faint} />
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  countPill: { borderRadius: radius.pill, paddingHorizontal: 9, paddingVertical: 2 },
  countText: { fontSize: 11.5, fontWeight: '800' },
  list: { gap: spacing.sm },
  nodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  nodeInfo: { flex: 1, gap: 2 },
  nodeName: { fontSize: 15, fontWeight: '700' },
  nodeMeta: { fontSize: 11.5 },
  nodeRight: { alignItems: 'flex-end', gap: 4 },
  nodePing: { fontSize: 11.5, fontWeight: '700' },
  selectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    borderRadius: radius.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  selectedText: { fontSize: 10, fontWeight: '800', color: '#FFFFFF' },
  scanTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  scanTextWrap: { flex: 1 },
  scanHint: { fontSize: 12.5, lineHeight: 18 },
  scanBtn: { borderRadius: radius.pill, overflow: 'hidden' },
  scanBtnFill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 11,
  },
  scanBtnText: { fontSize: 13, fontWeight: '800', color: '#FFFFFF' },
  progressWrap: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  progressTrack: { flex: 1, height: 7, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: 7, borderRadius: 4 },
  progressText: { fontSize: 11.5, fontWeight: '800', width: 38, textAlign: 'right' },
  emptyWrap: { alignItems: 'center', gap: 6, paddingVertical: spacing.md },
  empty: { fontSize: 12.5, textAlign: 'center' },
  results: { gap: spacing.xs },
  foundText: { fontSize: 11.5, fontWeight: '800', letterSpacing: 0.4, textTransform: 'uppercase' },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingVertical: 9,
    paddingHorizontal: spacing.md,
  },
  resultIp: { flex: 1, fontSize: 14.5, fontWeight: '600' },
  pingPill: { borderRadius: radius.pill, paddingHorizontal: 8, paddingVertical: 3 },
  resultPing: { fontSize: 12, fontWeight: '800' },
});
