import Ionicons from '@expo/vector-icons/Ionicons';
import Constants from 'expo-constants';
import { LinearGradient } from 'expo-linear-gradient';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { BrandMark, Card, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import type { Lang } from '@/lib/i18n';
import { tapFeedback } from '@/lib/haptics';
import { useSettings, type ThemeMode } from '@/lib/settings-context';

const TELEGRAM_CHANNEL = 'https://t.me/kingpannel758';
const TELEGRAM_DEV = 'https://t.me/LoadingTURK';
const DEV_HANDLE = '@LoadingTURK';
const VERSION = Constants.expoConfig?.version ?? '1.0.0';

export default function AboutScreen() {
  const colors = useColors();
  const { t, lang, setLang, theme, setTheme, rtl } = useSettings();

  const open = (url: string) => {
    tapFeedback();
    Linking.openURL(url).catch(() => {});
  };

  const langOptions: SegmentOption<Lang>[] = [
    { value: 'en', label: 'English' },
    { value: 'fa', label: 'فارسی' },
  ];
  const themeOptions: SegmentOption<ThemeMode>[] = [
    { value: 'light', label: t('light'), icon: 'sunny-outline' },
    { value: 'dark', label: t('dark'), icon: 'moon-outline' },
  ];

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('aboutTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('aboutSubtitle')}</Text>
      </View>

      {/* Brand hero card */}
      <View style={styles.heroCard}>
        <LinearGradient
          colors={colors.gradientHero}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[StyleSheet.absoluteFill, { borderRadius: radius.xl }]}
        />
        <View style={[styles.heroInner, { borderColor: colors.border }]}>
          <BrandMark size={56} />
          <View style={styles.heroText}>
            <Text style={[styles.heroTitle, { color: colors.text }]}>
              King <Text style={{ color: colors.primary }}>VPN</Text>
            </Text>
            <Text style={[styles.heroTagline, { color: colors.muted }]}>{t('tagline')}</Text>
          </View>
          <View style={[styles.versionPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.versionText, { color: colors.muted }]}>v{VERSION}</Text>
          </View>
        </View>
      </View>

      {/* Preferences: language + theme */}
      <SectionHeader title={t('preferences')} />
      <Card style={styles.prefCard}>
        <View style={styles.prefRow}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name="language" size={18} color={colors.primary} />
          </View>
          <Text style={[styles.prefLabel, { color: colors.text }]}>{t('language')}</Text>
        </View>
        <Segmented options={langOptions} value={lang} onChange={setLang} />

        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        <View style={styles.prefRow}>
          <View style={[styles.prefIcon, { backgroundColor: colors.cardAlt }]}>
            <Ionicons name={theme === 'dark' ? 'moon' : 'sunny'} size={18} color={colors.primary} />
          </View>
          <Text style={[styles.prefLabel, { color: colors.text }]}>{t('theme')}</Text>
        </View>
        <Segmented options={themeOptions} value={theme} onChange={setTheme} />
      </Card>

      {/* Community links */}
      <SectionHeader title={t('community')} />

      <LinkCard
        icon="paper-plane"
        iconColors={['#2AABEE', '#229ED9']}
        label={t('telegramChannel')}
        value={TELEGRAM_CHANNEL.replace('https://', '')}
        hint={t('channelHint')}
        onPress={() => open(TELEGRAM_CHANNEL)}
        rtl={rtl}
      />

      <LinkCard
        icon="person"
        iconColors={colors.gradientBrand}
        label={t('developer')}
        value={DEV_HANDLE}
        hint={t('devHint')}
        onPress={() => open(TELEGRAM_DEV)}
        rtl={rtl}
      />

      <Text style={[styles.footer, { color: colors.faint }]}>
        King VPN · {t('version')} {VERSION}
      </Text>
    </Screen>
  );
}

function LinkCard({
  icon,
  iconColors,
  label,
  value,
  hint,
  onPress,
  rtl,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconColors: readonly [string, string, ...string[]];
  label: string;
  value: string;
  hint: string;
  onPress: () => void;
  rtl: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.linkCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && { opacity: 0.85, transform: [{ scale: 0.99 }] },
      ]}>
      <LinearGradient
        colors={iconColors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.linkIcon}>
        <Ionicons name={icon} size={20} color="#FFFFFF" />
      </LinearGradient>
      <View style={styles.linkInfo}>
        <Text style={[styles.linkLabel, { color: colors.faint }]}>{label}</Text>
        <Text style={[styles.linkValue, { color: colors.text }]} numberOfLines={1}>
          {value}
        </Text>
        <Text style={[styles.linkHint, { color: colors.muted }]} numberOfLines={1}>
          {hint}
        </Text>
      </View>
      <View style={[styles.openBtn, { backgroundColor: colors.cardAlt }]}>
        <Ionicons name={rtl ? 'arrow-back' : 'arrow-forward'} size={16} color={colors.primary} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  heroCard: { borderRadius: radius.xl, overflow: 'hidden' },
  heroInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.xl,
  },
  heroText: { flex: 1, gap: 2 },
  heroTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.5 },
  heroTagline: { fontSize: 12.5 },
  versionPill: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  versionText: { fontSize: 11.5, fontWeight: '800' },
  prefCard: { gap: spacing.sm },
  prefRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  prefIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  prefLabel: { fontSize: 15, fontWeight: '700' },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 4 },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  linkIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  linkInfo: { flex: 1, gap: 1 },
  linkLabel: { fontSize: 11, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
  linkValue: { fontSize: 15, fontWeight: '700' },
  linkHint: { fontSize: 11.5 },
  openBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  footer: { fontSize: 12, textAlign: 'center', marginTop: spacing.md },
});
