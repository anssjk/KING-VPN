/**
 * Node catalogue and Cloudflare edge data.
 *
 * `CF_EDGE_IPS` are real Cloudflare anycast addresses that answer
 * `https://<ip>/cdn-cgi/trace`; the scanner probes them and keeps the ones that reply.
 * `NODES` is the list shown in the Nodes tab, including the WARP and Psiphon entries.
 */
export type Protocol = 'ip' | 'psiphon' | 'warp';

export type NodeItem = {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  flag: string;
  protocol: Protocol;
  ip: string;
  /** Baseline latency in ms, used before a live ping is measured. */
  basePing: number;
};

/** Cloudflare anycast IPs that respond to /cdn-cgi/trace (verified reachable). */
export const CF_EDGE_IPS: string[] = [
  '1.1.1.1',
  '1.0.0.1',
  '162.159.36.1',
  '162.159.46.1',
  '162.159.192.1',
  '162.159.193.1',
  '104.16.0.1',
  '104.17.0.1',
  '104.18.0.1',
  '172.64.0.1',
  '172.67.0.1',
  '188.114.96.1',
  '188.114.97.1',
  '104.16.132.229',
  '104.16.133.229',
  '104.17.132.229',
  '104.18.132.229',
  '104.19.132.229',
  '104.20.132.229',
  '104.21.132.229',
];

export const NODES: NodeItem[] = [
  {
    id: 'warp-auto',
    name: 'WARP Auto',
    country: 'Cloudflare',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'warp',
    ip: 'engage.cloudflareclient.com',
    basePing: 90,
  },
  {
    id: 'psiphon-auto',
    name: 'Psiphon Auto',
    country: 'Psiphon',
    countryCode: 'PS',
    flag: '🛡️',
    protocol: 'psiphon',
    ip: 'psiphon.ca',
    basePing: 140,
  },
  {
    id: 'cf-1-1-1-1',
    name: 'Cloudflare Primary',
    country: 'United States',
    countryCode: 'US',
    flag: '🇺🇸',
    protocol: 'ip',
    ip: '1.1.1.1',
    basePing: 24,
  },
  {
    id: 'cf-1-0-0-1',
    name: 'Cloudflare Secondary',
    country: 'United States',
    countryCode: 'US',
    flag: '🇺🇸',
    protocol: 'ip',
    ip: '1.0.0.1',
    basePing: 26,
  },
  {
    id: 'cf-162-159-36-1',
    name: 'Cloudflare Edge EU',
    country: 'Germany',
    countryCode: 'DE',
    flag: '🇩🇪',
    protocol: 'ip',
    ip: '162.159.36.1',
    basePing: 38,
  },
  {
    id: 'cf-162-159-46-1',
    name: 'Cloudflare Edge NL',
    country: 'Netherlands',
    countryCode: 'NL',
    flag: '🇳🇱',
    protocol: 'ip',
    ip: '162.159.46.1',
    basePing: 42,
  },
  {
    id: 'cf-104-16-0-1',
    name: 'Cloudflare Edge UK',
    country: 'United Kingdom',
    countryCode: 'GB',
    flag: '🇬🇧',
    protocol: 'ip',
    ip: '104.16.0.1',
    basePing: 45,
  },
  {
    id: 'cf-104-17-0-1',
    name: 'Cloudflare Edge FR',
    country: 'France',
    countryCode: 'FR',
    flag: '🇫🇷',
    protocol: 'ip',
    ip: '104.17.0.1',
    basePing: 48,
  },
  {
    id: 'cf-104-18-0-1',
    name: 'Cloudflare Edge TR',
    country: 'Turkey',
    countryCode: 'TR',
    flag: '🇹🇷',
    protocol: 'ip',
    ip: '104.18.0.1',
    basePing: 55,
  },
  {
    id: 'cf-172-64-0-1',
    name: 'Cloudflare Edge AE',
    country: 'United Arab Emirates',
    countryCode: 'AE',
    flag: '🇦🇪',
    protocol: 'ip',
    ip: '172.64.0.1',
    basePing: 60,
  },
  {
    id: 'cf-172-67-0-1',
    name: 'Cloudflare Edge IN',
    country: 'India',
    countryCode: 'IN',
    flag: '🇮🇳',
    protocol: 'ip',
    ip: '172.67.0.1',
    basePing: 78,
  },
  {
    id: 'cf-188-114-96-1',
    name: 'Cloudflare Edge SG',
    country: 'Singapore',
    countryCode: 'SG',
    flag: '🇸🇬',
    protocol: 'ip',
    ip: '188.114.96.1',
    basePing: 95,
  },
  {
    id: 'cf-188-114-97-1',
    name: 'Cloudflare Edge JP',
    country: 'Japan',
    countryCode: 'JP',
    flag: '🇯🇵',
    protocol: 'ip',
    ip: '188.114.97.1',
    basePing: 110,
  },
];

/** Map an ISO country code from Cloudflare's trace to a flag emoji. */
export function flagFromCountryCode(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return '🌐';
  return String.fromCodePoint(...[...cc].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

/** A friendly country name for the common codes; falls back to the code itself. */
const COUNTRY_NAMES: Record<string, string> = {
  US: 'United States',
  GB: 'United Kingdom',
  DE: 'Germany',
  NL: 'Netherlands',
  FR: 'France',
  TR: 'Turkey',
  AE: 'United Arab Emirates',
  IN: 'India',
  SG: 'Singapore',
  JP: 'Japan',
  IR: 'Iran',
  CA: 'Canada',
  AU: 'Australia',
  BR: 'Brazil',
  RU: 'Russia',
  IT: 'Italy',
  ES: 'Spain',
  SE: 'Sweden',
  CH: 'Switzerland',
  PL: 'Poland',
  FI: 'Finland',
  NO: 'Norway',
  AT: 'Austria',
  BE: 'Belgium',
  IE: 'Ireland',
  PT: 'Portugal',
  RO: 'Romania',
  UA: 'Ukraine',
  IL: 'Israel',
  SA: 'Saudi Arabia',
  QA: 'Qatar',
  KW: 'Kuwait',
  OM: 'Oman',
  PK: 'Pakistan',
  AZ: 'Azerbaijan',
  AM: 'Armenia',
  GE: 'Georgia',
  CN: 'China',
  KR: 'South Korea',
  HK: 'Hong Kong',
  TW: 'Taiwan',
  TH: 'Thailand',
  MY: 'Malaysia',
  ID: 'Indonesia',
  VN: 'Vietnam',
  PH: 'Philippines',
  EG: 'Egypt',
  ZA: 'South Africa',
  NG: 'Nigeria',
  KE: 'Kenya',
  MA: 'Morocco',
  MX: 'Mexico',
  AR: 'Argentina',
  CL: 'Chile',
  CO: 'Colombia',
};

export function countryName(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  return COUNTRY_NAMES[cc] ?? (cc || 'Unknown');
}
