import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

import { fetchTrace, pingHost, type TraceInfo } from '@/lib/cloudflare';
import { NODES, type NodeItem, type Protocol } from '@/lib/nodes';
import { usePersistentState } from '@/hooks/use-persistent-state';

export type ConnStatus = 'disconnected' | 'connecting' | 'connected';

type AppValue = {
  // Onboarding / account
  token: string;
  setToken: (t: string) => void;
  deployed: boolean;
  setDeployed: (v: boolean) => void;
  /** False until the stored values have loaded, so the router does not flash a screen. */
  ready: boolean;
  // Selection
  protocol: Protocol;
  setProtocol: (p: Protocol) => void;
  selectedNodeId: string;
  setSelectedNodeId: (id: string) => void;
  selectedNode: NodeItem;
  // Live connection
  status: ConnStatus;
  pingMs: number | null;
  trace: TraceInfo | null;
  error: string | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  runPing: () => Promise<void>;
  reset: () => void;
};

const AppContext = createContext<AppValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = usePersistentState<string>('cf_token', '');
  const [deployed, setDeployed, deployedStatus] = usePersistentState<boolean>('deployed', false);
  const [protocol, setProtocol] = usePersistentState<Protocol>('protocol', 'warp');
  const [selectedNodeId, setSelectedNodeId] = usePersistentState<string>('node_id', 'cf-1-1-1-1');

  const [status, setStatus] = useState<ConnStatus>('disconnected');
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [trace, setTrace] = useState<TraceInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const selectedNode = useMemo(
    () => NODES.find((n) => n.id === selectedNodeId) ?? NODES[0],
    [selectedNodeId],
  );

  const connect = useCallback(async () => {
    setError(null);
    setStatus('connecting');
    try {
      // A real round trip through the selected Cloudflare edge: this both proves the
      // node answers and reads back the public IP / country the edge sees.
      const info = await fetchTrace(selectedNode.ip);
      setTrace(info);
      const p = await pingHost(selectedNode.ip);
      setPingMs(p.ok ? p.ms : null);
      setStatus('connected');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Connection failed');
      setStatus('disconnected');
    }
  }, [selectedNode]);

  const disconnect = useCallback(() => {
    setStatus('disconnected');
    setError(null);
  }, []);

  const runPing = useCallback(async () => {
    const p = await pingHost(selectedNode.ip);
    setPingMs(p.ok ? p.ms : null);
  }, [selectedNode]);

  const reset = useCallback(() => {
    setDeployed(false);
    setStatus('disconnected');
    setTrace(null);
    setPingMs(null);
  }, [setDeployed]);

  const value = useMemo<AppValue>(
    () => ({
      token,
      setToken,
      deployed,
      setDeployed,
      ready: deployedStatus !== 'loading',
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      status,
      pingMs,
      trace,
      error,
      connect,
      disconnect,
      runPing,
      reset,
    }),
    [
      token,
      setToken,
      deployed,
      setDeployed,
      deployedStatus,
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      status,
      pingMs,
      trace,
      error,
      connect,
      disconnect,
      runPing,
      reset,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return value;
}
