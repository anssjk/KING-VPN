/**
 * Cloudflare network layer.
 *
 * Everything here talks to real Cloudflare endpoints over HTTPS:
 *   - `https://<ip>/cdn-cgi/trace`  → the caller's public IP, country and edge colo
 *   - the same URL is timed to measure latency (ping)
 *   - `https://api.cloudflare.com/client/v4/user/tokens/verify` → token check
 *
 * Every request has an AbortController timeout so a dead host can never hang the UI.
 */
import { CF_EDGE_IPS } from '@/lib/nodes';

const TRACE_TIMEOUT_MS = 6000;
const PING_TIMEOUT_MS = 5000;
const VERIFY_TIMEOUT_MS = 10000;

export type TraceInfo = {
  ip: string;
  loc: string;
  colo: string;
  warp: string;
  http: string;
  tls: string;
};

export type PingResult = {
  ip: string;
  ok: boolean;
  ms: number;
};

async function fetchWithTimeout(url: string, timeoutMs: number, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function parseTrace(text: string): TraceInfo {
  const map: Record<string, string> = {};
  for (const line of text.split('\n')) {
    const idx = line.indexOf('=');
    if (idx > 0) {
      map[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
    }
  }
  return {
    ip: map.ip ?? '',
    loc: map.loc ?? '',
    colo: map.colo ?? '',
    warp: map.warp ?? 'off',
    http: map.http ?? '',
    tls: map.tls ?? '',
  };
}

/** Read the caller's public IP, country and edge colo through Cloudflare. */
export async function fetchTrace(ip = '1.1.1.1'): Promise<TraceInfo> {
  const res = await fetchWithTimeout(`https://${ip}/cdn-cgi/trace`, TRACE_TIMEOUT_MS, {
    headers: { Accept: 'text/plain' },
  });
  if (!res.ok) {
    throw new Error(`trace failed (${res.status})`);
  }
  const text = await res.text();
  const info = parseTrace(text);
  if (!info.ip) {
    throw new Error('trace returned no ip');
  }
  return info;
}

/** Measure round-trip latency to a Cloudflare edge IP, in milliseconds. */
export async function pingHost(ip: string): Promise<PingResult> {
  const started = Date.now();
  try {
    const res = await fetchWithTimeout(`https://${ip}/cdn-cgi/trace`, PING_TIMEOUT_MS, {
      headers: { Accept: 'text/plain' },
      cache: 'no-store',
    });
    const ms = Date.now() - started;
    if (!res.ok) {
      return { ip, ok: false, ms };
    }
    // Drain the body so the timing covers the full round trip.
    await res.text();
    return { ip, ok: true, ms: Date.now() - started };
  } catch {
    return { ip, ok: false, ms: Date.now() - started };
  }
}

/**
 * Probe a list of IPs and return the ones that answered, fastest first.
 * `onProgress` reports how many have been checked so the UI can show a bar.
 */
export async function scanIps(
  ips: string[] = CF_EDGE_IPS,
  onProgress?: (done: number, total: number) => void,
): Promise<PingResult[]> {
  const results: PingResult[] = [];
  let done = 0;
  // Small batches keep the phone's connection pool happy and the scan quick.
  const batchSize = 6;
  for (let i = 0; i < ips.length; i += batchSize) {
    const batch = ips.slice(i, i + batchSize);
    const settled = await Promise.all(batch.map((ip) => pingHost(ip)));
    for (const r of settled) {
      if (r.ok) results.push(r);
    }
    done += batch.length;
    onProgress?.(Math.min(done, ips.length), ips.length);
  }
  return results.sort((a, b) => a.ms - b.ms);
}

export type TokenVerifyResult = {
  ok: boolean;
  status: 'active' | 'invalid' | 'unknown';
  message: string;
};

/**
 * Verify a Cloudflare API token against the official endpoint. A network failure is
 * reported as `unknown` so the app can still continue offline rather than blocking the
 * user on a flaky connection.
 */
export async function verifyToken(token: string): Promise<TokenVerifyResult> {
  const trimmed = token.trim();
  if (!trimmed) {
    return { ok: false, status: 'invalid', message: 'Token is empty.' };
  }
  try {
    const res = await fetchWithTimeout(
      'https://api.cloudflare.com/client/v4/user/tokens/verify',
      VERIFY_TIMEOUT_MS,
      {
        headers: {
          Authorization: `Bearer ${trimmed}`,
          'Content-Type': 'application/json',
        },
      },
    );
    const body = (await res.json().catch(() => null)) as
      | { success?: boolean; result?: { status?: string }; errors?: { message?: string }[] }
      | null;
    if (res.ok && body?.success && body.result?.status === 'active') {
      return { ok: true, status: 'active', message: 'Token is active.' };
    }
    const message = body?.errors?.[0]?.message ?? `Token rejected (${res.status}).`;
    return { ok: false, status: 'invalid', message };
  } catch {
    return {
      ok: false,
      status: 'unknown',
      message: 'Could not reach Cloudflare. Check your connection.',
    };
  }
}
