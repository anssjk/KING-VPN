import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AuroraBackground } from '@/components/aurora-background';
import { BrandMark, Button, TextField } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { fetchTrace, verifyToken } from '@/lib/cloudflare';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import { useSettings } from '@/lib/settings-context';

/**
 * Cloudflare "API token template URL".
 *
 * Cloudflare's dashboard reads these query parameters and pre-fills the token
 * creation form, so the user only has to press "Create Token":
 *   - permissionGroupKeys: URL-encoded JSON array of permissions (required by Cloudflare)
 *   - accountId / zoneId:  scope of the token ("*" = all accounts, "all" = all zones)
 *   - name:                the token name, pre-filled with "KING VPN"
 *
 * The app only calls /user/tokens/verify, which needs no permission at all, so the
 * template asks for the smallest real permission (read-only account settings) instead
 * of granting anything broad.
 *
 * Docs: https://developers.cloudflare.com/fundamentals/api/how-to/account-owned-token-template/
 */
const CLOUDFLARE_TOKEN_NAME = 'KING VPN';
const CLOUDFLARE_TOKEN_PERMISSIONS = JSON.stringify([{ key: 'account_settings', type: 'read' }]);
const CLOUDFLARE_TOKEN_URL =
  'https://dash.cloudflare.com/profile/api-tokens' +
  `?permissionGroupKeys=${encodeURIComponent(CLOUDFLARE_TOKEN_PERMISSIONS)}` +
  '&accountId=%2A&zoneId=all' +
  `&name=${encodeURIComponent(CLOUDFLARE_TOKEN_NAME)}`;

/** Plain token page, used only if the template URL cannot be opened. */
const CLOUDFLARE_TOKEN_URL_FALLBACK = 'https://dash.cloudflare.com/profile/api-tokens';

type Step = 0 | 1 | 2;

export default function OnboardingScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const { token, setToken, setDeployed } = useApp();

  const [step, setStep] = useState<Step>(0);
  const [draft, setDraft] = useState(token);
  const [error, setError] = useState<string | null>(null);
  const [deploying, setDeploying] = useState(false);
  const [deployStep, setDeployStep] = useState(0);

  const openCloudflare = () => {
    tapFeedback();
    // The template URL pre-fills the token name ("KING VPN") and its permissions, so the
    // user only has to press "Create Token". If the phone cannot open it, fall back to
    // the plain token page so the link never becomes a dead end.
    Linking.openURL(CLOUDFLARE_TOKEN_URL).catch(() =>
      Linking.openURL(CLOUDFLARE_TOKEN_URL_FALLBACK).catch(() =>
        setError('Could not open the browser.'),
      ),
    );
  };

  const goToDeploy = () => {
    if (!draft.trim()) {
      setError(t('tokenRequired'));
      return;
    }
    tapFeedback();
    setError(null);
    setToken(draft.trim());
    setStep(2);
  };

  const startDeployment = async () => {
    tapFeedback();
    setDeploying(true);
    setDeployStep(0);
    setError(null);
    try {
      // Step 1: verify the token with Cloudflare (a network failure is tolerated).
      setDeployStep(1);
      const result = await verifyToken(draft.trim());
      if (result.status === 'invalid') {
        setError(result.message);
        setDeploying(false);
        setDeployStep(0);
        return;
      }
      // Step 2: reach the Cloudflare edge.
      setDeployStep(2);
      await fetchTrace('1.1.1.1').catch(() => null);
      // Step 3: prepare nodes.
      setDeployStep(3);
      await new Promise((r) => setTimeout(r, 600));
      setDeployStep(4);
      successFeedback();
      setDeployed(true);
      router.replace('/(tabs)');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Deployment failed.');
      setDeploying(false);
      setDeployStep(0);
    }
  };

  const badge = step === 0 ? t('ob1Badge') : step === 1 ? t('ob2Badge') : t('ob3Badge');

  return (
    <SafeAreaView edges={['top', 'left', 'right', 'bottom']} style={styles.root}>
      <AuroraBackground />
      <KeyboardAvoidingView
        style={styles.root}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          {/* Brand header */}
          <View style={styles.header}>
            <BrandMark size={52} />
            <Text style={[styles.brand, { color: colors.text }]}>
              King <Text style={{ color: colors.primary }}>VPN</Text>
            </Text>
            <Text style={[styles.tagline, { color: colors.muted }]}>{t('tagline')}</Text>
          </View>

          <StepBar step={step} badge={badge} />

          {step === 0 ? (
            <View style={styles.body}>
              <Text style={[styles.title, { color: colors.text }]}>{t('ob1Title')}</Text>
              <Text style={[styles.paragraph, { color: colors.muted }]}>{t('ob1Body')}</Text>

              <View style={styles.features}>
                <Feature icon="flash" text={t('ob1Feature1')} />
                <Feature icon="pulse" text={t('ob1Feature2')} />
                <Feature icon="color-palette" text={t('ob1Feature3')} />
              </View>

              <Button title={t('next')} icon="arrow-forward" onPress={() => setStep(1)} />
            </View>
          ) : null}

          {step === 1 ? (
            <View style={styles.body}>
              <Text style={[styles.title, { color: colors.text }]}>{t('ob2Title')}</Text>
              <Text style={[styles.paragraph, { color: colors.muted }]}>{t('ob2Body')}</Text>

              {/* Cloudflare link — opens the browser so the user can copy a token */}
              <Pressable
                onPress={openCloudflare}
                style={({ pressed }) => [
                  styles.linkCard,
                  { borderColor: colors.border, backgroundColor: colors.card },
                  pressed && { opacity: 0.8 },
                ]}>
                <LinearGradient
                  colors={['#F6821F', '#F38020']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.linkIcon}>
                  <Ionicons name="cloud" size={20} color="#FFFFFF" />
                </LinearGradient>
                <View style={styles.linkInfo}>
                  <Text style={[styles.linkTitle, { color: colors.text }]}>{t('ob2Link')}</Text>
                  <Text style={[styles.linkHint, { color: colors.faint }]}>{t('ob2LinkHint')}</Text>
                </View>
                <Ionicons name="open-outline" size={18} color={colors.primary} />
              </Pressable>

              <TextField
                label={t('tokenLabel')}
                placeholder={t('tokenPlaceholder')}
                value={draft}
                onChangeText={(v) => {
                  setDraft(v);
                  if (error) setError(null);
                }}
                autoCapitalize="none"
                autoCorrect={false}
                multiline
                error={error}
                hint={t('tokenHint')}
                style={styles.tokenInput}
              />

              <View style={styles.row}>
                <View style={styles.flex}>
                  <Button title={t('back')} variant="secondary" onPress={() => setStep(0)} />
                </View>
                <View style={styles.flex}>
                  <Button title={t('next')} icon="arrow-forward" onPress={goToDeploy} />
                </View>
              </View>
            </View>
          ) : null}

          {step === 2 ? (
            <View style={styles.body}>
              <Text style={[styles.title, { color: colors.text }]}>{t('ob3Title')}</Text>
              <Text style={[styles.paragraph, { color: colors.muted }]}>{t('ob3Body')}</Text>

              <View style={[styles.deployCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <DeployRow label={t('deployStep1')} state={deployStep >= 1} active={deploying && deployStep === 1} />
                <DeployRow label={t('deployStep2')} state={deployStep >= 2} active={deploying && deployStep === 2} />
                <DeployRow label={t('deployStep3')} state={deployStep >= 3} active={deploying && deployStep === 3} />
                <DeployRow label={t('deployStep4')} state={deployStep >= 4} active={false} />
              </View>

              {error ? (
                <View style={[styles.errorBox, { borderColor: colors.danger, backgroundColor: colors.card }]}>
                  <Ionicons name="alert-circle" size={18} color={colors.danger} />
                  <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
                </View>
              ) : null}

              <Button
                title={deploying ? t('deploying') : t('startDeploy')}
                icon="rocket"
                loading={deploying}
                onPress={startDeployment}
              />
              {!deploying ? (
                <Button title={t('back')} variant="ghost" onPress={() => setStep(1)} />
              ) : null}
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function StepBar({ step, badge }: { step: Step; badge: string }) {
  const colors = useColors();
  return (
    <View style={styles.stepWrap}>
      <View style={[styles.badgePill, { backgroundColor: colors.cardAlt }]}>
        <Text style={[styles.badgeText, { color: colors.primary }]}>{badge}</Text>
      </View>
      <View style={styles.stepBar}>
        {[0, 1, 2].map((i) => (
          <View key={i} style={styles.stepItem}>
            <View
              style={[
                styles.stepDot,
                {
                  backgroundColor: i <= step ? colors.primary : colors.card,
                  borderColor: i <= step ? colors.primary : colors.border,
                },
              ]}>
              {i < step ? (
                <Ionicons name="checkmark" size={15} color="#FFFFFF" />
              ) : (
                <Text style={[styles.stepNum, { color: i <= step ? '#FFFFFF' : colors.faint }]}>{i + 1}</Text>
              )}
            </View>
            {i < 2 ? (
              <View style={[styles.stepLine, { backgroundColor: i < step ? colors.primary : colors.border }]} />
            ) : null}
          </View>
        ))}
      </View>
    </View>
  );
}

function Feature({ icon, text }: { icon: keyof typeof Ionicons.glyphMap; text: string }) {
  const colors = useColors();
  return (
    <View style={[styles.featureRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.featureIcon, { backgroundColor: colors.cardAlt }]}>
        <Ionicons name={icon} size={17} color={colors.primary} />
      </View>
      <Text style={[styles.featureText, { color: colors.text }]}>{text}</Text>
    </View>
  );
}

function DeployRow({ label, state, active }: { label: string; state: boolean; active: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.deployRow}>
      {active ? (
        <ActivityIndicator size="small" color={colors.primary} />
      ) : (
        <Ionicons
          name={state ? 'checkmark-circle' : 'ellipse-outline'}
          size={20}
          color={state ? colors.success : colors.faint}
        />
      )}
      <Text style={[styles.deployLabel, { color: state ? colors.text : colors.muted }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { padding: spacing.lg, gap: spacing.md, paddingBottom: spacing.xl },
  header: { alignItems: 'center', gap: 6, marginTop: spacing.md },
  brand: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  tagline: { fontSize: 13, fontWeight: '500' },
  stepWrap: { alignItems: 'center', gap: spacing.sm, marginVertical: spacing.sm },
  badgePill: { borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 4 },
  badgeText: { fontSize: 11.5, fontWeight: '800', letterSpacing: 0.4 },
  stepBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  stepItem: { flexDirection: 'row', alignItems: 'center' },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNum: { fontSize: 13, fontWeight: '800' },
  stepLine: { width: 40, height: 2, marginHorizontal: 4 },
  body: { gap: spacing.md },
  title: { fontSize: 23, fontWeight: '900', textAlign: 'center', letterSpacing: -0.4 },
  paragraph: { fontSize: 14.5, lineHeight: 22, textAlign: 'center' },
  features: { gap: spacing.sm, marginVertical: spacing.xs },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    padding: spacing.sm + 2,
  },
  featureIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  featureText: { fontSize: 14, flex: 1, fontWeight: '600' },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    padding: spacing.sm + 2,
  },
  linkIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  linkInfo: { flex: 1, gap: 1 },
  linkTitle: { fontSize: 14.5, fontWeight: '700' },
  linkHint: { fontSize: 11.5 },
  tokenInput: { minHeight: 92, textAlignVertical: 'top', paddingTop: spacing.sm },
  row: { flexDirection: 'row', gap: spacing.sm },
  flex: { flex: 1 },
  deployCard: { borderWidth: StyleSheet.hairlineWidth, borderRadius: radius.lg, padding: spacing.md, gap: spacing.md },
  deployRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  deployLabel: { fontSize: 14.5, fontWeight: '600' },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },
});
