import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { Card, FlagBadge, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { tapFeedback } from '@/lib/haptics';
import { NODES, type NodeItem, type Protocol } from '@/lib/nodes';
import { useSettings } from '@/lib/settings-context';

export default function NodesScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const { selectedNodeId, setSelectedNodeId, protocol, setProtocol, selectedNode } = useApp();

  const protocolOptions: SegmentOption<Protocol>[] = [
    { value: 'ip', label: t('protoIp'), icon: 'server-outline' },
    { value: 'psiphon', label: t('protoPsiphon'), icon: 'shield-outline' },
    { value: 'warp', label: t('protoWarp'), icon: 'flash-outline' },
  ];

  // Group by protocol so the list reads as three real routing strategies.
  const groups: { protocol: Protocol; label: string; items: NodeItem[] }[] = [
    { protocol: 'warp', label: t('protoWarp'), items: NODES.filter((n) => n.protocol === 'warp') },
    { protocol: 'psiphon', label: t('protoPsiphon'), items: NODES.filter((n) => n.protocol === 'psiphon') },
    { protocol: 'ip', label: t('protoIp'), items: NODES.filter((n) => n.protocol === 'ip') },
  ];

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('nodesTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('nodesSubtitle')}</Text>
      </View>

      {/* Current selection */}
      <Card glowColor={colors.primary}>
        <View style={[styles.currentRow, rtl && styles.rowReverse]}>
          <FlagBadge flag={selectedNode.flag} size={44} />
          <View style={styles.currentInfo}>
            <Text style={[styles.currentLabel, { color: colors.faint }]}>{t('currentNode')}</Text>
            <Text style={[styles.currentName, { color: colors.text }]} numberOfLines={1}>
              {selectedNode.name}
            </Text>
            <Text style={[styles.currentHost, { color: colors.muted }]} numberOfLines={1}>
              {selectedNode.host}
            </Text>
          </View>
        </View>
      </Card>

      {/* Protocol */}
      <SectionHeader title={t('protocols')} subtitle={t('protocolHint')} />
      <Segmented options={protocolOptions} value={protocol} onChange={setProtocol} layout="grid" />

      {/* Scanner shortcut */}
      <Pressable
        onPress={() => {
          tapFeedback();
          router.push('/(tabs)/scanner');
        }}
        style={({ pressed }) => [
          styles.scanRow,
          { backgroundColor: colors.card, borderColor: colors.border },
          pressed && { opacity: 0.85 },
        ]}>
        <View style={[styles.scanIcon, { backgroundColor: colors.cardAlt }]}>
          <Ionicons name="scan" size={20} color={colors.primary} />
        </View>
        <View style={styles.scanInfo}>
          <Text style={[styles.scanTitle, { color: colors.text }]}>{t('scannerTitle')}</Text>
          <Text style={[styles.scanHint, { color: colors.faint }]} numberOfLines={1}>
            {t('scannerSubtitle')}
          </Text>
        </View>
        <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={18} color={colors.primary} />
      </Pressable>

      {/* Nodes, grouped by protocol */}
      {groups.map((group) => (
        <View key={group.protocol} style={styles.group}>
          <SectionHeader
            title={group.label}
            badge={
              <View style={[styles.countPill, { backgroundColor: colors.cardAlt }]}>
                <Text style={[styles.countText, { color: colors.primary }]}>{group.items.length}</Text>
              </View>
            }
          />
          <View style={styles.list}>
            {group.items.map((node) => (
              <NodeRow
                key={node.id}
                node={node}
                selected={node.id === selectedNodeId}
                onPress={() => {
                  tapFeedback();
                  setSelectedNodeId(node.id);
                }}
              />
            ))}
          </View>
        </View>
      ))}
    </Screen>
  );
}

function NodeRow({ node, selected, onPress }: { node: NodeItem; selected: boolean; onPress: () => void }) {
  const colors = useColors();
  const { t, rtl } = useSettings();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.nodeRow,
        {
          backgroundColor: colors.card,
          borderColor: selected ? colors.primary : colors.border,
        },
        selected && {
          shadowColor: colors.primary,
          shadowOpacity: 0.35,
          shadowRadius: 14,
          shadowOffset: { width: 0, height: 6 },
          elevation: 6,
        },
        pressed && { opacity: 0.85 },
      ]}>
      <FlagBadge flag={node.flag} size={42} />
      <View style={styles.nodeInfo}>
        <Text style={[styles.nodeName, { color: colors.text }]} numberOfLines={1}>
          {node.name}
        </Text>
        <Text style={[styles.nodeMeta, { color: colors.faint }]} numberOfLines={1}>
          {node.host}
        </Text>
        {node.note ? (
          <Text style={[styles.nodeNote, { color: colors.muted }]} numberOfLines={1}>
            {node.note}
          </Text>
        ) : null}
      </View>
      <View style={styles.nodeRight}>
        {selected ? (
          <View style={[styles.selectedBadge, { backgroundColor: colors.primary }]}>
            <Ionicons name="checkmark" size={11} color="#FFFFFF" />
            <Text style={styles.selectedText}>{t('selected')}</Text>
          </View>
        ) : (
          <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={16} color={colors.faint} />
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  currentRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  currentInfo: { flex: 1, gap: 1 },
  currentLabel: { fontSize: 10.5, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
  currentName: { fontSize: 16, fontWeight: '800' },
  currentHost: { fontSize: 11.5 },
  scanRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  scanIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  scanInfo: { flex: 1, gap: 2 },
  scanTitle: { fontSize: 14.5, fontWeight: '800' },
  scanHint: { fontSize: 11.5 },
  group: { gap: spacing.sm },
  countPill: { borderRadius: radius.pill, paddingHorizontal: 9, paddingVertical: 2 },
  countText: { fontSize: 11.5, fontWeight: '800' },
  list: { gap: spacing.sm },
  nodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  nodeInfo: { flex: 1, gap: 1 },
  nodeName: { fontSize: 15, fontWeight: '700' },
  nodeMeta: { fontSize: 11.5 },
  nodeNote: { fontSize: 10.5 },
  nodeRight: { alignItems: 'flex-end', gap: 4 },
  selectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    borderRadius: radius.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  selectedText: { fontSize: 10, fontWeight: '800', color: '#FFFFFF' },
});
