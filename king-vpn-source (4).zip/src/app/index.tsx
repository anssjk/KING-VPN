import { Redirect } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';

import { AuroraBackground } from '@/components/aurora-background';
import { BrandMark } from '@/components/ui';
import { useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';

/**
 * Entry point.
 *
 *   not deployed yet  → onboarding
 *   deployed          → the permission gate, which then hands off to the tabs
 *
 * The gate is a separate route rather than a modal so the user can leave it with the
 * system back button and land in the app, and so it is only shown once per launch.
 */
export default function Index() {
  const colors = useColors();
  const { deployed, ready } = useApp();

  if (!ready) {
    return (
      <View style={styles.center}>
        <AuroraBackground />
        <BrandMark size={64} />
        <ActivityIndicator color={colors.primary} style={styles.spinner} />
      </View>
    );
  }

  return <Redirect href={deployed ? '/permissions' : '/onboarding'} />;
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 20 },
  spinner: { marginTop: 8 },
});
