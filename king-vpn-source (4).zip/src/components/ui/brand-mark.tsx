import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet, Text, View } from 'react-native';

import { useColors } from '@/constants/theme';

type Props = {
  size?: number;
  /** Show the wordmark next to the shield. */
  withWordmark?: boolean;
};

/** The King VPN shield in a gradient tile — the app logo, drawn in code. */
export function BrandMark({ size = 44, withWordmark }: Props) {
  const colors = useColors();
  return (
    <View style={styles.row}>
      <LinearGradient
        colors={colors.gradientBrand}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.tile,
          {
            width: size,
            height: size,
            borderRadius: size * 0.31,
            shadowColor: colors.primary,
            shadowOpacity: 0.5,
            shadowRadius: size * 0.35,
            shadowOffset: { width: 0, height: size * 0.16 },
            elevation: 8,
          },
        ]}>
        <Ionicons name="shield-checkmark" size={size * 0.56} color="#FFFFFF" />
      </LinearGradient>
      {withWordmark ? (
        <Text style={[styles.wordmark, { color: colors.text, fontSize: size * 0.6 }]}>
          King <Text style={{ color: colors.primary }}>VPN</Text>
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  tile: { alignItems: 'center', justifyContent: 'center' },
  wordmark: { fontWeight: '900', letterSpacing: -0.6 },
});
