import { useCallback, useRef, useState } from 'react';

import { scanEndpoints, type PingResult, type ScanSummary } from '@/lib/cloudflare';

export type ScanPhase = 'idle' | 'running' | 'done' | 'cancelled';

export type ScannerState = {
  phase: ScanPhase;
  /** 0..1 */
  progress: number;
  done: number;
  total: number;
  /** Every endpoint measured so far, in completion order. */
  results: PingResult[];
  /** Endpoints that answered, fastest first. */
  reachable: PingResult[];
  summary: ScanSummary | null;
  error: string | null;
};

const INITIAL: ScannerState = {
  phase: 'idle',
  progress: 0,
  done: 0,
  total: 0,
  results: [],
  reachable: [],
  summary: null,
  error: null,
};

/**
 * Drives a scan and exposes its live state.
 *
 * The scan itself lives in `scanEndpoints`; this hook only owns the React state, the
 * cancel flag and the progress maths, so the screen stays a pure view. Results stream in
 * as each endpoint finishes, which is what makes the list feel alive instead of frozen
 * behind a spinner.
 */
export function useScanner() {
  const [state, setState] = useState<ScannerState>(INITIAL);
  const stopRef = useRef(false);
  const runningRef = useRef(false);

  const start = useCallback(async (hosts: string[], samples = 3, concurrency = 6) => {
    if (runningRef.current) return;
    runningRef.current = true;
    stopRef.current = false;
    setState({ ...INITIAL, phase: 'running', total: hosts.length });

    try {
      const summary = await scanEndpoints(hosts, {
        samples,
        concurrency,
        shouldStop: () => stopRef.current,
        onResult: (result, done, total) => {
          setState((prev) => {
            const results = [...prev.results, result];
            const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
            return {
              ...prev,
              results,
              reachable,
              done,
              total,
              progress: total > 0 ? done / total : 0,
            };
          });
        },
      });
      setState((prev) => ({
        ...prev,
        phase: summary.cancelled ? 'cancelled' : 'done',
        summary,
        reachable: summary.reachable,
        progress: 1,
      }));
    } catch (e) {
      setState((prev) => ({
        ...prev,
        phase: 'done',
        error: e instanceof Error ? e.message : 'Scan failed',
      }));
    } finally {
      runningRef.current = false;
    }
  }, []);

  const cancel = useCallback(() => {
    stopRef.current = true;
  }, []);

  const reset = useCallback(() => {
    if (runningRef.current) return;
    setState(INITIAL);
  }, []);

  return { ...state, start, cancel, reset, running: state.phase === 'running' };
}
