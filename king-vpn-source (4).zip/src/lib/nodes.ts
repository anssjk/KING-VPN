/**
 * Endpoint catalogue.
 *
 * Every entry is a **WARP endpoint**: a Cloudflare anycast address that accepts
 * WireGuard on port 2408. That is the key correction in this build — the previous
 * version listed plain HTTPS web addresses and then "connected" by fetching
 * `/cdn-cgi/trace`, which is a connectivity test, not a VPN. A WARP endpoint is
 * something a WireGuard tunnel can actually dial.
 *
 * The same Cloudflare peer public key serves all of them, so switching node changes
 * *where* the tunnel is dialled (useful when one anycast range is filtered on the local
 * network) without needing a new registration.
 *
 * Protocols are real routing strategies:
 *   - `warp`    → the hostname endpoint, which follows Cloudflare's DNS-based routing
 *   - `ip`      → a bare anycast IP, which skips DNS entirely
 *   - `psiphon` → a different anycast range, as an alternative path
 */

export type Protocol = 'ip' | 'psiphon' | 'warp';

/** `ip` endpoints are dialled as bare addresses; `host` endpoints use DNS. */
export type EndpointKind = 'ip' | 'host';

export type NodeItem = {
  id: string;
  name: string;
  /** Where the anycast range is announced. Anycast nodes are shown honestly. */
  country: string;
  countryCode: string;
  flag: string;
  protocol: Protocol;
  /** Bare IP or hostname the tunnel dials. */
  host: string;
  kind: EndpointKind;
  /** Baseline latency in ms, used for ordering before a live probe is measured. */
  basePing: number;
  /** One-line description of why this endpoint is reachable. */
  note?: string;
};

/** The port every WARP endpoint listens on for WireGuard. */
export const WARP_PORT = 2408;

/**
 * Cloudflare's WARP anycast ranges. These are the addresses the official client dials
 * when it cannot use the hostname, and they accept WireGuard on 2408.
 */
export const WARP_IPS: string[] = [
  '162.159.192.1',
  '162.159.193.1',
  '162.159.195.1',
  '162.159.204.1',
  '188.114.96.1',
  '188.114.97.1',
  '188.114.98.1',
  '188.114.99.1',
];

/** The hostname endpoint — Cloudflare routes it to the nearest healthy edge. */
export const WARP_HOST = 'engage.cloudflareclient.com';

export const NODES: NodeItem[] = [
  {
    id: 'warp-auto',
    name: 'WARP Auto',
    country: 'Global — automatic',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'warp',
    host: WARP_HOST,
    kind: 'host',
    basePing: 90,
    note: 'Cloudflare picks the nearest healthy edge',
  },
  {
    id: 'warp-ip-1',
    name: 'WARP 162.159.192.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.192.1',
    kind: 'ip',
    basePing: 40,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-2',
    name: 'WARP 162.159.193.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.193.1',
    kind: 'ip',
    basePing: 42,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-3',
    name: 'WARP 162.159.195.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.195.1',
    kind: 'ip',
    basePing: 44,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-4',
    name: 'WARP 162.159.204.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.204.1',
    kind: 'ip',
    basePing: 46,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-psiphon-1',
    name: 'WARP 188.114.96.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🛡️',
    protocol: 'psiphon',
    host: '188.114.96.1',
    kind: 'ip',
    basePing: 50,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-2',
    name: 'WARP 188.114.97.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🛡️',
    protocol: 'psiphon',
    host: '188.114.97.1',
    kind: 'ip',
    basePing: 52,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-3',
    name: 'WARP 188.114.98.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🛡️',
    protocol: 'psiphon',
    host: '188.114.98.1',
    kind: 'ip',
    basePing: 54,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-4',
    name: 'WARP 188.114.99.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🛡️',
    protocol: 'psiphon',
    host: '188.114.99.1',
    kind: 'ip',
    basePing: 56,
    note: 'Alternative anycast range',
  },
];

/** Every endpoint the scanner probes by default. */
export const SCAN_SEEDS: string[] = dedupe([WARP_HOST, ...WARP_IPS]);

/**
 * The ordered candidate list for a protocol.
 *
 * `connect()` walks this list when the selected endpoint fails, so one filtered anycast
 * address can never strand the user on an error.
 */
export function candidatesFor(protocol: Protocol, selectedHost?: string): string[] {
  const pools: Record<Protocol, string[]> = {
    warp: [WARP_HOST, ...WARP_IPS],
    ip: [...WARP_IPS, WARP_HOST],
    psiphon: [
      '188.114.96.1',
      '188.114.97.1',
      '188.114.98.1',
      '188.114.99.1',
      ...WARP_IPS,
      WARP_HOST,
    ],
  };
  return dedupe([...(selectedHost ? [selectedHost] : []), ...pools[protocol]]);
}

/** The `host:port` a tunnel dials for a given endpoint. */
export function endpointFor(host: string): string {
  return host.includes(':') ? host : `${host}:${WARP_PORT}`;
}

/** The catalogue entry for a host, when the scanner reports one it knows. */
export function nodeForHost(host: string): NodeItem | undefined {
  return NODES.find((n) => n.host === host);
}

function dedupe(list: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    const key = item.trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item.trim());
  }
  return out;
}

/** Map an ISO country code from Cloudflare's trace to a flag emoji. */
export function flagFromCountryCode(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return '🌐';
  return String.fromCodePoint(...[...cc].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

/** A friendly country name for the common codes; falls back to the code itself. */
const COUNTRY_NAMES: Record<string, string> = {
  US: 'United States',
  GB: 'United Kingdom',
  DE: 'Germany',
  NL: 'Netherlands',
  FR: 'France',
  TR: 'Turkey',
  AE: 'United Arab Emirates',
  IN: 'India',
  SG: 'Singapore',
  JP: 'Japan',
  IR: 'Iran',
  CA: 'Canada',
  AU: 'Australia',
  BR: 'Brazil',
  RU: 'Russia',
  IT: 'Italy',
  ES: 'Spain',
  SE: 'Sweden',
  CH: 'Switzerland',
  PL: 'Poland',
  FI: 'Finland',
  NO: 'Norway',
  AT: 'Austria',
  BE: 'Belgium',
  IE: 'Ireland',
  PT: 'Portugal',
  RO: 'Romania',
  UA: 'Ukraine',
  IL: 'Israel',
  SA: 'Saudi Arabia',
  QA: 'Qatar',
  KW: 'Kuwait',
  OM: 'Oman',
  PK: 'Pakistan',
  AZ: 'Azerbaijan',
  AM: 'Armenia',
  GE: 'Georgia',
  CN: 'China',
  KR: 'South Korea',
  HK: 'Hong Kong',
  TW: 'Taiwan',
  TH: 'Thailand',
  MY: 'Malaysia',
  ID: 'Indonesia',
  VN: 'Vietnam',
  PH: 'Philippines',
  EG: 'Egypt',
  ZA: 'South Africa',
  NG: 'Nigeria',
  KE: 'Kenya',
  MA: 'Morocco',
  MX: 'Mexico',
  AR: 'Argentina',
  CL: 'Chile',
  CO: 'Colombia',
};

export function countryName(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  return COUNTRY_NAMES[cc] ?? (cc || 'Unknown');
}
