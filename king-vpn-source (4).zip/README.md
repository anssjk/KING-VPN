# King VPN

اپ اندرویدی **King VPN** — کلاینت Cloudflare با ظاهر مدرن (Expo / React Native + TypeScript).

نسخه: **1.3.0** · شناسه پکیج: `com.kingvpn.app`

## تغییرات نسخه ۱.۳.۰

- **رفع خطای `Connection reset` در کانفیگ‌های غیر وارپ.** ۱۶ آدرس از ۲۰ آدرس قبلی، سرویس `/cdn-cgi/trace` را
  روی IP خالی سرو نمی‌کردند و لبه‌ی کلادفلر آن‌ها را رد می‌کرد. لیست نودها با آدرس‌های تأییدشده جایگزین شد و
  منطق اتصال حالا یک لیست کاندید را به‌ترتیب امتحان می‌کند تا همیشه یکی وصل شود.
- **اسکنر کامل:** تأخیر، نوسان، درصد افت، چند نمونه، پیشرفت زنده، توقف، مرتب‌سازی، فیلتر و انتخاب سریع‌ترین.
- **آیکون جدید** (۱۰۲۴×۱۰۲۴ + adaptive) و **صفحه‌ی مجوز** برای اعلان و VPN هنگام ورود.

## ساخت APK بدون کامپیوتر (فقط با مرورگر گوشی)

این ریپازیتوری یک workflow آماده دارد: `.github/workflows/build-apk.yml`

۱. فایل `king-vpn-source.zip` را در ریشه‌ی همین ریپازیتوری آپلود کنید.
۲. فایل `.github/workflows/build-apk.yml` را اضافه کنید (اگر همراه زیپ نیامده).
۳. تب **Actions** → **Build King VPN APK** → **Run workflow**.
۴. بعد از چند دقیقه، APK در دو جا آماده است:
   - تب **Actions** → پایین صفحه → **Artifacts** → `king-vpn-apk`
   - بخش **Releases** در صفحه‌ی اصلی → `king-vpn.apk`

راهنمای کامل قدم‌به‌قدم فارسی: [`GITHUB_ACTIONS_GUIDE.md`](GITHUB_ACTIONS_GUIDE.md)

## ساخت با Expo (نیاز به کامپیوتر)

```bash
npm install
npm install -g eas-cli
eas login
eas init
eas build --platform android --profile preview
```

جزئیات بیشتر (آیفون، گوگل پلی، تنظیمات): [`BUILD_GUIDE.md`](BUILD_GUIDE.md)

## اجرا در حالت توسعه

```bash
npm install
npx expo start
```

سپس با اپ **Expo Go** روی گوشی، کد QR را اسکن کنید.

## ساختار پروژه

```
src/app/            صفحه‌ها (expo-router)
  onboarding.tsx    ورود سه‌مرحله‌ای
  (tabs)/index.tsx  صفحه اصلی: اتصال، آی‌پی/کشور، پینگ، پروتکل
  (tabs)/nodes.tsx  نودها، پروتکل‌ها، اسکنر آی‌پی
  (tabs)/about.tsx  چنل تلگرام، آیدی توسعه‌دهنده، زبان، تم
src/components/     کامپوننت‌های ظاهری (کره اتصال، پس‌زمینه شفق، کارت شیشه‌ای)
src/lib/            منطق: cloudflare، nodes، i18n، تنظیمات
```

## نکته

در مرحله‌ی دوم آنبوردینگ، لینک «دریافت توکن از کلادفلر» یک **لینک قالب رسمی Cloudflare** باز می‌کند که نام توکن را از پیش با مقدار «KING VPN» پر می‌کند؛
کاربر فقط دکمه‌ی **Create Token** را می‌زند و نیازی به تایپ نام ندارد.

این اپ یک کلاینت/داشبورد واقعی Cloudflare است: آی‌پی و کشور را از `cdn-cgi/trace` می‌خواند،
پینگ را واقعی اندازه می‌گیرد و توکن را با API رسمی Cloudflare بررسی می‌کند. تونل سیستمی VPN
نمی‌سازد — ساخت تونل واقعی WARP/Psiphon به کد نیتیو خارج از Expo نیاز دارد.
