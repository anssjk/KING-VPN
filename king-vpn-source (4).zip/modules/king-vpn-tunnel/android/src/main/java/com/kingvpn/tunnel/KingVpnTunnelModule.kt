package com.kingvpn.tunnel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import expo.modules.kotlin.activityresult.AppContextActivityResultContract
import expo.modules.kotlin.activityresult.AppContextActivityResultLauncher
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.functions.Coroutine
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.KeyPair
import java.net.InetAddress

/**
 * The real Android VPN tunnel.
 *
 * This module is what makes King VPN an actual VPN client instead of a connectivity
 * tester. It owns three things the JavaScript layer cannot do on its own:
 *
 *  1. **The system consent dialog.** Android only grants VPN rights through
 *     `VpnService.prepare()`, which returns an Intent the *activity* must launch. That
 *     Intent is the "Connection request" dialog the user sees. We launch it through
 *     Expo's activity-result registry so the answer comes back to JavaScript.
 *  2. **The tunnel itself.** `GoBackend` from `com.wireguard.android:tunnel` creates a
 *     real TUN interface through `android.net.VpnService` and runs the userspace
 *     WireGuard implementation (`libwg-go`) inside it. Traffic genuinely leaves the
 *     phone through the peer endpoint.
 *  3. **Live tunnel state.** Handshake time and byte counters come from the backend, so
 *     the UI can show whether the tunnel is really up rather than assuming it.
 *
 * Nothing here reports success it did not observe: `connectAsync` resolves only after
 * the backend reports the tunnel UP, and every failure is surfaced with its real reason.
 */
class KingVpnTunnelModule : Module() {

  private val context: Context
    get() = appContext.reactContext ?: throw CodedException("React context is not available")

  /** The single tunnel this app manages. WireGuard allows one active tunnel per backend. */
  private val tunnel = KingTunnel()

  private var backend: Backend? = null

  /** Assigned by the activity-result registry once an Activity is available. */
  private var vpnPermissionLauncher: AppContextActivityResultLauncher<String, Boolean>? = null

  /** Lazily created so a missing native library surfaces as a clean error, not a crash. */
  private fun backend(): Backend {
    backend?.let { return it }
    val created = GoBackend(context)
    backend = created
    return created
  }

  override fun definition() = ModuleDefinition {
    Name("KingVpnTunnel")

    Events("onTunnelStateChange")

    /**
     * Register the consent-dialog launcher. `VpnService.prepare()`'s Intent must be
     * started from an Activity, so it goes through Expo's activity-result registry.
     */
    RegisterActivityContracts {
      vpnPermissionLauncher = registerForActivityResult(VpnPermissionContract())
    }

    /** True when Android has already granted this app the VPN permission. */
    AsyncFunction("isPreparedAsync") {
      // null means "already authorized"; a non-null Intent means consent is still needed.
      VpnService.prepare(context) == null
    }

    /**
     * Show the real system VPN consent dialog and resolve with the user's answer.
     * Resolves `true` only when Android actually granted the permission.
     */
    AsyncFunction("requestPermissionAsync") Coroutine { ->
      if (VpnService.prepare(context) == null) {
        return@Coroutine true
      }
      val launcher = vpnPermissionLauncher
        ?: throw CodedException("The VPN consent dialog is not ready yet. Try again in a moment.")
      launcher.launch("")
    }

    /** Generate a WireGuard key pair with the library's constant-time implementation. */
    AsyncFunction("generateKeyPairAsync") {
      val pair = KeyPair()
      mapOf(
        "privateKey" to pair.privateKey.toBase64(),
        "publicKey" to pair.publicKey.toBase64()
      )
    }

    /**
     * Bring the tunnel up.
     *
     * `config` carries the WireGuard parameters (private key, addresses, peer). The call
     * resolves only once the backend reports the tunnel UP; if the permission is missing
     * or the config is rejected, it rejects with the real reason.
     */
    AsyncFunction("connectAsync") Coroutine { config: Map<String, Any?> ->
      if (VpnService.prepare(context) != null) {
        throw VpnPermissionMissingException()
      }
      val wgConfig = buildConfig(config)
      val state = backend().setState(tunnel, Tunnel.State.UP, wgConfig)
      if (state != Tunnel.State.UP) {
        throw TunnelStartException("The tunnel did not come up (state: $state).")
      }
      // Keep the process alive so Android does not reclaim the tunnel in the background.
      try {
        KingVpnForegroundService.start(context)
      } catch (e: Exception) {
        // The tunnel is up; a missing notification must not tear it down.
      }
      sendEvent("onTunnelStateChange", mapOf("state" to "UP"))
      true
    }

    /** Tear the tunnel down. Safe to call when it is already down. */
    AsyncFunction("disconnectAsync") Coroutine { ->
      try {
        backend().setState(tunnel, Tunnel.State.DOWN, null)
      } finally {
        try {
          KingVpnForegroundService.stop(context)
        } catch (e: Exception) {
          // Already stopped.
        }
        sendEvent("onTunnelStateChange", mapOf("state" to "DOWN"))
      }
      true
    }

    /**
     * The tunnel's real state plus traffic counters.
     *
     * `latestHandshakeMs` is the strongest signal that the tunnel is genuinely working:
     * it only becomes non-zero after a successful cryptographic handshake with the peer.
     */
    AsyncFunction("getStatusAsync") {
      val be = backend()
      val state = be.getState(tunnel)
      val stats = try {
        be.getStatistics(tunnel)
      } catch (e: Exception) {
        null
      }
      val peerKey = try {
        stats?.peers()?.firstOrNull()
      } catch (e: Exception) {
        null
      }
      val peerStats = if (peerKey != null) {
        try {
          stats?.peer(peerKey)
        } catch (e: Exception) {
          null
        }
      } else {
        null
      }
      mapOf(
        "state" to state.name,
        "rxBytes" to (peerStats?.rxBytes ?: 0L),
        "txBytes" to (peerStats?.txBytes ?: 0L),
        "latestHandshakeMs" to (peerStats?.latestHandshakeEpochMillis ?: 0L),
        "version" to (try { be.version } catch (e: Exception) { "" })
      )
    }

    /**
     * Measure one endpoint's reachability and round-trip time.
     *
     * A WARP endpoint does not answer HTTPS on a bare IP (the edge needs the right SNI),
     * so an HTTP probe reports a false failure. A TCP connect to port 443 measures what
     * actually matters — whether this anycast range is reachable from the current
     * network — and its handshake time is a fair latency figure. Runs off the JS thread.
     */
    AsyncFunction("probeAsync") Coroutine { host: String, port: Int, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        socket = java.net.Socket()
        socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        mapOf(
          "ok" to true,
          "ms" to (System.currentTimeMillis() - started).toInt(),
          "error" to null
        )
      } catch (e: Exception) {
        mapOf(
          "ok" to false,
          "ms" to 0,
          "error" to (e.message ?: e.javaClass.simpleName)
        )
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    OnDestroy {
      try {
        backend?.setState(tunnel, Tunnel.State.DOWN, null)
      } catch (_: Exception) {
        // Nothing to do: the process is going away and the system drops the tunnel.
      }
      try {
        KingVpnForegroundService.stop(context)
      } catch (_: Exception) {
        // Already stopped.
      }
    }
  }

  /**
   * Turn the JavaScript config map into a WireGuard `Config`.
   *
   * Every field is validated by the library, so a malformed key or address produces a
   * precise `BadConfigException` instead of a tunnel that silently fails to pass traffic.
   */
  private fun buildConfig(raw: Map<String, Any?>): Config {
    val privateKey = raw["privateKey"] as? String
      ?: throw CodedException("privateKey is required")
    val peerPublicKey = raw["peerPublicKey"] as? String
      ?: throw CodedException("peerPublicKey is required")
    val endpoint = raw["endpoint"] as? String
      ?: throw CodedException("endpoint is required")

    val addresses = (raw["addresses"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val dns = (raw["dns"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val allowedIps = (raw["allowedIps"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val mtu = (raw["mtu"] as? Number)?.toInt() ?: 1280
    val keepalive = (raw["persistentKeepalive"] as? Number)?.toInt() ?: 25

    try {
      val ifaceBuilder = Interface.Builder()
        .parsePrivateKey(privateKey)
        .setMtu(mtu)

      for (address in addresses) {
        ifaceBuilder.addAddress(InetNetwork.parse(address))
      }
      for (server in dns) {
        ifaceBuilder.addDnsServer(InetAddress.getByName(server))
      }

      val peerBuilder = Peer.Builder()
        .parsePublicKey(peerPublicKey)
        .parseEndpoint(endpoint)
        .setPersistentKeepalive(keepalive)

      for (allowed in allowedIps) {
        peerBuilder.addAllowedIp(InetNetwork.parse(allowed))
      }

      return Config.Builder()
        .setInterface(ifaceBuilder.build())
        .addPeer(peerBuilder.build())
        .build()
    } catch (e: BadConfigException) {
      throw CodedException("Invalid WireGuard configuration: ${e.message}")
    } catch (e: Exception) {
      throw CodedException("Could not build the tunnel configuration: ${e.message}")
    }
  }
}

/** The tunnel identity the backend tracks. One instance, one name. */
private class KingTunnel : Tunnel {
  override fun getName(): String = "kingvpn"

  override fun onStateChange(newState: Tunnel.State) {
    // The module pushes state to JavaScript from connect/disconnect, where the call
    // context is known; this callback exists because the interface requires it.
  }
}

/**
 * Launches `VpnService.prepare()`'s Intent and reports whether the user allowed it.
 *
 * `Activity.RESULT_OK` is the only outcome that means the permission was granted; a
 * back-press or "Cancel" comes back as `RESULT_CANCELED` and must not be treated as
 * success.
 */
private class VpnPermissionContract : AppContextActivityResultContract<String, Boolean> {

  override fun createIntent(context: Context, input: String): Intent {
    // prepare() is guaranteed non-null here: the caller checks it before launching.
    return VpnService.prepare(context) ?: Intent()
  }

  override fun parseResult(input: String, resultCode: Int, intent: Intent?): Boolean {
    return resultCode == Activity.RESULT_OK
  }
}

class VpnPermissionMissingException :
  CodedException("Android has not granted VPN permission. Accept the system connection request first.")

class TunnelStartException(message: String) : CodedException(message)
