# KING VPN — رفع خطای بیلد APK (نسخه ۲)

## خلاصه

بیلد در مرحله‌ی Gradle با `BUILD FAILED in 54s` شکست می‌خورد. علت اصلی، **ناسازگاری نسخه‌ی
`react-native-worklets` با `expo-modules-core`** بود — نه minSdk.

---

## خطای واقعی

`expo-modules-core@57.0.26` در `package.json` خودش این محدوده‌ی peer را اعلام می‌کند:

```
"react-native-worklets": "^0.7.4 || ^0.8.0 || ^0.9.0 || ^0.10.0"
```

اما پروژه `react-native-worklets@0.13.1` نصب کرده بود (که `react-native-reanimated@4.7.1`
به آن نیاز دارد). این نسخه **بیرون** از محدوده‌ی مجاز است.

### چرا این کار را می‌شکند

`expo-modules-core` در `android/cmake/main.cmake` (خط ۷۰ به بعد) این کار را می‌کند:

```cmake
if (REACT_NATIVE_WORKLETS_DIR)
  find_package(react-native-worklets CONFIG QUIET)
  if (react-native-worklets_FOUND)
    target_link_libraries(expo-modules-core PRIVATE react-native-worklets::worklets)
  else ()
    add_library(worklets SHARED IMPORTED)
    set_target_properties(worklets PROPERTIES
      IMPORTED_LOCATION
      "${REACT_NATIVE_WORKLETS_DIR}/android/build/intermediates/cmake/${BUILD_TYPE}/obj/${ANDROID_ABI}/libworklets.so")
  endif ()
endif ()
```

با نسخه‌ی ناسازگار، مسیر `libworklets.so` ساخته نمی‌شود و لینک‌کردن با خطای
`... file or directory)` شکست می‌خورد — همان چیزی که در اسکرین‌شات دیده می‌شود.

همچنین `expo-modules-core/android/build.gradle` (خط ۶۵–۷۵) به‌صورت مستقیم به
تسک‌های پروژه‌ی `:react-native-worklets` وابسته می‌شود:

```groovy
def workletsProject = enableWorkletsIntegration ? findProject(":react-native-worklets") : null
if (workletsProject != null) {
  evaluationDependsOn(workletsProject.path)
  tasks.getByName("buildCMakeDebug").dependsOn(workletsProject.tasks.getByName("mergeDebugNativeLibs"))
}
```

---

## اصلاحات

### ۱) `package.json` — هم‌تراز کردن نسخه‌ها با Expo SDK 57

نسخه‌های درست از `node_modules/expo/bundledNativeModules.json` گرفته شده‌اند (منبع رسمی Expo):

| پکیج | قبل | بعد |
|---|---|---|
| `react-native-worklets` | `0.13.1` (غیرمستقیم) | `0.10.1` |
| `react-native-reanimated` | `4.7.1` (غیرمستقیم) | `4.5.1` |

`react-native-reanimated@4.5.1` دقیقاً به `react-native-worklets@0.10.x` نیاز دارد، پس هر دو
با هم سازگارند و با `expo-modules-core@57.0.26` هم منطبق‌اند.

### ۲) `package-lock.json` بازتولید شد

ورک‌فلو با `npm ci` نصب می‌کند؛ `npm ci` اگر lockfile با `package.json` هم‌خوان نباشد
متوقف می‌شود. lockfile جدید با `npm install` ساخته شد.

### ۳) `modules/king-vpn-tunnel/android/build.gradle` — پین کردن صریح SDK

`expo-module-gradle-plugin` مقدار minSdk را از `rootProject.extra.minSdkVersion` می‌خواند و
اگر پیدا نکند **به ۲۴ برمی‌گردد**. چون `hev.aar` (hev-socks5-tunnel 2.20.0) خودش minSdk 29
اعلام می‌کند، این باعث خطای manifest merger می‌شد. حالا مستقیماً در ماژول تعیین شده:

```groovy
android {
  namespace "com.kingvpn.tunnel"
  compileSdk 36
  defaultConfig {
    minSdk 29
    targetSdk 36
    ...
  }
}
```

این کار مستقل از نحوه‌ی resolve شدن version catalog درست کار می‌کند.

### ۴) ورک‌فلو — دیگر خطا را قورت نمی‌دهد

دو مشکل در `.github/workflows/build-apk.yml` بود:

**الف)** این خط خطای واقعی را پنهان می‌کرد:

```bash
./gradlew assembleRelease --no-daemon || echo "Release build failed, trying a debug build"
```

`|| echo` باعث می‌شد شکستِ release نادیده گرفته شود و بعد یک بیلد debug هم شکست بخورد —
در نتیجه لاگ فقط دنباله‌ی بی‌معنی نشان می‌داد. حالا:

```bash
set +e
./gradlew assembleRelease --no-daemon 2>&1 | tee /tmp/gradle-release.log
RELEASE_STATUS=${PIPESTATUS[0]}
set -e
if [ "$RELEASE_STATUS" -ne 0 ]; then
  grep -nE "What went wrong|^e: |error:|Caused by|FAILURE:|No such file|Execution failed" /tmp/gradle-release.log | head -40
  exit "$RELEASE_STATUS"
fi
```

**ب)** یک مرحله‌ی جدید «Check dependency consistency» اضافه شد که قبل از بیلد،
`npm ls --all` را بررسی می‌کند و اگر `ELSPROBLEMS` (peer dependency نامعتبر) وجود داشت،
با پیام واضح متوقف می‌شود — دقیقاً همان چیزی که این بار اتفاق افتاد.

---

## بررسی‌هایی که انجام شد

| بررسی | نتیجه |
|---|---|
| `npm install` | ✅ بدون خطا، ۶۱۴ پکیج |
| `npm ls --all` | ✅ بدون `ELSPROBLEMS` (قبلاً `react-native-worklets@0.13.1 invalid` بود) |
| `npm ci --dry-run` | ✅ lockfile هم‌خوان است |
| `npx tsc --noEmit` | ✅ بدون خطا |
| `npx expo export --platform android` | ✅ باندل Hermes ساخته شد (۳.۱ مگابایت) |
| `npx expo config --type prebuild` | ✅ پلاگین‌ها resolve می‌شوند |
| `expo-modules-autolinking resolve` | ✅ ماژول `king-vpn-tunnel` شناسایی می‌شود |
| SHA-256 هر دو AAR | ✅ با مقادیر پین‌شده در ورک‌فلو مطابقت دارد |
| API کاتلین ماژول | ✅ با WireGuard / libv2ray / hev / expo-modules-core 57 تطبیق داده شد |

## آنچه بررسی نشد

APK در این محیط ساخته نمی‌شود (هیچ ابزار اندروید یا گوشی‌ای اینجا نیست)، پس **خودِ بیلد
Gradle اجرا نشد**. زنجیره‌ی پیکربندی، وابستگی‌ها، تایپ‌چک و باندل JS بررسی شدند؛ بیلد واقعی
روی GitHub Actions انجام می‌شود.

## قدم بعدی

فایل `king-vpn-source-fixed-v2.zip` را دانلود کنید، محتوایش را در ریپازیتوری GitHub
جایگزین کنید و push کنید. ورک‌فلو خودش APK را می‌سازد و در **Releases** می‌گذارد.

> **نکته:** با minSdk = 29، اپ روی اندروید ۱۰ (API 29) و بالاتر نصب می‌شود.
