import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import { connectThrough, describeError, fetchTrace, pingHost, type ConnectAttempt } from '@/lib/cloudflare';
import {
  NODES,
  WARP_PORT,
  WARP_SNI,
  endpointFor,
  maskEndpoint,
  resolveEndpoint,
  type NodeItem,
  type Protocol,
  type ResolvedEndpoint,
} from '@/lib/nodes';
import { ensureRegistration, clearRegistration, type WarpRegistration } from '@/lib/warp';
import {
  connectTunnel,
  disconnectTunnel,
  getTunnelStatus,
  isAvailable as tunnelAvailable,
  isPrepared,
  requestVpnPermission,
  unavailableReason,
  type TunnelStatus,
} from '@/lib/tunnel';
import { usePersistentState } from '@/hooks/use-persistent-state';

export type ConnStatus = 'disconnected' | 'connecting' | 'connected';

type AppValue = {
  // Onboarding / account
  token: string;
  setToken: (t: string) => void;
  deployed: boolean;
  setDeployed: (v: boolean) => void;
  /** False until the stored values have loaded, so the router does not flash a screen. */
  ready: boolean;
  // Selection
  protocol: Protocol;
  setProtocol: (p: Protocol) => void;
  selectedNodeId: string;
  setSelectedNodeId: (id: string) => void;
  selectedNode: NodeItem;
  /**
   * The endpoint the tunnel will dial: address, port and SNI.
   *
   * This is the single source of truth for the connection. When the scanner picks a
   * node, its measured address and port land here and are used verbatim by the tunnel
   * config — no field is re-derived from the catalogue afterwards.
   */
  resolvedEndpoint: ResolvedEndpoint;
  /** A display-safe label for the endpoint (the raw address is never rendered). */
  endpointLabel: string;
  /** Select an arbitrary host found by the scanner (not in the built-in catalogue). */
  selectHost: (host: string, port?: number, sni?: string) => void;
  // Live connection
  status: ConnStatus;
  pingMs: number | null;
  /** The public IP the tunnel is presenting, read after it comes up. */
  publicIp: string | null;
  error: string | null;
  /** Technical detail behind `error`, for the support channel. */
  errorDetail: string | null;
  /** Which endpoint actually carried the session. */
  activeHost: string | null;
  /** Progress while connecting: "trying 2 of 9". */
  attempt: { index: number; total: number; host: string } | null;
  /** Endpoints tried before the successful one. */
  fallbackLog: ConnectAttempt[];
  /** Live tunnel counters from the native backend. */
  tunnel: TunnelStatus | null;
  /** True when this build can actually create a VPN (false in Expo Go / web). */
  canTunnel: boolean;
  /** Why the tunnel is unavailable, when it is. */
  tunnelUnavailableReason: string | null;
  /** True once Android has granted the VPN permission. */
  vpnGranted: boolean;
  /** Ask Android for the VPN permission (shows the real system dialog). */
  requestVpn: () => Promise<boolean>;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  runPing: () => Promise<void>;
  /** Forget the WARP device and register a fresh one on the next connect. */
  resetRegistration: () => Promise<void>;
  reset: () => void;
};

const AppContext = createContext<AppValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = usePersistentState<string>('cf_token', '');
  const [deployed, setDeployed, deployedStatus] = usePersistentState<boolean>('deployed', false);
  const [protocol, setProtocol] = usePersistentState<Protocol>('protocol', 'warp');
  const [selectedNodeId, setSelectedNodeId] = usePersistentState<string>('node_id', 'warp-auto');
  // A host picked from the scanner that is not part of the built-in catalogue.
  const [customHost, setCustomHost] = usePersistentState<string>('custom_host', '');
  // The port and SNI the scanner measured for that host. Kept alongside it so a restart
  // reconnects to the same address:port instead of falling back to the default port.
  const [customPort, setCustomPort] = usePersistentState<number>('custom_port', WARP_PORT);
  const [customSni, setCustomSni] = usePersistentState<string>('custom_sni', WARP_SNI);

  const [status, setStatus] = useState<ConnStatus>('disconnected');
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [publicIp, setPublicIp] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState<string | null>(null);
  const [activeHost, setActiveHost] = useState<string | null>(null);
  const [attempt, setAttempt] = useState<{ index: number; total: number; host: string } | null>(null);
  const [fallbackLog, setFallbackLog] = useState<ConnectAttempt[]>([]);
  const [tunnel, setTunnel] = useState<TunnelStatus | null>(null);
  const [vpnGranted, setVpnGranted] = useState(false);

  const registrationRef = useRef<WarpRegistration | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const selectedNode = useMemo(() => {
    const found = NODES.find((n) => n.id === selectedNodeId);
    if (found) return found;
    // A scanner result: present it as a node so every screen can render it.
    if (customHost) {
      return {
        id: `scan-${customHost}`,
        // The name is a masked label: the raw address is an operational detail and is
        // never shown on screen.
        name: maskEndpoint(customHost),
        country: 'Scanned endpoint',
        countryCode: 'CF',
        flag: '📡',
        protocol: 'ip' as Protocol,
        host: customHost,
        kind: 'host' as const,
        basePing: 0,
        note: 'Found by the scanner',
      } satisfies NodeItem;
    }
    return NODES[0];
  }, [selectedNodeId, customHost]);

  /**
   * The endpoint the tunnel dials.
   *
   * For a scanned node this is exactly what the scanner measured — address, port and
   * SNI. For a catalogue node it is the catalogue address on the tunnel port. Either
   * way the tunnel config is built from this object and nothing else.
   */
  const resolvedEndpoint = useMemo<ResolvedEndpoint>(() => {
    if (customHost) {
      return resolveEndpoint(customHost, customPort, customSni || WARP_SNI);
    }
    return resolveEndpoint(selectedNode.host, WARP_PORT, WARP_SNI);
  }, [customHost, customPort, customSni, selectedNode]);

  const endpointLabel = useMemo(() => maskEndpoint(resolvedEndpoint.host), [resolvedEndpoint]);

  // Read the real permission state once, so the UI never claims a permission it lacks.
  useEffect(() => {
    let alive = true;
    isPrepared().then((granted) => {
      if (alive) setVpnGranted(granted);
    });
    return () => {
      alive = false;
    };
  }, []);

  // Poll the native backend while connected, so the counters and handshake time are live.
  useEffect(() => {
    if (status !== 'connected') {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
      return;
    }
    const tick = async () => {
      const next = await getTunnelStatus();
      if (next) {
        setTunnel(next);
        // The backend is the authority: if it says DOWN, the tunnel really is down.
        if (next.state === 'DOWN') {
          setStatus('disconnected');
          setActiveHost(null);
        }
      }
    };
    void tick();
    pollRef.current = setInterval(tick, 2000);
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [status]);

  const selectHost = useCallback(
    (host: string, port: number = WARP_PORT, sni: string = WARP_SNI) => {
      const existing = NODES.find((n) => n.host === host);
      if (existing) {
        setCustomHost('');
        setCustomPort(WARP_PORT);
        setCustomSni(WARP_SNI);
        setSelectedNodeId(existing.id);
        return;
      }
      // Keep the measured port and SNI with the host, so the tunnel dials the exact
      // address:port the scanner reached rather than a default.
      setCustomHost(host);
      setCustomPort(port);
      setCustomSni(sni);
      setSelectedNodeId(`scan-${host}`);
    },
    [setCustomHost, setCustomPort, setCustomSni, setSelectedNodeId],
  );

  const requestVpn = useCallback(async () => {
    const granted = await requestVpnPermission();
    setVpnGranted(granted);
    return granted;
  }, []);

  const connect = useCallback(async () => {
    setError(null);
    setErrorDetail(null);
    setFallbackLog([]);
    setAttempt(null);
    setPublicIp(null);

    if (!tunnelAvailable) {
      setError(unavailableReason() ?? 'The VPN module is not available in this build.');
      setStatus('disconnected');
      return;
    }

    setStatus('connecting');
    try {
      // 1. Android's own consent dialog. Without this the tunnel cannot be created.
      if (!(await isPrepared())) {
        const granted = await requestVpnPermission();
        setVpnGranted(granted);
        if (!granted) {
          setError('VPN permission was not granted. Accept the system request to connect.');
          setStatus('disconnected');
          return;
        }
      } else {
        setVpnGranted(true);
      }

      // 2. Pick an endpoint that actually answers on this network.
      //    The selected endpoint is tried first, on the exact port the scanner measured.
      const picked = await connectThrough(
        protocol,
        resolvedEndpoint.host,
        (a, index, total) => {
          setAttempt({ index, total, host: a.host });
          if (!a.ok) {
            setFallbackLog((prev) => [...prev, a]);
          }
        },
        resolvedEndpoint.port,
      );

      // 3. Register with WARP (cached after the first time) and build the tunnel config.
      const registration = registrationRef.current ?? (await ensureRegistration());
      registrationRef.current = registration;

      // 4. Bring the real tunnel up. This resolves only once the backend reports UP.
      //
      //    Every address-bearing field comes from `picked.endpoint`, which is the
      //    scanner's own result: the same IP, the same port, and the SNI that address
      //    must be presented as. Nothing here is re-derived from the catalogue, so the
      //    tunnel dials exactly what was measured.
      const target = picked.endpoint;
      const isIpLiteral = /^\d{1,3}(\.\d{1,3}){3}$/.test(target.host);
      await connectTunnel({
        privateKey: registration.privateKey,
        peerPublicKey: registration.peerPublicKey,
        endpoint: endpointFor(target.host, target.port),
        sni: target.sni,
        addresses: registration.addresses,
        // DNS goes to the same edge the tunnel dials, so name resolution takes the
        // measured path too. A hostname cannot be a DNS server, so fall back to the
        // public resolver in that one case.
        dns: isIpLiteral ? [target.host] : ['1.1.1.1', '1.0.0.1'],
        allowedIps: ['0.0.0.0/0', '::/0'],
        mtu: 1280,
        persistentKeepalive: 25,
      });

      setActiveHost(target.host);
      setStatus('connected');
      setAttempt(null);

      // 5. Read the public IP *through* the tunnel — proof it is carrying traffic.
      //    The trace request goes out over the tunnel interface, so the address it
      //    reports is the one the internet sees, not the phone's own.
      try {
        const trace = await fetchTrace('1.1.1.1');
        setPublicIp(trace.ip);
      } catch {
        // The tunnel is up; a failed trace only means we cannot show the exit IP.
        setPublicIp(null);
      }
      const probe = await pingHost(target.host, 1, undefined, target.port);
      setPingMs(probe.ok ? probe.ms : null);
      const status = await getTunnelStatus();
      if (status) setTunnel(status);
    } catch (e) {
      const { message, detail } = describeError(e);
      setError(message);
      setErrorDetail(detail);
      setStatus('disconnected');
      setAttempt(null);
      // A failed start can leave a half-open tunnel; make sure it is down.
      try {
        await disconnectTunnel();
      } catch {
        // Already down.
      }
    }
  }, [protocol, resolvedEndpoint]);

  const disconnect = useCallback(async () => {
    try {
      await disconnectTunnel();
    } catch {
      // Nothing to tear down.
    }
    setStatus('disconnected');
    setError(null);
    setErrorDetail(null);
    setActiveHost(null);
    setAttempt(null);
    setPublicIp(null);
    setTunnel(null);
  }, []);

  const runPing = useCallback(async () => {
    const p = await pingHost(resolvedEndpoint.host, 3, undefined, resolvedEndpoint.port);
    setPingMs(p.ok ? p.ms : null);
  }, [resolvedEndpoint]);

  const resetRegistration = useCallback(async () => {
    registrationRef.current = null;
    await clearRegistration();
  }, []);

  const reset = useCallback(() => {
    setDeployed(false);
    setStatus('disconnected');
    setPingMs(null);
    setPublicIp(null);
    setActiveHost(null);
    setError(null);
    setErrorDetail(null);
  }, [setDeployed]);

  const value = useMemo<AppValue>(
    () => ({
      token,
      setToken,
      deployed,
      setDeployed,
      ready: deployedStatus !== 'loading',
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      resolvedEndpoint,
      endpointLabel,
      selectHost,
      status,
      pingMs,
      publicIp,
      error,
      errorDetail,
      activeHost,
      attempt,
      fallbackLog,
      tunnel,
      canTunnel: tunnelAvailable,
      tunnelUnavailableReason: unavailableReason(),
      vpnGranted,
      requestVpn,
      connect,
      disconnect,
      runPing,
      resetRegistration,
      reset,
    }),
    [
      token,
      setToken,
      deployed,
      setDeployed,
      deployedStatus,
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      resolvedEndpoint,
      endpointLabel,
      selectHost,
      status,
      pingMs,
      publicIp,
      error,
      errorDetail,
      activeHost,
      attempt,
      fallbackLog,
      tunnel,
      vpnGranted,
      requestVpn,
      connect,
      disconnect,
      runPing,
      resetRegistration,
      reset,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return value;
}
