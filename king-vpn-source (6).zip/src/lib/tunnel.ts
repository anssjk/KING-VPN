/**
 * Typed bridge to the native Android tunnel module (`modules/king-vpn-tunnel`).
 *
 * The native side owns the real `android.net.VpnService`; this file only describes its
 * shape and degrades cleanly on platforms that have no tunnel (web, iOS, Expo Go).
 *
 * `isAvailable` is the single source of truth for "can this build actually create a
 * VPN?". Expo Go and the web preview cannot, because they have no custom native code —
 * so the UI must say so instead of pretending to connect.
 */
import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';

export type TunnelState = 'UP' | 'DOWN' | 'TOGGLE';

export type TunnelStatus = {
  state: TunnelState;
  rxBytes: number;
  txBytes: number;
  /** Epoch millis of the last successful handshake; 0 means none yet. */
  latestHandshakeMs: number;
  version: string;
};

export type WireGuardConfig = {
  privateKey: string;
  peerPublicKey: string;
  /** `host:port` of the peer. */
  endpoint: string;
  /**
   * TLS server name for the peer address.
   *
   * WireGuard itself is not TLS, so this is not part of the tunnel handshake. It is
   * carried here because the same resolved endpoint is used for the TLS reachability
   * probe and for any TLS-based transport, and because the native side logs it so a
   * support report shows which name the address was validated against.
   */
  sni?: string;
  /** Interface addresses, e.g. `172.16.0.2/32`. */
  addresses: string[];
  dns: string[];
  allowedIps: string[];
  mtu?: number;
  persistentKeepalive?: number;
};

type NativeTunnelModule = {
  isPreparedAsync(): Promise<boolean>;
  requestPermissionAsync(): Promise<boolean>;
  generateKeyPairAsync(): Promise<{ privateKey: string; publicKey: string }>;
  connectAsync(config: WireGuardConfig): Promise<boolean>;
  disconnectAsync(): Promise<boolean>;
  getStatusAsync(): Promise<TunnelStatus>;
  probeAsync(host: string, port: number, timeoutMs: number): Promise<ProbeResult>;
  probeTlsAsync(host: string, port: number, sni: string, timeoutMs: number): Promise<ProbeResult>;
};

export type ProbeResult = {
  ok: boolean;
  ms: number;
  error: string | null;
  /** The port that actually answered, when one did. */
  port?: number;
};

const native = requireOptionalNativeModule<NativeTunnelModule>('KingVpnTunnel');

/** True only on an Android build that actually contains the tunnel module. */
export const isAvailable = Platform.OS === 'android' && native != null;

/** Why the tunnel is unavailable, for the UI to explain instead of failing silently. */
export function unavailableReason(): string | null {
  if (isAvailable) return null;
  if (Platform.OS === 'android') {
    return 'This build has no native VPN module. Build a development or release APK (Expo Go cannot create a VPN).';
  }
  return 'The VPN tunnel is Android-only in this build.';
}

function requireModule(): NativeTunnelModule {
  if (!native) {
    throw new Error(unavailableReason() ?? 'The VPN module is not available.');
  }
  return native;
}

/** True when Android has already granted the VPN permission. */
export async function isPrepared(): Promise<boolean> {
  if (!native) return false;
  try {
    return await native.isPreparedAsync();
  } catch {
    return false;
  }
}

/**
 * Show the real system "Connection request" dialog.
 * Resolves true only when the user actually allowed it.
 */
export async function requestVpnPermission(): Promise<boolean> {
  if (!native) return false;
  return native.requestPermissionAsync();
}

export async function generateKeyPair(): Promise<{ privateKey: string; publicKey: string }> {
  return requireModule().generateKeyPairAsync();
}

/** Bring the tunnel up. Resolves only once the backend reports it UP. */
export async function connectTunnel(config: WireGuardConfig): Promise<boolean> {
  return requireModule().connectAsync(config);
}

export async function disconnectTunnel(): Promise<boolean> {
  if (!native) return true;
  return native.disconnectAsync();
}

export async function getTunnelStatus(): Promise<TunnelStatus | null> {
  if (!native) return null;
  try {
    return await native.getStatusAsync();
  } catch {
    return null;
  }
}

/**
 * Measure one endpoint with a real TCP connect.
 *
 * This is the scanner's probe. It works on bare anycast IPs, where an HTTPS request
 * would fail for lack of the right SNI and report a false negative.
 *
 * The port is the one the tunnel will dial, so the latency the user sees is the latency
 * of the path the tunnel actually takes. When that port is filtered on the local network
 * the probe retries on 443 purely to tell "host is down" apart from "this port is
 * blocked"; the reported `port` stays the tunnel port either way.
 */
export async function probeEndpoint(
  host: string,
  port = 2408,
  timeoutMs = 4000,
  sni?: string,
): Promise<ProbeResult> {
  if (!native) {
    return { ok: false, ms: 0, error: 'The native probe is unavailable in this build.' };
  }
  try {
    // When a server name is supplied, probe with a real TLS handshake that presents it.
    // That is the only probe that proves the address, the port *and* the SNI agree —
    // which is exactly the triple the tunnel config is built from.
    if (sni) {
      const tls = await native.probeTlsAsync(host, port, sni, timeoutMs);
      if (tls.ok) return { ...tls, port };
      if (port !== 443) {
        const tls443 = await native.probeTlsAsync(host, 443, sni, timeoutMs);
        if (tls443.ok) return { ...tls443, port };
      }
      return { ...tls, port };
    }
    const primary = await native.probeAsync(host, port, timeoutMs);
    if (primary.ok) return { ...primary, port };
    if (port !== 443) {
      const fallback = await native.probeAsync(host, 443, timeoutMs);
      if (fallback.ok) return { ...fallback, port };
    }
    return { ...primary, port };
  } catch (e) {
    return { ok: false, ms: 0, error: e instanceof Error ? e.message : String(e), port };
  }
}
