/**
 * Runtime permissions.
 *
 * Two permissions matter to a VPN client, and they are requested in different ways:
 *
 *  - **Notifications** — a normal Android runtime permission. `expo-notifications` asks
 *    for it and reports the answer, so the app can show a real Allow / Don't allow
 *    dialog and remember the choice.
 *  - **VPN** — Android never grants this from a normal permission prompt. The system
 *    shows its own consent dialog ("Connection request") when a `VpnService` calls
 *    `VpnService.prepare()`. A JavaScript-only app has no `VpnService`, so the honest
 *    thing is to open the system VPN screen where the user can review and allow the
 *    connection, and to declare the service permission in `app.json` so a native
 *    `VpnService` added later is already allowed to run.
 *
 * Nothing here pretends a permission was granted when it was not: every function
 * returns the real state it observed.
 */
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as IntentLauncher from 'expo-intent-launcher';

export type PermissionState = 'granted' | 'denied' | 'undetermined' | 'unavailable';

export type PermissionSnapshot = {
  notifications: PermissionState;
  /** True once the user has been through the VPN screen at least once. */
  vpn: PermissionState;
};

/** Android's Settings.ACTION_VPN_SETTINGS constant. */
const ACTION_VPN_SETTINGS = 'android.settings.VPN_SETTINGS';

/** Read the current notification permission without prompting. */
export async function getNotificationPermission(): Promise<PermissionState> {
  if (Platform.OS === 'web') return 'unavailable';
  try {
    const settings = await Notifications.getPermissionsAsync();
    if (settings.granted) return 'granted';
    if (settings.canAskAgain) return 'undetermined';
    return 'denied';
  } catch {
    return 'unavailable';
  }
}

/**
 * Ask for notification permission. Returns the state after the user answers.
 * On a device where the OS will not prompt again, this reports `denied` rather than
 * looping the dialog.
 */
export async function requestNotificationPermission(): Promise<PermissionState> {
  if (Platform.OS === 'web') return 'unavailable';
  try {
    const existing = await Notifications.getPermissionsAsync();
    if (existing.granted) return 'granted';
    if (!existing.canAskAgain) return 'denied';
    const asked = await Notifications.requestPermissionsAsync({
      ios: {
        allowAlert: true,
        allowBadge: true,
        allowSound: true,
      },
    });
    return asked.granted ? 'granted' : 'denied';
  } catch {
    return 'unavailable';
  }
}

/**
 * Open the system VPN screen so the user can review and allow the connection.
 *
 * On Android this is the real Settings screen that lists VPN profiles and the system
 * consent entry. On iOS there is no equivalent public screen, so the app reports
 * `unavailable` and the UI explains that iOS asks when the tunnel starts.
 */
export async function openVpnSettings(): Promise<PermissionState> {
  if (Platform.OS !== 'android') return 'unavailable';
  try {
    await IntentLauncher.startActivityAsync(ACTION_VPN_SETTINGS);
    return 'granted';
  } catch {
    // Some OEM builds rename the activity; fall back to the general settings screen.
    try {
      await IntentLauncher.startActivityAsync(IntentLauncher.ActivityAction.SETTINGS);
      return 'granted';
    } catch {
      return 'unavailable';
    }
  }
}

/** A short, honest label for a permission state, used by the gate screen. */
export function permissionLabel(state: PermissionState): string {
  switch (state) {
    case 'granted':
      return 'Allowed';
    case 'denied':
      return 'Blocked';
    case 'undetermined':
      return 'Not asked yet';
    default:
      return 'Not available on this device';
  }
}
