import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';

import {
  connectThrough,
  describeError,
  pingHost,
  type ConnectAttempt,
  type TraceInfo,
} from '@/lib/cloudflare';
import { NODES, type NodeItem, type Protocol } from '@/lib/nodes';
import { usePersistentState } from '@/hooks/use-persistent-state';

export type ConnStatus = 'disconnected' | 'connecting' | 'connected';

type AppValue = {
  // Onboarding / account
  token: string;
  setToken: (t: string) => void;
  deployed: boolean;
  setDeployed: (v: boolean) => void;
  /** False until the stored values have loaded, so the router does not flash a screen. */
  ready: boolean;
  // Selection
  protocol: Protocol;
  setProtocol: (p: Protocol) => void;
  selectedNodeId: string;
  setSelectedNodeId: (id: string) => void;
  selectedNode: NodeItem;
  /** Select an arbitrary host found by the scanner (not in the built-in catalogue). */
  selectHost: (host: string) => void;
  // Live connection
  status: ConnStatus;
  pingMs: number | null;
  trace: TraceInfo | null;
  error: string | null;
  /** Technical detail behind `error`, for the support channel. */
  errorDetail: string | null;
  /** Which endpoint actually carried the session. */
  activeHost: string | null;
  /** Progress while connecting: "trying 2 of 9". */
  attempt: { index: number; total: number; host: string } | null;
  /** Endpoints tried before the successful one. */
  fallbackLog: ConnectAttempt[];
  connect: () => Promise<void>;
  disconnect: () => void;
  runPing: () => Promise<void>;
  reset: () => void;
};

const AppContext = createContext<AppValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = usePersistentState<string>('cf_token', '');
  const [deployed, setDeployed, deployedStatus] = usePersistentState<boolean>('deployed', false);
  const [protocol, setProtocol] = usePersistentState<Protocol>('protocol', 'warp');
  const [selectedNodeId, setSelectedNodeId] = usePersistentState<string>('node_id', 'cf-primary');
  // A host picked from the scanner that is not part of the built-in catalogue.
  const [customHost, setCustomHost] = usePersistentState<string>('custom_host', '');

  const [status, setStatus] = useState<ConnStatus>('disconnected');
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [trace, setTrace] = useState<TraceInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState<string | null>(null);
  const [activeHost, setActiveHost] = useState<string | null>(null);
  const [attempt, setAttempt] = useState<{ index: number; total: number; host: string } | null>(null);
  const [fallbackLog, setFallbackLog] = useState<ConnectAttempt[]>([]);

  const selectedNode = useMemo(() => {
    const found = NODES.find((n) => n.id === selectedNodeId);
    if (found) return found;
    // A scanner result: present it as a node so every screen can render it.
    if (customHost) {
      return {
        id: `scan-${customHost}`,
        name: customHost,
        country: 'Scanned endpoint',
        countryCode: 'CF',
        flag: '📡',
        protocol: 'ip' as Protocol,
        host: customHost,
        kind: 'host' as const,
        basePing: 0,
        note: 'Found by the scanner',
      } satisfies NodeItem;
    }
    return NODES[0];
  }, [selectedNodeId, customHost]);

  const selectHost = useCallback(
    (host: string) => {
      const existing = NODES.find((n) => n.host === host);
      if (existing) {
        setCustomHost('');
        setSelectedNodeId(existing.id);
        return;
      }
      setCustomHost(host);
      setSelectedNodeId(`scan-${host}`);
    },
    [setCustomHost, setSelectedNodeId],
  );

  const connect = useCallback(async () => {
    setError(null);
    setErrorDetail(null);
    setFallbackLog([]);
    setStatus('connecting');
    setAttempt(null);
    try {
      // Walk the protocol's candidate pool, selected node first. The first endpoint that
      // answers wins, so a blocked address no longer ends in a dead-end error.
      const result = await connectThrough(protocol, selectedNode.host, (a, index, total) => {
        setAttempt({ index, total, host: a.host });
        if (!a.ok) {
          setFallbackLog((prev) => [...prev, a]);
        }
      });
      setTrace(result.trace);
      setPingMs(result.ping.ok ? result.ping.ms : null);
      setActiveHost(result.host);
      setStatus('connected');
      setAttempt(null);
    } catch (e) {
      const { message, detail } = describeError(e);
      setError(message);
      setErrorDetail(detail);
      setStatus('disconnected');
      setAttempt(null);
    }
  }, [protocol, selectedNode]);

  const disconnect = useCallback(() => {
    setStatus('disconnected');
    setError(null);
    setErrorDetail(null);
    setActiveHost(null);
    setAttempt(null);
  }, []);

  const runPing = useCallback(async () => {
    const p = await pingHost(selectedNode.host, 3);
    setPingMs(p.ok ? p.ms : null);
  }, [selectedNode]);

  const reset = useCallback(() => {
    setDeployed(false);
    setStatus('disconnected');
    setTrace(null);
    setPingMs(null);
    setActiveHost(null);
    setError(null);
    setErrorDetail(null);
  }, [setDeployed]);

  const value = useMemo<AppValue>(
    () => ({
      token,
      setToken,
      deployed,
      setDeployed,
      ready: deployedStatus !== 'loading',
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      selectHost,
      status,
      pingMs,
      trace,
      error,
      errorDetail,
      activeHost,
      attempt,
      fallbackLog,
      connect,
      disconnect,
      runPing,
      reset,
    }),
    [
      token,
      setToken,
      deployed,
      setDeployed,
      deployedStatus,
      protocol,
      setProtocol,
      selectedNodeId,
      setSelectedNodeId,
      selectedNode,
      selectHost,
      status,
      pingMs,
      trace,
      error,
      errorDetail,
      activeHost,
      attempt,
      fallbackLog,
      connect,
      disconnect,
      runPing,
      reset,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppValue {
  const value = useContext(AppContext);
  if (!value) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return value;
}
