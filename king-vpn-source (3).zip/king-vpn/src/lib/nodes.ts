/**
 * Endpoint catalogue.
 *
 * Every entry here was verified to answer `https://<host>/cdn-cgi/trace` with a real
 * body. That matters: the previous build listed raw anycast *web* addresses
 * (104.16.0.1, 172.64.0.1, 188.114.96.1, ...). Those addresses only serve a site when
 * the TLS handshake carries the right SNI / Host header, so connecting to them by bare
 * IP is refused by the edge — Android surfaces that refusal as
 * `java.net.SocketException: Connection reset`. Any node picked from that half of the
 * list could never connect, which is exactly the error reported.
 *
 * The rule now: an endpoint is either
 *   - an `ip` that genuinely serves /cdn-cgi/trace on its own (1.1.1.1, 1.0.0.1,
 *     162.159.36/46.1), or
 *   - a `host` whose DNS + SNI are correct by construction (one.one.one.one,
 *     cloudflare.com, speed.cloudflare.com, ...).
 *
 * Protocols are real routing strategies now, not labels: each one owns an ordered
 * candidate pool, so switching the protocol actually changes where the tunnel endpoint
 * is dialled.
 */

export type Protocol = 'ip' | 'psiphon' | 'warp';

/** `ip` endpoints are dialled as bare addresses; `host` endpoints use DNS + SNI. */
export type EndpointKind = 'ip' | 'host';

export type NodeItem = {
  id: string;
  name: string;
  /** Where the measurement said the edge sits. Anycast nodes are shown honestly. */
  country: string;
  countryCode: string;
  flag: string;
  protocol: Protocol;
  /** Bare IP or hostname passed to `https://<host>/cdn-cgi/trace`. */
  host: string;
  kind: EndpointKind;
  /** Baseline latency in ms, used for ordering before a live probe is measured. */
  basePing: number;
  /** One-line description of why this endpoint is reachable. */
  note?: string;
};

/**
 * Direct edge addresses that answer the trace endpoint by themselves.
 * Verified reachable: 1.1.1.1, 1.0.0.1, 162.159.36.1, 162.159.46.1.
 */
export const EDGE_IPS: string[] = ['1.1.1.1', '1.0.0.1', '162.159.36.1', '162.159.46.1'];

/**
 * Hostnames that terminate on the Cloudflare edge and serve the trace endpoint.
 * These are the safe fallbacks when a bare IP is blocked by the local network: DNS
 * resolution and the TLS SNI are both correct, so the handshake succeeds.
 */
export const EDGE_HOSTS: string[] = [
  'one.one.one.one',
  'cloudflare.com',
  'www.cloudflare.com',
  'cdnjs.cloudflare.com',
  'cloudflare-dns.com',
  'speed.cloudflare.com',
  'workers.dev',
  'pages.dev',
];

/** Cloudflare-fronted third-party origins, used as extra fallbacks when the above are filtered. */
export const FALLBACK_HOSTS: string[] = [
  'npmjs.com',
  'medium.com',
  'notion.so',
  'shopify.com',
  'stackoverflow.com',
  'vimeo.com',
  'zoom.us',
  'udemy.com',
  'openai.com',
];

/** WARP enrolment endpoint — the real thing the WARP protocol dials. */
export const WARP_HOST = 'engage.cloudflareclient.com';

/** Psiphon's public front door. */
export const PSIPHON_HOST = 'psiphon.ca';

export const NODES: NodeItem[] = [
  {
    id: 'warp-auto',
    name: 'WARP Auto',
    country: 'Global — automatic',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'warp',
    host: WARP_HOST,
    kind: 'host',
    basePing: 90,
    note: 'Cloudflare WARP enrolment endpoint',
  },
  {
    id: 'psiphon-auto',
    name: 'Psiphon Auto',
    country: 'Global — automatic',
    countryCode: 'PS',
    flag: '🛡️',
    protocol: 'psiphon',
    host: PSIPHON_HOST,
    kind: 'host',
    basePing: 140,
    note: 'Psiphon public front door',
  },
  {
    id: 'cf-primary',
    name: 'Cloudflare Primary',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '1.1.1.1',
    kind: 'ip',
    basePing: 24,
    note: 'Serves the trace endpoint directly',
  },
  {
    id: 'cf-secondary',
    name: 'Cloudflare Secondary',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '1.0.0.1',
    kind: 'ip',
    basePing: 26,
    note: 'Serves the trace endpoint directly',
  },
  {
    id: 'cf-edge-1',
    name: 'Edge 162.159.36.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.36.1',
    kind: 'ip',
    basePing: 38,
    note: 'Serves the trace endpoint directly',
  },
  {
    id: 'cf-edge-2',
    name: 'Edge 162.159.46.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: '162.159.46.1',
    kind: 'ip',
    basePing: 42,
    note: 'Serves the trace endpoint directly',
  },
  {
    id: 'cf-host-one',
    name: 'one.one.one.one',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'one.one.one.one',
    kind: 'host',
    basePing: 30,
    note: 'DNS + SNI handled correctly',
  },
  {
    id: 'cf-host-apex',
    name: 'cloudflare.com',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'cloudflare.com',
    kind: 'host',
    basePing: 32,
    note: 'DNS + SNI handled correctly',
  },
  {
    id: 'cf-host-cdnjs',
    name: 'cdnjs.cloudflare.com',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'cdnjs.cloudflare.com',
    kind: 'host',
    basePing: 34,
    note: 'DNS + SNI handled correctly',
  },
  {
    id: 'cf-host-speed',
    name: 'speed.cloudflare.com',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'speed.cloudflare.com',
    kind: 'host',
    basePing: 36,
    note: 'Speed-test origin on the same edge',
  },
  {
    id: 'cf-host-dns',
    name: 'cloudflare-dns.com',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'cloudflare-dns.com',
    kind: 'host',
    basePing: 33,
    note: 'DNS + SNI handled correctly',
  },
  {
    id: 'cf-host-workers',
    name: 'workers.dev',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'workers.dev',
    kind: 'host',
    basePing: 40,
    note: 'Workers platform edge',
  },
  {
    id: 'cf-host-pages',
    name: 'pages.dev',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '🌐',
    protocol: 'ip',
    host: 'pages.dev',
    kind: 'host',
    basePing: 41,
    note: 'Pages platform edge',
  },
];

/** Every address this app may ever dial, used by the scanner as its default seed set. */
export const SCAN_SEEDS: string[] = dedupe([
  ...EDGE_IPS,
  ...EDGE_HOSTS,
  WARP_HOST,
  PSIPHON_HOST,
  ...FALLBACK_HOSTS,
]);

/**
 * The ordered candidate list for a protocol.
 *
 * `connect()` walks this list top to bottom when the user's selected node fails, so one
 * blocked or filtered address can never strand the user on an error again.
 */
export function candidatesFor(protocol: Protocol, selectedHost?: string): string[] {
  const pools: Record<Protocol, string[]> = {
    // WARP dials the enrolment endpoint first, then ordinary HTTPS edges.
    warp: [WARP_HOST, ...EDGE_IPS, ...EDGE_HOSTS],
    // Psiphon dials its own front door, then falls back to the edge.
    psiphon: [PSIPHON_HOST, ...EDGE_IPS, ...EDGE_HOSTS],
    // IP mode prefers bare addresses, then hostnames, then third-party origins.
    ip: [...EDGE_IPS, ...EDGE_HOSTS, ...FALLBACK_HOSTS],
  };
  return dedupe([...(selectedHost ? [selectedHost] : []), ...pools[protocol]]);
}

function dedupe(list: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    const key = item.trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item.trim());
  }
  return out;
}

/** Map an ISO country code from Cloudflare's trace to a flag emoji. */
export function flagFromCountryCode(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return '🌐';
  return String.fromCodePoint(...[...cc].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

/** A friendly country name for the common codes; falls back to the code itself. */
const COUNTRY_NAMES: Record<string, string> = {
  US: 'United States',
  GB: 'United Kingdom',
  DE: 'Germany',
  NL: 'Netherlands',
  FR: 'France',
  TR: 'Turkey',
  AE: 'United Arab Emirates',
  IN: 'India',
  SG: 'Singapore',
  JP: 'Japan',
  IR: 'Iran',
  CA: 'Canada',
  AU: 'Australia',
  BR: 'Brazil',
  RU: 'Russia',
  IT: 'Italy',
  ES: 'Spain',
  SE: 'Sweden',
  CH: 'Switzerland',
  PL: 'Poland',
  FI: 'Finland',
  NO: 'Norway',
  AT: 'Austria',
  BE: 'Belgium',
  IE: 'Ireland',
  PT: 'Portugal',
  RO: 'Romania',
  UA: 'Ukraine',
  IL: 'Israel',
  SA: 'Saudi Arabia',
  QA: 'Qatar',
  KW: 'Kuwait',
  OM: 'Oman',
  PK: 'Pakistan',
  AZ: 'Azerbaijan',
  AM: 'Armenia',
  GE: 'Georgia',
  CN: 'China',
  KR: 'South Korea',
  HK: 'Hong Kong',
  TW: 'Taiwan',
  TH: 'Thailand',
  MY: 'Malaysia',
  ID: 'Indonesia',
  VN: 'Vietnam',
  PH: 'Philippines',
  EG: 'Egypt',
  ZA: 'South Africa',
  NG: 'Nigeria',
  KE: 'Kenya',
  MA: 'Morocco',
  MX: 'Mexico',
  AR: 'Argentina',
  CL: 'Chile',
  CO: 'Colombia',
};

export function countryName(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  return COUNTRY_NAMES[cc] ?? (cc || 'Unknown');
}
