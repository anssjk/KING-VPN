/**
 * Network layer: probing, connecting and scanning.
 *
 * Everything here talks to real Cloudflare endpoints over HTTPS:
 *   - `https://<host>/cdn-cgi/trace` → the caller's public IP, country and edge colo
 *   - the same URL is timed to measure latency (ping)
 *   - `https://api.cloudflare.com/client/v4/user/tokens/verify` → token check
 *
 * Two rules keep the app usable on a hostile network:
 *
 *  1. **Never trust one address.** `connectThrough()` walks an ordered candidate list and
 *     returns the first endpoint that answers. A single blocked IP can no longer produce
 *     a dead-end error.
 *  2. **Never show a raw Java exception.** `describeError()` turns
 *     `java.net.SocketException: Connection reset` and friends into a sentence the user
 *     can act on, while keeping the technical detail available for support.
 *
 * Every request has an AbortController timeout so a dead host can never hang the UI.
 */
import { candidatesFor, type Protocol } from '@/lib/nodes';

const TRACE_TIMEOUT_MS = 6000;
const PING_TIMEOUT_MS = 5000;
const VERIFY_TIMEOUT_MS = 10000;

export type TraceInfo = {
  ip: string;
  loc: string;
  colo: string;
  warp: string;
  http: string;
  tls: string;
  /** The endpoint that produced this trace. */
  host: string;
};

export type PingResult = {
  host: string;
  ok: boolean;
  /** Median round-trip in ms across the samples that succeeded. */
  ms: number;
  /** Fastest sample, in ms. */
  best: number;
  /** Spread between fastest and slowest sample, in ms — a stability signal. */
  jitter: number;
  /** 0..1 — share of samples that failed. */
  loss: number;
  /** Samples attempted. */
  samples: number;
  /** Country code reported by the edge, when the probe read a trace. */
  loc?: string;
  colo?: string;
  /** Human-readable reason when `ok` is false. */
  error?: string;
};

async function fetchWithTimeout(url: string, timeoutMs: number, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function parseTrace(text: string): Omit<TraceInfo, 'host'> {
  const map: Record<string, string> = {};
  for (const line of text.split('\n')) {
    const idx = line.indexOf('=');
    if (idx > 0) {
      map[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
    }
  }
  return {
    ip: map.ip ?? '',
    loc: map.loc ?? '',
    colo: map.colo ?? '',
    warp: map.warp ?? 'off',
    http: map.http ?? '',
    tls: map.tls ?? '',
  };
}

/**
 * Turn a thrown value into something a person can read.
 *
 * Android's fetch rejects with messages like
 * `fetch failed: java.net.SocketException: Connection reset` or
 * `java.net.UnknownHostException: Unable to resolve host ...`. Those are accurate but
 * useless in a UI, so each known shape gets a plain sentence. `detail` keeps the original
 * text for the support channel.
 */
export function describeError(e: unknown): { message: string; detail: string } {
  const detail = e instanceof Error ? e.message : String(e);
  const low = detail.toLowerCase();

  if (low.includes('abort')) {
    return { message: 'The endpoint did not answer in time.', detail };
  }
  if (low.includes('connection reset') || low.includes('econnreset') || low.includes('socketexception')) {
    return {
      message: 'The network reset the connection. This address is blocked here — trying another one.',
      detail,
    };
  }
  if (low.includes('unknownhost') || low.includes('unable to resolve') || low.includes('nodename nor servname')) {
    return { message: 'That address could not be resolved. Check your connection or DNS.', detail };
  }
  if (low.includes('timeout') || low.includes('timed out') || low.includes('etimedout')) {
    return { message: 'The connection timed out. The endpoint may be filtered on this network.', detail };
  }
  if (low.includes('network request failed') || low.includes('failed to fetch') || low.includes('networkerror')) {
    return { message: 'No network response. Check that mobile data or Wi-Fi is on.', detail };
  }
  if (low.includes('certificate') || low.includes('ssl') || low.includes('tls')) {
    return { message: 'The secure handshake failed. This endpoint cannot be trusted from here.', detail };
  }
  if (low.includes('trace returned no ip') || low.includes('trace failed')) {
    return { message: 'The endpoint answered, but not with a usable trace. Trying another one.', detail };
  }
  return { message: 'Could not reach the endpoint.', detail };
}

/** Read the caller's public IP, country and edge colo through one endpoint. */
export async function fetchTrace(host = '1.1.1.1', timeoutMs = TRACE_TIMEOUT_MS): Promise<TraceInfo> {
  const res = await fetchWithTimeout(`https://${host}/cdn-cgi/trace`, timeoutMs, {
    headers: { Accept: 'text/plain' },
    cache: 'no-store',
  });
  if (!res.ok) {
    throw new Error(`trace failed (${res.status})`);
  }
  const text = await res.text();
  const info = parseTrace(text);
  if (!info.ip) {
    throw new Error('trace returned no ip');
  }
  return { ...info, host };
}

/**
 * Measure one endpoint with `samples` round trips.
 *
 * Latency is the median of the successful samples (robust against one slow outlier),
 * `jitter` is the spread, and `loss` is the share that failed. A single sample is enough
 * for a quick ping; the scanner uses three so its ranking means something.
 */
export async function pingHost(host: string, samples = 1, timeoutMs = PING_TIMEOUT_MS): Promise<PingResult> {
  const times: number[] = [];
  let failures = 0;
  let loc: string | undefined;
  let colo: string | undefined;
  let lastError: string | undefined;

  for (let i = 0; i < Math.max(1, samples); i += 1) {
    const started = Date.now();
    try {
      const res = await fetchWithTimeout(`https://${host}/cdn-cgi/trace`, timeoutMs, {
        headers: { Accept: 'text/plain' },
        cache: 'no-store',
      });
      if (!res.ok) {
        failures += 1;
        lastError = `HTTP ${res.status}`;
        continue;
      }
      const text = await res.text();
      const info = parseTrace(text);
      if (!info.ip) {
        failures += 1;
        lastError = 'no trace body';
        continue;
      }
      times.push(Date.now() - started);
      loc = info.loc || loc;
      colo = info.colo || colo;
    } catch (e) {
      failures += 1;
      lastError = describeError(e).message;
    }
  }

  const total = Math.max(1, samples);
  if (times.length === 0) {
    return {
      host,
      ok: false,
      ms: 0,
      best: 0,
      jitter: 0,
      loss: 1,
      samples: total,
      error: lastError ?? 'unreachable',
    };
  }
  const sorted = [...times].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  return {
    host,
    ok: true,
    ms: median,
    best: sorted[0],
    jitter: sorted[sorted.length - 1] - sorted[0],
    loss: failures / total,
    samples: total,
    loc,
    colo,
  };
}

export type ConnectAttempt = {
  host: string;
  ok: boolean;
  ms?: number;
  error?: string;
};

export type ConnectResult = {
  trace: TraceInfo;
  ping: PingResult;
  /** The endpoint that actually worked. */
  host: string;
  /** Every endpoint tried before it, in order — shown in the UI as a fallback log. */
  attempts: ConnectAttempt[];
};

/**
 * Connect by walking the protocol's candidate list.
 *
 * The selected node is tried first, then the rest of the pool. The first endpoint that
 * returns a valid trace wins and the loop stops, so a normal connection costs one
 * request. `onAttempt` fires after each try so the UI can show "trying 2 of 9".
 *
 * Throws only when *every* candidate failed; the error then carries the last real reason
 * plus the attempt log, instead of a bare `Connection reset`.
 */
export async function connectThrough(
  protocol: Protocol,
  selectedHost: string | undefined,
  onAttempt?: (attempt: ConnectAttempt, index: number, total: number) => void,
): Promise<ConnectResult> {
  const candidates = candidatesFor(protocol, selectedHost);
  const attempts: ConnectAttempt[] = [];
  let lastError = 'No endpoint answered.';

  for (let i = 0; i < candidates.length; i += 1) {
    const host = candidates[i];
    try {
      const trace = await fetchTrace(host);
      const ping = await pingHost(host, 1);
      const attempt: ConnectAttempt = { host, ok: true, ms: ping.ok ? ping.ms : undefined };
      attempts.push(attempt);
      onAttempt?.(attempt, i + 1, candidates.length);
      return { trace, ping, host, attempts };
    } catch (e) {
      const { message } = describeError(e);
      lastError = message;
      const attempt: ConnectAttempt = { host, ok: false, error: message };
      attempts.push(attempt);
      onAttempt?.(attempt, i + 1, candidates.length);
    }
  }

  const err = new Error(lastError);
  (err as Error & { attempts?: ConnectAttempt[] }).attempts = attempts;
  throw err;
}

export type ScanOptions = {
  /** Round trips per endpoint. 3 gives a meaningful jitter figure. */
  samples?: number;
  /** How many endpoints are probed at once. */
  concurrency?: number;
  /** Per-request timeout. */
  timeoutMs?: number;
  /** Called after each endpoint finishes, with the running result list. */
  onResult?: (result: PingResult, done: number, total: number) => void;
  /** Return true to stop early (the UI's Cancel button). */
  shouldStop?: () => boolean;
};

export type ScanSummary = {
  results: PingResult[];
  /** Endpoints that answered, fastest first. */
  reachable: PingResult[];
  total: number;
  done: number;
  cancelled: boolean;
  /** Wall-clock duration of the scan, in ms. */
  durationMs: number;
};

/**
 * Probe a list of endpoints concurrently and return everything measured.
 *
 * Unlike the old scanner this keeps the failures too, so the UI can show "12 of 21
 * answered" and let the user see which addresses are blocked on their network. It is
 * cancellable, reports progress per endpoint, and never rejects: a scan that finds
 * nothing returns an empty `reachable` list rather than throwing.
 */
export async function scanEndpoints(hosts: string[], options: ScanOptions = {}): Promise<ScanSummary> {
  const samples = options.samples ?? 3;
  const concurrency = Math.max(1, options.concurrency ?? 6);
  const timeoutMs = options.timeoutMs ?? PING_TIMEOUT_MS;
  const started = Date.now();

  const unique = Array.from(new Set(hosts.map((h) => h.trim()).filter(Boolean)));
  const results: PingResult[] = [];
  let cursor = 0;
  let done = 0;
  let cancelled = false;

  const worker = async () => {
    for (;;) {
      if (options.shouldStop?.()) {
        cancelled = true;
        return;
      }
      const index = cursor;
      cursor += 1;
      if (index >= unique.length) return;
      const host = unique[index];
      const result = await pingHost(host, samples, timeoutMs);
      results.push(result);
      done += 1;
      options.onResult?.(result, done, unique.length);
    }
  };

  await Promise.all(Array.from({ length: Math.min(concurrency, unique.length) }, worker));

  const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
  return {
    results,
    reachable,
    total: unique.length,
    done,
    cancelled,
    durationMs: Date.now() - started,
  };
}

export type TokenVerifyResult = {
  ok: boolean;
  status: 'active' | 'invalid' | 'unknown';
  message: string;
};

/**
 * Verify a Cloudflare API token against the official endpoint. A network failure is
 * reported as `unknown` so the app can still continue offline rather than blocking the
 * user on a flaky connection.
 */
export async function verifyToken(token: string): Promise<TokenVerifyResult> {
  const trimmed = token.trim();
  if (!trimmed) {
    return { ok: false, status: 'invalid', message: 'Token is empty.' };
  }
  try {
    const res = await fetchWithTimeout(
      'https://api.cloudflare.com/client/v4/user/tokens/verify',
      VERIFY_TIMEOUT_MS,
      {
        headers: {
          Authorization: `Bearer ${trimmed}`,
          'Content-Type': 'application/json',
        },
      },
    );
    const body = (await res.json().catch(() => null)) as
      | { success?: boolean; result?: { status?: string }; errors?: { message?: string }[] }
      | null;
    if (res.ok && body?.success && body.result?.status === 'active') {
      return { ok: true, status: 'active', message: 'Token is active.' };
    }
    const message = body?.errors?.[0]?.message ?? `Token rejected (${res.status}).`;
    return { ok: false, status: 'invalid', message };
  } catch {
    return {
      ok: false,
      status: 'unknown',
      message: 'Could not reach Cloudflare. Check your connection.',
    };
  }
}
