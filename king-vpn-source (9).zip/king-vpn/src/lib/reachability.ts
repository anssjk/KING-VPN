/**
 * Reachability testing: TCP, TLS, and the only check that really counts — a config test.
 *
 * ## The three levels, and why all three exist
 *
 *  1. **TCP connect** (`probeTcp`) — the address and port accept a connection. Fast, and
 *     the right first filter for a TCP-based transport. It says nothing about whether a
 *     proxy would work.
 *  2. **TLS handshake** (`probeTls`) — the address, the port *and* the SNI agree, because
 *     a bare IP only completes a TLS handshake when the ClientHello carries the name the
 *     server serves. This is the right filter for a TLS/REALITY endpoint.
 *  3. **Config test** (`verifyConfig`) — the core is started with the real config and a
 *     page is fetched *through it*. This is the only level that can honestly say "this
 *     works", because traffic actually left through the server.
 *
 * A port being open is never reported as "working". The scanner shows the TCP/TLS result
 * as a *reachability* signal, and only a config test turns a row into a verified server.
 */
import { probeTcp, probeTls, testConfig, type ConfigTestResult, type ReachProbe } from '@/lib/xray';
import type { ServerConfig } from '@/lib/xray-config';

export type ReachLevel = 'tcp' | 'tls';

export type ReachResult = {
  host: string;
  port: number;
  level: ReachLevel;
  ok: boolean;
  ms: number;
  error: string | null;
};

/**
 * Probe one endpoint at the requested level.
 *
 * `sni` is only used for the TLS level; a TCP probe ignores it. The function never throws:
 * a failure is a result with `ok: false` and the reason, so a scan can keep going.
 */
export async function probeReach(
  host: string,
  port: number,
  level: ReachLevel,
  sni: string,
  timeoutMs = 3000,
): Promise<ReachResult> {
  const result: ReachProbe =
    level === 'tls' ? await probeTls(host, port, sni, timeoutMs) : await probeTcp(host, port, timeoutMs);
  return {
    host,
    port,
    level,
    ok: result.ok,
    ms: result.ms,
    error: result.error,
  };
}

/**
 * Probe many endpoints concurrently, with a real cap on how many run at once.
 *
 * The cap is the point: a scan that opens thousands of sockets at once gets the app
 * throttled by the OS and the network, and looks like a flood to the other side. A worker
 * pool keeps the pressure bounded and the results honest.
 */
export async function probeManyReach(
  targets: { host: string; port: number }[],
  level: ReachLevel,
  sni: string,
  options: {
    concurrency?: number;
    timeoutMs?: number;
    onResult?: (result: ReachResult, done: number, total: number) => void;
    shouldStop?: () => boolean;
  } = {},
): Promise<ReachResult[]> {
  const concurrency = Math.max(1, options.concurrency ?? 32);
  const timeoutMs = options.timeoutMs ?? 3000;
  const results: ReachResult[] = [];
  let cursor = 0;
  let done = 0;

  const worker = async () => {
    for (;;) {
      if (options.shouldStop?.()) return;
      const index = cursor;
      cursor += 1;
      if (index >= targets.length) return;
      const target = targets[index];
      const result = await probeReach(target.host, target.port, level, sni, timeoutMs);
      results.push(result);
      done += 1;
      options.onResult?.(result, done, targets.length);
    }
  };

  await Promise.all(Array.from({ length: Math.min(concurrency, targets.length) }, worker));
  return results;
}

/**
 * The real test: start the core with this config and fetch a page through it.
 *
 * This is the gate that turns a reachable address into a *working* server. It is
 * deliberately separate from the reachability probes so the UI can show the difference:
 * "reachable" is a measurement, "verified" is proof.
 */
export async function verifyConfig(config: ServerConfig, timeoutMs = 12000): Promise<ConfigTestResult> {
  return testConfig(config, timeoutMs);
}

/**
 * Verify a list of configs, one at a time.
 *
 * Sequential on purpose: each test starts the core and binds the SOCKS port, so two at
 * once would fight over the port. A list of candidates is tested in order and the first
 * that passes is the one to use.
 */
export async function verifyFirstWorking(
  configs: ServerConfig[],
  options: {
    timeoutMs?: number;
    onResult?: (config: ServerConfig, result: ConfigTestResult, index: number) => void;
    shouldStop?: () => boolean;
  } = {},
): Promise<{ config: ServerConfig; result: ConfigTestResult } | null> {
  for (let i = 0; i < configs.length; i += 1) {
    if (options.shouldStop?.()) return null;
    const config = configs[i];
    const result = await verifyConfig(config, options.timeoutMs ?? 12000);
    options.onResult?.(config, result, i);
    if (result.ok) return { config, result };
  }
  return null;
}
