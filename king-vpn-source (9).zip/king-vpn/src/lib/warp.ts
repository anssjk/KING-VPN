/**
 * Cloudflare WARP enrolment.
 *
 * A WARP "node" is not a URL you can ping — it is a WireGuard peer you must be
 * *registered* with. The flow is:
 *
 *   1. generate a WireGuard key pair on the device,
 *   2. POST the public key to Cloudflare's registration API,
 *   3. Cloudflare answers with the peer's public key, the endpoint, and the tunnel
 *      addresses assigned to this device,
 *   4. those four things become the WireGuard config the native tunnel dials.
 *
 * This is the same exchange the official WARP client performs. The private key never
 * leaves the phone; only the public half is sent.
 *
 * Registration is cached on the device: re-registering on every connect would create a
 * new device each time and burn through Cloudflare's per-IP registration limit.
 */
import { generateKeyPair } from '@/lib/tunnel';
import { readJSON, writeJSON } from '@/lib/storage';

/** Cloudflare's client API. The version segment is the one the Android client uses. */
const REG_URL = 'https://api.cloudflareclient.com/v0a2158/reg';
const REG_TIMEOUT_MS = 20000;

/** Cloudflare's WARP peer public key — constant across all registrations. */
export const WARP_PEER_PUBLIC_KEY = 'bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=';

/** The WARP endpoint host. Ports 2408/500/1701/4500 are all valid; 2408 is standard. */
export const WARP_ENDPOINT_HOST = 'engage.cloudflareclient.com';
export const WARP_ENDPOINT_PORT = 2408;

export type WarpRegistration = {
  /** WireGuard private key, base64. Stays on the device. */
  privateKey: string;
  /** Our public key, base64 — what Cloudflare has on file. */
  publicKey: string;
  /** Cloudflare's peer public key. */
  peerPublicKey: string;
  /** `host:port` to dial. */
  endpoint: string;
  /** Tunnel addresses assigned to this device, CIDR. */
  addresses: string[];
  /** Cloudflare's device id, kept so the registration can be reused. */
  deviceId: string;
  /** When this registration was made (epoch ms). */
  createdAt: number;
};

const CACHE_KEY = 'warp_registration';

type RegResponse = {
  id?: string;
  config?: {
    peers?: {
      public_key?: string;
      endpoint?: { host?: string; ports?: number[] };
    }[];
    interface?: {
      addresses?: { v4?: string; v6?: string };
    };
  };
  error?: string;
  errors?: { message?: string }[];
};

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Register a fresh device with Cloudflare WARP.
 *
 * Throws with a readable message when Cloudflare refuses (rate limit, blocked network)
 * so the caller can show it instead of a bare fetch error.
 */
export async function registerWarp(): Promise<WarpRegistration> {
  const keys = await generateKeyPair();

  const body = {
    key: keys.publicKey,
    install_id: '',
    fcm_token: '',
    tos: new Date().toISOString(),
    model: 'PC',
    serial_number: '',
    locale: 'en_US',
    type: 'Android',
    warp_enabled: true,
  };

  let res: Response;
  try {
    res = await fetchWithTimeout(
      REG_URL,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Cloudflare rejects requests without a client user-agent.
          'User-Agent': 'okhttp/3.12.1',
          'CF-Client-Version': 'a-6.11-2158',
        },
        body: JSON.stringify(body),
      },
      REG_TIMEOUT_MS,
    );
  } catch (e) {
    const detail = e instanceof Error ? e.message : String(e);
    throw new Error(`Could not reach Cloudflare to register: ${detail}`);
  }

  const json = (await res.json().catch(() => null)) as RegResponse | null;

  if (!res.ok || !json) {
    const reason = json?.errors?.[0]?.message ?? json?.error ?? `HTTP ${res.status}`;
    throw new Error(`Cloudflare refused the registration: ${reason}`);
  }

  const peer = json.config?.peers?.[0];
  const peerPublicKey = peer?.public_key ?? WARP_PEER_PUBLIC_KEY;
  const host = peer?.endpoint?.host ?? `${WARP_ENDPOINT_HOST}:${WARP_ENDPOINT_PORT}`;
  const v4 = json.config?.interface?.addresses?.v4;
  const v6 = json.config?.interface?.addresses?.v6;

  if (!v4) {
    throw new Error('Cloudflare did not return a tunnel address. Try again.');
  }

  const addresses = [`${v4}/32`];
  if (v6) addresses.push(`${v6}/128`);

  return {
    privateKey: keys.privateKey,
    publicKey: keys.publicKey,
    peerPublicKey,
    endpoint: host,
    addresses,
    deviceId: json.id ?? '',
    createdAt: Date.now(),
  };
}

/** The cached registration, or null when this device has never registered. */
export async function loadRegistration(): Promise<WarpRegistration | null> {
  try {
    const stored = await readJSON<WarpRegistration | null>(CACHE_KEY, null);
    if (!stored || !stored.privateKey || !stored.addresses?.length) return null;
    return stored;
  } catch {
    return null;
  }
}

/** Register once and remember it; later calls reuse the stored device. */
export async function ensureRegistration(force = false): Promise<WarpRegistration> {
  if (!force) {
    const cached = await loadRegistration();
    if (cached) return cached;
  }
  const fresh = await registerWarp();
  await writeJSON(CACHE_KEY, fresh);
  return fresh;
}

/** Forget the stored device, so the next connect registers a new one. */
export async function clearRegistration(): Promise<void> {
  await writeJSON(CACHE_KEY, null);
}
