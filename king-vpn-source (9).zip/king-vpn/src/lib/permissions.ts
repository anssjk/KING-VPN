/**
 * Runtime permissions.
 *
 * Two permissions matter to a VPN client, and both are now requested for real:
 *
 *  - **VPN** — Android never grants this from a normal permission prompt. The system
 *    shows its own "Connection request" dialog when `VpnService.prepare()`'s Intent is
 *    launched from an Activity. The native module (`modules/king-vpn-tunnel`) does
 *    exactly that, so the user sees the genuine system dialog and the answer is recorded
 *    by Android. `requestVpnPermission()` returns what Android actually decided.
 *  - **Notifications** — a normal Android runtime permission. `expo-notifications` asks
 *    for it and reports the answer.
 *
 * Nothing here pretends a permission was granted when it was not: every function
 * returns the real state it observed.
 */
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

import { isPrepared, requestVpnPermission, isAvailable as tunnelAvailable } from '@/lib/tunnel';

export type PermissionState = 'granted' | 'denied' | 'undetermined' | 'unavailable';

export type PermissionSnapshot = {
  notifications: PermissionState;
  vpn: PermissionState;
};

/** Read the current notification permission without prompting. */
export async function getNotificationPermission(): Promise<PermissionState> {
  if (Platform.OS === 'web') return 'unavailable';
  try {
    const settings = await Notifications.getPermissionsAsync();
    if (settings.granted) return 'granted';
    if (settings.canAskAgain) return 'undetermined';
    return 'denied';
  } catch {
    return 'unavailable';
  }
}

/**
 * Ask for notification permission. Returns the state after the user answers.
 * On a device where the OS will not prompt again, this reports `denied` rather than
 * looping the dialog.
 */
export async function requestNotificationPermission(): Promise<PermissionState> {
  if (Platform.OS === 'web') return 'unavailable';
  try {
    const existing = await Notifications.getPermissionsAsync();
    if (existing.granted) return 'granted';
    if (!existing.canAskAgain) return 'denied';
    const asked = await Notifications.requestPermissionsAsync({
      ios: {
        allowAlert: true,
        allowBadge: true,
        allowSound: true,
      },
    });
    return asked.granted ? 'granted' : 'denied';
  } catch {
    return 'unavailable';
  }
}

/** Read the current VPN permission without prompting. */
export async function getVpnPermission(): Promise<PermissionState> {
  if (Platform.OS !== 'android') return 'unavailable';
  if (!tunnelAvailable) return 'unavailable';
  try {
    return (await isPrepared()) ? 'granted' : 'undetermined';
  } catch {
    return 'unavailable';
  }
}

/**
 * Show Android's real VPN consent dialog and return the user's answer.
 *
 * This is the system "Connection request" screen — the same one every VPN app shows.
 * It resolves `granted` only when Android recorded the permission.
 */
export async function requestVpnPermissionState(): Promise<PermissionState> {
  if (Platform.OS !== 'android') return 'unavailable';
  if (!tunnelAvailable) return 'unavailable';
  try {
    const granted = await requestVpnPermission();
    return granted ? 'granted' : 'denied';
  } catch {
    return 'denied';
  }
}

/** A short, honest label for a permission state, used by the gate screen. */
export function permissionLabel(state: PermissionState): string {
  switch (state) {
    case 'granted':
      return 'Allowed';
    case 'denied':
      return 'Blocked';
    case 'undetermined':
      return 'Not asked yet';
    default:
      return 'Not available on this device';
  }
}
