/**
 * Typed bridge to the native Xray engine.
 *
 * The native module (`modules/king-vpn-tunnel`) owns the real `android.net.VpnService`,
 * the Xray core and the TUN bridge. This file only describes their shape and degrades
 * cleanly on platforms that have no tunnel (web, iOS, Expo Go).
 *
 * `isAvailable` is the single source of truth for "can this build actually create a
 * VPN?". Expo Go and the web preview cannot, because they have no custom native code —
 * so the UI must say so instead of pretending to connect.
 */
import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';

import type { ServerConfig } from '@/lib/xray-config';
import { buildXrayConfig } from '@/lib/xray-config';

export type TunnelState = 'UP' | 'DOWN';

export type TunnelStatus = {
  state: TunnelState;
  rxBytes: number;
  txBytes: number;
  /** Epoch millis of the last successful handshake; 0 means none yet. */
  latestHandshakeMs: number;
  version: string;
};

/** The result of a real config-level connectivity test. */
export type ConfigTestResult = {
  ok: boolean;
  ms: number;
  /** The exit IP the server reported, when the test succeeded. */
  ip: string | null;
  error: string | null;
};

/** The result of a TCP or TLS reachability probe. */
export type ReachProbe = {
  ok: boolean;
  ms: number;
  error: string | null;
};

type NativeTunnelModule = {
  isPreparedAsync(): Promise<boolean>;
  requestPermissionAsync(): Promise<boolean>;
  generateKeyPairAsync(): Promise<{ privateKey: string; publicKey: string }>;
  coreVersionAsync(): Promise<string>;
  connectXrayAsync(configJson: string, mtu: number): Promise<boolean>;
  disconnectAsync(): Promise<boolean>;
  getStatusAsync(): Promise<TunnelStatus>;
  probeTcpAsync(host: string, port: number, timeoutMs: number): Promise<ReachProbe>;
  probeTlsAsync(host: string, port: number, sni: string, timeoutMs: number): Promise<ReachProbe>;
  testConfigAsync(configJson: string, timeoutMs: number): Promise<ConfigTestResult>;
  probeWgAsync(
    host: string,
    port: number,
    privateKey: string,
    peerPublicKey: string,
    timeoutMs: number,
  ): Promise<{
    ok: boolean;
    ms: number;
    error: string | null;
    port?: number;
    colo?: string | null;
    loc?: string | null;
  }>;
  probeManyAsync(
    endpoints: { host: string; port: number }[],
    privateKey: string,
    peerPublicKey: string,
    timeoutMs: number,
    concurrency: number,
    resolveColo: boolean,
  ): Promise<
    {
      host: string;
      port: number;
      ok: boolean;
      ms: number;
      error: string | null;
      colo?: string | null;
      loc?: string | null;
    }[]
  >;
  cancelScanAsync(): Promise<boolean>;
  resolveColoAsync(host: string, timeoutMs: number): Promise<{ colo: string | null; loc: string | null }>;
  addListener(event: string, listener: (payload: unknown) => void): { remove: () => void };
};

const native = requireOptionalNativeModule<NativeTunnelModule>('KingVpnTunnel');

/** True only on an Android build that actually contains the tunnel module. */
export const isAvailable = Platform.OS === 'android' && native != null;

/** Why the tunnel is unavailable, for the UI to explain instead of failing silently. */
export function unavailableReason(): string | null {
  if (isAvailable) return null;
  if (Platform.OS === 'android') {
    return 'This build has no native VPN module. Build a development or release APK (Expo Go cannot create a VPN).';
  }
  return 'The VPN tunnel is Android-only in this build.';
}

function requireModule(): NativeTunnelModule {
  if (!native) {
    throw new Error(unavailableReason() ?? 'The VPN module is not available.');
  }
  return native;
}

/** True when Android has already granted the VPN permission. */
export async function isPrepared(): Promise<boolean> {
  if (!native) return false;
  try {
    return await native.isPreparedAsync();
  } catch {
    return false;
  }
}

/**
 * Show the real system "Connection request" dialog.
 * Resolves true only when the user actually allowed it.
 */
export async function requestVpnPermission(): Promise<boolean> {
  if (!native) return false;
  return native.requestPermissionAsync();
}

export async function generateKeyPair(): Promise<{ privateKey: string; publicKey: string }> {
  return requireModule().generateKeyPairAsync();
}

/** The Xray core's version string, e.g. `Lib v40, Xray-core v26.11.9`. */
export async function coreVersion(): Promise<string> {
  if (!native) return '';
  try {
    return await native.coreVersionAsync();
  } catch {
    return '';
  }
}

/**
 * Bring the tunnel up for a server config.
 *
 * The config is turned into a full Xray JSON document here, so the native side stays
 * protocol-agnostic. Resolves only once the TUN exists, the core is running and the
 * bridge is up.
 */
export async function connectServer(config: ServerConfig, mtu = 1500): Promise<boolean> {
  const json = buildXrayConfig(config);
  return requireModule().connectXrayAsync(json, mtu);
}

/** Bring the tunnel up from an already-built Xray JSON config. */
export async function connectConfigJson(configJson: string, mtu = 1500): Promise<boolean> {
  return requireModule().connectXrayAsync(configJson, mtu);
}

export async function disconnectTunnel(): Promise<boolean> {
  if (!native) return true;
  return native.disconnectAsync();
}

export async function getTunnelStatus(): Promise<TunnelStatus | null> {
  if (!native) return null;
  try {
    return await native.getStatusAsync();
  } catch {
    return null;
  }
}

/** A real TCP connect probe. Proves the address and port accept a connection. */
export async function probeTcp(host: string, port: number, timeoutMs = 3000): Promise<ReachProbe> {
  if (!native) return { ok: false, ms: 0, error: 'The native probe is unavailable in this build.' };
  try {
    return await native.probeTcpAsync(host, port, timeoutMs);
  } catch (e) {
    return { ok: false, ms: 0, error: e instanceof Error ? e.message : String(e) };
  }
}

/** A real TLS handshake probe that presents `sni`. */
export async function probeTls(
  host: string,
  port: number,
  sni: string,
  timeoutMs = 4000,
): Promise<ReachProbe> {
  if (!native) return { ok: false, ms: 0, error: 'The native probe is unavailable in this build.' };
  try {
    return await native.probeTlsAsync(host, port, sni, timeoutMs);
  } catch (e) {
    return { ok: false, ms: 0, error: e instanceof Error ? e.message : String(e) };
  }
}

/**
 * The real test: start the core with this config and fetch a page through it.
 *
 * This is the only check that can honestly say a config works — a success means traffic
 * actually left through the server, not merely that a port was open.
 */
export async function testConfig(config: ServerConfig, timeoutMs = 12000): Promise<ConfigTestResult> {
  if (!native) {
    return { ok: false, ms: 0, ip: null, error: 'The native core is unavailable in this build.' };
  }
  try {
    return await native.testConfigAsync(buildXrayConfig(config), timeoutMs);
  } catch (e) {
    return { ok: false, ms: 0, ip: null, error: e instanceof Error ? e.message : String(e) };
  }
}

/** Test an already-built Xray JSON config. */
export async function testConfigJson(configJson: string, timeoutMs = 12000): Promise<ConfigTestResult> {
  if (!native) {
    return { ok: false, ms: 0, ip: null, error: 'The native core is unavailable in this build.' };
  }
  try {
    return await native.testConfigAsync(configJson, timeoutMs);
  } catch (e) {
    return { ok: false, ms: 0, ip: null, error: e instanceof Error ? e.message : String(e) };
  }
}

/**
 * Probe one WARP endpoint with a **real WireGuard handshake**.
 *
 * WireGuard is UDP, so a TCP connect to 2408/500/1701/4500 is closed on every WARP edge.
 * A success here means the peer accepted our key, our MAC and our ciphertext.
 */
export async function probeEndpoint(
  host: string,
  port: number,
  privateKey: string,
  peerPublicKey: string,
  timeoutMs = 3000,
): Promise<{ ok: boolean; ms: number; error: string | null; port?: number; colo?: string | null; loc?: string | null }> {
  if (!native) {
    return { ok: false, ms: 0, error: 'The native probe is unavailable in this build.', port };
  }
  try {
    const result = await native.probeWgAsync(host, port, privateKey, peerPublicKey, timeoutMs);
    return { ...result, port };
  } catch (e) {
    return { ok: false, ms: 0, error: e instanceof Error ? e.message : String(e), port };
  }
}

/**
 * Probe many WARP endpoints concurrently with real handshakes.
 *
 * `onProgress` is called for each result as it lands, so the UI can stream results instead
 * of waiting for the whole scan.
 */
export async function probeMany(
  targets: { host: string; port: number }[],
  privateKey: string,
  peerPublicKey: string,
  options: {
    timeoutMs?: number;
    concurrency?: number;
    resolveColo?: boolean;
    onProgress?: (result: {
      host: string;
      ok: boolean;
      ms: number;
      error: string | null;
      port?: number;
      colo?: string | null;
      loc?: string | null;
    }) => void;
  } = {},
): Promise<
  {
    host: string;
    ok: boolean;
    ms: number;
    error: string | null;
    port?: number;
    colo?: string | null;
    loc?: string | null;
  }[]
> {
  if (!native) return [];
  const { timeoutMs = 3000, concurrency = 64, resolveColo = false, onProgress } = options;

  let subscription: { remove: () => void } | null = null;
  if (onProgress) {
    subscription = native.addListener('onScanProgress', (payload) => {
      const p = payload as {
        host?: string;
        port?: number;
        ok?: boolean;
        ms?: number;
        error?: string | null;
        colo?: string | null;
        loc?: string | null;
      };
      if (!p?.host) return;
      onProgress({
        host: p.host,
        ok: Boolean(p.ok),
        ms: p.ms ?? 0,
        error: p.error ?? null,
        port: p.port,
        colo: p.colo ?? null,
        loc: p.loc ?? null,
      });
    });
  }

  try {
    // The native side already puts the host on every result, so the array is used as-is.
    // (The previous build re-attached hosts by array index, which was wrong: results come
    // back in completion order, not target order, so every row could show another
    // endpoint's address.)
    return await native.probeManyAsync(
      targets,
      privateKey,
      peerPublicKey,
      timeoutMs,
      concurrency,
      resolveColo,
    );
  } finally {
    subscription?.remove();
  }
}

/** Stop a running scan at the next endpoint. */
export async function cancelScan(): Promise<void> {
  if (!native) return;
  try {
    await native.cancelScanAsync();
  } catch {
    // Nothing running.
  }
}

/** Read the Cloudflare data centre an endpoint routes to, through that exact address. */
export async function resolveColo(
  host: string,
  timeoutMs = 4000,
): Promise<{ colo: string | null; loc: string | null }> {
  if (!native) return { colo: null, loc: null };
  try {
    return await native.resolveColoAsync(host, timeoutMs);
  } catch {
    return { colo: null, loc: null };
  }
}
