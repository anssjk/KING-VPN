/**
 * Cloudflare's published IP ranges.
 *
 * ## Why fetch them instead of hard-coding
 *
 * Cloudflare publishes the ranges it serves from at two stable, official URLs:
 *
 *   - `https://www.cloudflare.com/ips-v4`
 *   - `https://www.cloudflare.com/ips-v6`
 *
 * They change rarely, but they *do* change, and a hard-coded list silently goes stale —
 * which is one reason a scanner can stop finding anything. Fetching them means the scan
 * always covers what Cloudflare actually announces today.
 *
 * ## Scope and consent
 *
 * These are Cloudflare's own published ranges, and the app only ever connects to them the
 * way any client would: a TCP connect, a TLS handshake, or a WireGuard handshake. It does
 * not scan arbitrary third-party addresses, and it does not port-scan hosts it has no
 * reason to talk to. The ranges are also the ones the app's own traffic already goes
 * through, so testing them is testing the path the user is about to use.
 */

/** The official v4 range list. */
export const CLOUDFLARE_IPV4_URL = 'https://www.cloudflare.com/ips-v4';

/** The official v6 range list. */
export const CLOUDFLARE_IPV6_URL = 'https://www.cloudflare.com/ips-v6';

export type RangeFetchResult = {
  /** The ranges, in CIDR form, exactly as Cloudflare published them. */
  ranges: string[];
  /** True when the list came from the network; false when the built-in fallback was used. */
  live: boolean;
  /** Why the live fetch failed, when it did. */
  error: string | null;
};

/**
 * A small built-in fallback, used only when the live fetch fails.
 *
 * These are the ranges the app's own WARP endpoints live in, so they are always a valid
 * subset. The fallback is deliberately *not* presented as the full list: `live: false`
 * tells the UI to say the list could not be refreshed.
 */
export const FALLBACK_RANGES: string[] = [
  '162.159.192.0/24',
  '162.159.193.0/24',
  '162.159.195.0/24',
  '162.159.204.0/24',
  '188.114.96.0/24',
  '188.114.97.0/24',
  '188.114.98.0/24',
  '188.114.99.0/24',
];

/**
 * Fetch Cloudflare's published IPv4 ranges.
 *
 * A network failure is not fatal: the built-in fallback is returned with `live: false` so
 * the scanner can still run, and the UI can say the list is the cached one.
 */
export async function fetchCloudflareRanges(timeoutMs = 8000): Promise<RangeFetchResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(CLOUDFLARE_IPV4_URL, {
      headers: { Accept: 'text/plain' },
      cache: 'no-store',
      signal: controller.signal,
    });
    if (!res.ok) {
      return { ranges: FALLBACK_RANGES, live: false, error: `Cloudflare returned ${res.status}.` };
    }
    const text = await res.text();
    const ranges = text
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => /^\d{1,3}(\.\d{1,3}){3}\/\d{1,2}$/.test(line));
    if (ranges.length === 0) {
      return { ranges: FALLBACK_RANGES, live: false, error: 'The range list was empty.' };
    }
    return { ranges, live: true, error: null };
  } catch (e) {
    return {
      ranges: FALLBACK_RANGES,
      live: false,
      error: e instanceof Error ? e.message : 'Could not reach Cloudflare.',
    };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Expand a CIDR block into individual addresses.
 *
 * `limit` caps how many addresses one block contributes, so a `/16` cannot blow up the
 * scan list. The default keeps a whole `/24` (254 hosts) and truncates anything larger.
 */
export function expandCidr(cidr: string, limit = 254): string[] {
  const [base, bitsRaw] = cidr.split('/');
  const bits = Number(bitsRaw);
  const octets = base.split('.').map(Number);
  if (octets.length !== 4 || octets.some((o) => !Number.isFinite(o))) return [];
  if (!Number.isFinite(bits) || bits < 8 || bits > 32) return [];

  const hostBits = 32 - bits;
  const total = Math.min(2 ** hostBits, limit + 2);
  const baseInt =
    ((octets[0] << 24) >>> 0) + (octets[1] << 16) + (octets[2] << 8) + octets[3];

  const out: string[] = [];
  // Skip the network address (i = 0) and the broadcast address (i = total - 1).
  for (let i = 1; i < total - 1 && out.length < limit; i += 1) {
    const value = (baseInt + i) >>> 0;
    out.push(
      `${(value >>> 24) & 0xff}.${(value >>> 16) & 0xff}.${(value >>> 8) & 0xff}.${value & 0xff}`,
    );
  }
  return out;
}

/**
 * Build a scan list from a set of ranges.
 *
 * `perRange` caps each block, so a scan stays bounded no matter how large the published
 * list is. The result is deduplicated.
 */
export function hostsFromRanges(ranges: string[], perRange = 254): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const range of ranges) {
    for (const host of expandCidr(range, perRange)) {
      if (seen.has(host)) continue;
      seen.add(host);
      out.push(host);
    }
  }
  return out;
}
