/**
 * Network layer: probing, connecting and scanning.
 *
 * Two different things live here, and keeping them apart is the point:
 *
 *  - **Probing** (`pingHost`, `scanEndpoints`) measures whether an endpoint is reachable
 *    from the current network. It performs a **real WireGuard handshake** through the
 *    native module. That is the only probe that means anything: WireGuard is UDP, so a
 *    TCP connect to 2408/500/1701/4500 is closed on every WARP edge and reports healthy
 *    endpoints as unreachable — which is exactly what the previous build did.
 *  - **Connecting** (`connectThrough`) brings up the actual WireGuard tunnel. It is not
 *    a request; it is `VpnService` + `libwg-go` routing traffic through the peer.
 *
 * `describeError()` turns raw Java exceptions into sentences a person can act on, while
 * keeping the technical detail for support.
 */
import { probeEndpoint, probeMany, cancelScan, type ScanTarget } from '@/lib/tunnel';
import {
  WARP_PORT,
  WARP_SNI,
  candidatesFor,
  endpointFor,
  type Protocol,
  type ResolvedEndpoint,
} from '@/lib/nodes';

const PING_TIMEOUT_MS = 3000;

export type TraceInfo = {
  ip: string;
  loc: string;
  colo: string;
  warp: string;
  http: string;
  tls: string;
  /** The endpoint that produced this trace. */
  host: string;
};

export type PingResult = {
  host: string;
  ok: boolean;
  /** Median round-trip in ms across the samples that succeeded. */
  ms: number;
  /** Fastest sample, in ms. */
  best: number;
  /** Spread between fastest and slowest sample, in ms — a stability signal. */
  jitter: number;
  /** 0..1 — share of samples that failed. */
  loss: number;
  /** Samples attempted. */
  samples: number;
  /** The port that was measured — the same port the tunnel will dial. */
  port: number;
  /** Country code the edge reported for this path, when the probe read a trace. */
  loc?: string;
  /** Cloudflare data centre that answered, when the probe read a trace. */
  colo?: string;
  /** Human-readable reason when `ok` is false. */
  error?: string;
};

/**
 * Turn a thrown value into something a person can read.
 *
 * Android's networking rejects with messages like
 * `java.net.SocketException: Connection reset` or
 * `java.net.UnknownHostException: Unable to resolve host ...`. Those are accurate but
 * useless in a UI, so each known shape gets a plain sentence. `detail` keeps the original
 * text for the support channel.
 */
export function describeError(e: unknown): { message: string; detail: string } {
  const detail = e instanceof Error ? e.message : String(e);
  const low = detail.toLowerCase();

  if (low.includes('abort')) {
    return { message: 'The endpoint did not answer in time.', detail };
  }
  if (low.includes('connection reset') || low.includes('econnreset') || low.includes('socketexception')) {
    return {
      message: 'The network reset the connection. This address is blocked here — trying another one.',
      detail,
    };
  }
  if (low.includes('unknownhost') || low.includes('unable to resolve') || low.includes('nodename nor servname')) {
    return { message: 'That address could not be resolved. Check your connection or DNS.', detail };
  }
  if (low.includes('timeout') || low.includes('timed out') || low.includes('etimedout')) {
    return { message: 'The connection timed out. The endpoint may be filtered on this network.', detail };
  }
  if (low.includes('network request failed') || low.includes('failed to fetch') || low.includes('networkerror')) {
    return { message: 'No network response. Check that mobile data or Wi-Fi is on.', detail };
  }
  if (low.includes('certificate') || low.includes('ssl') || low.includes('tls')) {
    return { message: 'The secure handshake failed. This endpoint cannot be trusted from here.', detail };
  }
  if (low.includes('permission')) {
    return { message: 'Android has not granted VPN permission. Accept the system request first.', detail };
  }
  if (low.includes('no native vpn module') || low.includes('vpn module is not available')) {
    return {
      message: 'This build has no native VPN module. Install a development or release APK — Expo Go cannot create a VPN.',
      detail,
    };
  }
  return { message: 'Could not reach the endpoint.', detail };
}

/**
 * Measure one endpoint with `samples` real WireGuard handshakes.
 *
 * Latency is the median of the successful samples (robust against one slow outlier),
 * `jitter` is the spread, and `loss` is the share that failed.
 */
export async function pingHost(
  host: string,
  samples = 1,
  timeoutMs = PING_TIMEOUT_MS,
  port: number = WARP_PORT,
  privateKey = '',
  peerPublicKey = '',
): Promise<PingResult> {
  const times: number[] = [];
  let failures = 0;
  let lastError: string | undefined;
  let colo: string | undefined;
  let loc: string | undefined;

  for (let i = 0; i < Math.max(1, samples); i += 1) {
    const result = await probeEndpoint(host, port, privateKey, peerPublicKey, timeoutMs);
    if (result.ok) {
      times.push(result.ms);
      if (result.colo) colo = result.colo;
      if (result.loc) loc = result.loc;
    } else {
      failures += 1;
      lastError = result.error ?? 'unreachable';
    }
  }

  const total = Math.max(1, samples);
  if (times.length === 0) {
    return {
      host,
      ok: false,
      ms: 0,
      best: 0,
      jitter: 0,
      loss: 1,
      samples: total,
      port,
      error: lastError ?? 'unreachable',
    };
  }
  const sorted = [...times].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  return {
    host,
    ok: true,
    ms: median,
    best: sorted[0],
    jitter: sorted[sorted.length - 1] - sorted[0],
    loss: failures / total,
    samples: total,
    port,
    colo,
    loc,
  };
}

export type ConnectAttempt = {
  host: string;
  ok: boolean;
  ms?: number;
  error?: string;
};

export type ConnectResult = {
  /** The endpoint the tunnel was actually dialled through. */
  host: string;
  /**
   * The fully resolved endpoint — address, port and SNI — that the tunnel config is
   * built from. This is the value the scanner produced, carried through unchanged, so
   * the tunnel dials exactly the address and port that were measured.
   */
  endpoint: ResolvedEndpoint;
  /** Every endpoint tried before it, in order — shown in the UI as a fallback log. */
  attempts: ConnectAttempt[];
};

/**
 * Pick the endpoint to dial.
 *
 * The selected node is tried first, then the rest of the protocol's pool. Each candidate
 * is probed with a real handshake; the first that answers is returned. This is a
 * *selection* step — the tunnel itself is brought up by the caller with the returned
 * host, so a filtered anycast range can no longer produce a dead-end error.
 */
export async function connectThrough(
  protocol: Protocol,
  selectedHost: string | undefined,
  privateKey: string,
  peerPublicKey: string,
  onAttempt?: (attempt: ConnectAttempt, index: number, total: number) => void,
  port: number = WARP_PORT,
): Promise<ConnectResult> {
  const candidates = candidatesFor(protocol, selectedHost);
  const attempts: ConnectAttempt[] = [];
  let lastError = 'No endpoint answered.';

  for (let i = 0; i < candidates.length; i += 1) {
    const host = candidates[i];
    const probe = await probeEndpoint(host, port, privateKey, peerPublicKey, PING_TIMEOUT_MS);
    if (probe.ok) {
      const attempt: ConnectAttempt = { host, ok: true, ms: probe.ms };
      attempts.push(attempt);
      onAttempt?.(attempt, i + 1, candidates.length);
      return {
        host,
        endpoint: { host, port: probe.port ?? port, sni: WARP_SNI },
        attempts,
      };
    }
    const message = probe.error ?? 'unreachable';
    lastError = message;
    const attempt: ConnectAttempt = { host, ok: false, error: message };
    attempts.push(attempt);
    onAttempt?.(attempt, i + 1, candidates.length);
  }

  const err = new Error(lastError);
  (err as Error & { attempts?: ConnectAttempt[] }).attempts = attempts;
  throw err;
}

export type ScanOptions = {
  /** Round trips per endpoint. 1 is enough for a handshake scan; 3 gives a jitter figure. */
  samples?: number;
  /** How many endpoints are probed at once. */
  concurrency?: number;
  /** Per-request timeout. */
  timeoutMs?: number;
  /** Port to probe — the tunnel port, so the measurement matches the real path. */
  port?: number;
  /** The device's WireGuard private key, so the handshake is the real one. */
  privateKey: string;
  /** Cloudflare's peer public key. */
  peerPublicKey: string;
  /** Read the data centre and country for each successful endpoint. */
  resolveColo?: boolean;
  /** Called after each endpoint finishes, with the running result list. */
  onResult?: (result: PingResult, done: number, total: number) => void;
  /** Return true to stop early (the UI's Cancel button). */
  shouldStop?: () => boolean;
};

export type ScanSummary = {
  results: PingResult[];
  /** Endpoints that answered, fastest first. */
  reachable: PingResult[];
  total: number;
  done: number;
  cancelled: boolean;
  /** Wall-clock duration of the scan, in ms. */
  durationMs: number;
};

/**
 * Probe a list of endpoints concurrently with real WireGuard handshakes.
 *
 * Failures are kept too, so the UI can show "12 of 21 answered" and let the user see
 * which addresses are blocked on their network. It is cancellable, reports progress per
 * endpoint, and never rejects: a scan that finds nothing returns an empty `reachable`
 * list rather than throwing.
 */
export async function scanEndpoints(targets: ScanTarget[], options: ScanOptions): Promise<ScanSummary> {
  const samples = options.samples ?? 1;
  const concurrency = Math.max(1, options.concurrency ?? 64);
  const timeoutMs = options.timeoutMs ?? PING_TIMEOUT_MS;
  const started = Date.now();

  // Deduplicate on host:port so a repeated target is not probed twice.
  const seen = new Set<string>();
  const unique: ScanTarget[] = [];
  for (const t of targets) {
    const key = `${t.host}:${t.port}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(t);
  }

  const results: PingResult[] = [];
  let done = 0;
  let cancelled = false;

  const record = (r: PingResult) => {
    results.push(r);
    done += 1;
    options.onResult?.(r, done, unique.length);
  };

  if (samples <= 1) {
    // One handshake per endpoint: use the native batch path, which streams results.
    const batch = await probeMany(unique, options.privateKey, options.peerPublicKey, {
      timeoutMs,
      concurrency,
      resolveColo: options.resolveColo ?? false,
      onProgress: (p) => {
        if (options.shouldStop?.()) {
          cancelled = true;
          return;
        }
        record({
          host: p.host,
          ok: p.ok,
          ms: p.ms,
          best: p.ms,
          jitter: 0,
          loss: p.ok ? 0 : 1,
          samples: 1,
          port: p.port ?? WARP_PORT,
          colo: p.colo ?? undefined,
          loc: p.loc ?? undefined,
          error: p.error ?? undefined,
        });
      },
    });
    // If the event stream delivered nothing (older native build), fall back to the array.
    if (results.length === 0 && batch.length > 0) {
      for (const r of batch) {
        record({
          host: r.host,
          ok: r.ok,
          ms: r.ms,
          best: r.ms,
          jitter: 0,
          loss: r.ok ? 0 : 1,
          samples: 1,
          port: r.port ?? WARP_PORT,
          colo: r.colo ?? undefined,
          loc: r.loc ?? undefined,
          error: r.error ?? undefined,
        });
      }
    }
  } else {
    // Multiple samples per endpoint: run them in waves so progress stays smooth.
    let cursor = 0;
    const worker = async () => {
      for (;;) {
        if (options.shouldStop?.()) {
          cancelled = true;
          return;
        }
        const index = cursor;
        cursor += 1;
        if (index >= unique.length) return;
        const t = unique[index];
        const r = await pingHost(
          t.host,
          samples,
          timeoutMs,
          t.port,
          options.privateKey,
          options.peerPublicKey,
        );
        record(r);
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, unique.length) }, worker));
  }

  const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
  return {
    results,
    reachable,
    total: unique.length,
    done,
    cancelled,
    durationMs: Date.now() - started,
  };
}

/** Stop a running native scan. */
export async function stopScan(): Promise<void> {
  await cancelScan();
}

/** The `host:port` a tunnel dials for a node — re-exported for the connect flow. */
export { endpointFor };

const VERIFY_TIMEOUT_MS = 10000;

export type TokenVerifyResult = {
  ok: boolean;
  status: 'active' | 'invalid' | 'unknown';
  message: string;
};

/**
 * Verify a Cloudflare API token against the official endpoint. A network failure is
 * reported as `unknown` so the app can still continue offline rather than blocking the
 * user on a flaky connection.
 */
export async function verifyToken(token: string): Promise<TokenVerifyResult> {
  const trimmed = token.trim();
  if (!trimmed) {
    return { ok: false, status: 'invalid', message: 'Token is empty.' };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), VERIFY_TIMEOUT_MS);
  try {
    const res = await fetch('https://api.cloudflare.com/client/v4/user/tokens/verify', {
      headers: {
        Authorization: `Bearer ${trimmed}`,
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
    });
    const body = (await res.json().catch(() => null)) as
      | { success?: boolean; result?: { status?: string }; errors?: { message?: string }[] }
      | null;
    if (res.ok && body?.success && body.result?.status === 'active') {
      return { ok: true, status: 'active', message: 'Token is active.' };
    }
    const message = body?.errors?.[0]?.message ?? `Token rejected (${res.status}).`;
    return { ok: false, status: 'invalid', message };
  } catch {
    return {
      ok: false,
      status: 'unknown',
      message: 'Could not reach Cloudflare. Check your connection.',
    };
  }
}

/**
 * Read the caller's public IP, country and edge colo through one endpoint.
 *
 * Used by onboarding as a "is the network up" check. It is deliberately *not* used to
 * decide whether the VPN is connected — that is the tunnel's own job.
 */
export async function fetchTrace(host = '1.1.1.1', timeoutMs = PING_TIMEOUT_MS): Promise<TraceInfo> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`https://${host}/cdn-cgi/trace`, {
      headers: { Accept: 'text/plain' },
      cache: 'no-store',
      signal: controller.signal,
    });
    if (!res.ok) {
      throw new Error(`trace failed (${res.status})`);
    }
    const text = await res.text();
    const map: Record<string, string> = {};
    for (const line of text.split('\n')) {
      const idx = line.indexOf('=');
      if (idx > 0) map[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
    }
    if (!map.ip) {
      throw new Error('trace returned no ip');
    }
    return {
      ip: map.ip,
      loc: map.loc ?? '',
      colo: map.colo ?? '',
      warp: map.warp ?? 'off',
      http: map.http ?? '',
      tls: map.tls ?? '',
      host,
    };
  } finally {
    clearTimeout(timer);
  }
}
