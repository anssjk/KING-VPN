/**
 * The user's own servers.
 *
 * A server is a parsed `ServerConfig` (see `xray-config.ts`) plus the small amount of
 * state the UI needs: when it was added and the result of the last real test. The list is
 * kept on the device, so the servers a user adds survive a restart.
 *
 * Nothing here invents a server. A config only enters the list after it has been parsed
 * from something the user actually supplied — a link, a subscription or a JSON config.
 */
import { useCallback } from 'react';

import { usePersistentState } from '@/hooks/use-persistent-state';
import type { ServerConfig } from '@/lib/xray-config';

export type ServerTestState = {
  /** True when the last config test passed — traffic really went through the server. */
  verified: boolean;
  /** The exit IP the server reported, when the test passed. */
  exitIp: string | null;
  /** Round-trip of the test, in ms. */
  ms: number;
  /** When the test ran, epoch millis. */
  at: number;
  /** The reason, when the test failed. */
  error: string | null;
};

export type StoredServer = {
  config: ServerConfig;
  /** Epoch millis the server was added. */
  addedAt: number;
  /** The last test result, or null when it has never been tested. */
  test: ServerTestState | null;
};

const STORAGE_KEY = 'xray_servers';

/**
 * The server list, persisted on the device.
 *
 * `add` de-duplicates on the config id, so adding the same link twice updates the existing
 * entry instead of creating a duplicate row.
 */
export function useServers() {
  const [servers, setServers, status] = usePersistentState<StoredServer[]>(STORAGE_KEY, []);

  const add = useCallback(
    (configs: ServerConfig[]) => {
      if (configs.length === 0) return 0;
      let added = 0;
      setServers((prev) => {
        const byId = new Map(prev.map((s) => [s.config.id, s]));
        for (const config of configs) {
          if (byId.has(config.id)) {
            // Refresh the stored config (a re-added link may carry new fields) but keep
            // the test result, which is still about the same endpoint.
            const existing = byId.get(config.id)!;
            byId.set(config.id, { ...existing, config });
          } else {
            byId.set(config.id, { config, addedAt: Date.now(), test: null });
            added += 1;
          }
        }
        return Array.from(byId.values());
      });
      return added;
    },
    [setServers],
  );

  const remove = useCallback(
    (id: string) => {
      setServers((prev) => prev.filter((s) => s.config.id !== id));
    },
    [setServers],
  );

  const setTest = useCallback(
    (id: string, test: ServerTestState) => {
      setServers((prev) => prev.map((s) => (s.config.id === id ? { ...s, test } : s)));
    },
    [setServers],
  );

  const clear = useCallback(() => setServers([]), [setServers]);

  return { servers, add, remove, setTest, clear, status };
}
