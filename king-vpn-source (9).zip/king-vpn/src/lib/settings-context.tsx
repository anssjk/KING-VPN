import { createContext, useCallback, useContext, useMemo, type ReactNode } from 'react';

import { usePersistentState } from '@/hooks/use-persistent-state';
import { translate, type Lang, type StringKey } from '@/lib/i18n';

export type ThemeMode = 'light' | 'dark';

type SettingsValue = {
  lang: Lang;
  theme: ThemeMode;
  setLang: (lang: Lang) => void;
  setTheme: (theme: ThemeMode) => void;
  t: (key: StringKey) => string;
  /** True when the layout should be right-to-left (Persian). */
  rtl: boolean;
};

const SettingsContext = createContext<SettingsValue | null>(null);

/**
 * App-wide language + theme. Both are kept on the phone, so the choice survives a
 * restart, and every screen reads them through `useSettings()`.
 */
export function SettingsProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = usePersistentState<Lang>('lang', 'en');
  const [theme, setTheme] = usePersistentState<ThemeMode>('theme', 'dark');

  const t = useCallback((key: StringKey) => translate(lang, key), [lang]);

  const value = useMemo<SettingsValue>(
    () => ({ lang, theme, setLang, setTheme, t, rtl: lang === 'fa' }),
    [lang, theme, setLang, setTheme, t],
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsValue {
  const value = useContext(SettingsContext);
  if (!value) {
    throw new Error('useSettings must be used inside SettingsProvider');
  }
  return value;
}
