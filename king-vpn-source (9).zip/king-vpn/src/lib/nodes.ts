/**
 * Endpoint catalogue and scan-target generation.
 *
 * ## What changed and why
 *
 * The previous build scanned **9 endpoints on one port** and probed them with a TCP
 * connect. Two things were wrong with that:
 *
 *  1. **The port was wrong for the probe.** WireGuard is UDP. A TCP connect to 2408 is
 *     closed on every WARP edge, so healthy endpoints were reported as unreachable.
 *  2. **The list was far too small.** Cloudflare announces WARP on eight /24 ranges, and
 *     each address in them is a separate anycast endpoint. Scanning nine of the ~2000
 *     available addresses is why the scanner "found almost nothing".
 *
 * This file now describes the **whole** space: every address in the eight ranges, crossed
 * with the four ports Cloudflare actually serves WireGuard on. The scanner probes all of
 * them with a real handshake and keeps the best 100.
 *
 * ## About countries
 *
 * WARP is anycast: the same address is announced from many data centres, and which one
 * answers is decided by routing from the user's own network. Cloudflare does not expose a
 * country picker, and the exit country follows the user's own location — so an app cannot
 * honestly promise "connect to Germany". What it *can* do is **measure** which data centre
 * and country each endpoint actually routes to from this device, and rank the results by
 * that. That is what `PREFERRED_COUNTRIES` and the measured `loc` field are for.
 */

export type Protocol = 'ip' | 'psiphon' | 'warp';

export type EndpointKind = 'ip' | 'host';

export type NodeItem = {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  flag: string;
  protocol: Protocol;
  host: string;
  kind: EndpointKind;
  basePing: number;
  note?: string;
};

/**
 * The eight /24 ranges Cloudflare announces WARP on.
 *
 * These are the ranges the official client dials. Every address in them is a valid
 * WireGuard endpoint, which is what makes a large scan worthwhile: two addresses in the
 * same range can route to different data centres from the same phone.
 */
export const WARP_RANGES: string[] = [
  '162.159.192',
  '162.159.193',
  '162.159.195',
  '162.159.204',
  '188.114.96',
  '188.114.97',
  '188.114.98',
  '188.114.99',
];

/**
 * The ports Cloudflare serves WireGuard on.
 *
 * 2408 is the default. 500, 1701 and 4500 are the documented fallbacks, and on a network
 * that filters 2408 one of the others is often open — which is exactly why the scanner
 * tests all four rather than assuming the default.
 */
export const WARP_PORTS: number[] = [2408, 500, 1701, 4500];

/** The port used when nothing has been measured yet. */
export const WARP_PORT = 2408;

/**
 * The TLS server name the Cloudflare edge expects.
 *
 * A bare anycast IP does not answer HTTPS without the right SNI, and the edge will not
 * present a valid certificate for an IP literal. Every transport that speaks TLS to the
 * edge must carry this name alongside the IP it dials.
 */
export const WARP_SNI = 'engage.cloudflareclient.com';

/** The hostname endpoint — Cloudflare routes it to the nearest healthy edge. */
export const WARP_HOST = 'engage.cloudflareclient.com';

/**
 * A fully resolved endpoint: the address the tunnel dials, the port it dials, and the
 * server name that address must be presented as.
 *
 * This is the single shape that travels from the scanner into the tunnel config, so the
 * IP and port the scanner measured are the exact ones the tunnel uses.
 */
export type ResolvedEndpoint = {
  host: string;
  port: number;
  sni: string;
};

/**
 * Build the resolved endpoint for a scanned address.
 *
 * `port` is whatever the scanner actually completed a handshake on, so a node that only
 * answers on a fallback port keeps that port all the way into the tunnel.
 */
export function resolveEndpoint(host: string, port: number = WARP_PORT, sni: string = WARP_SNI): ResolvedEndpoint {
  const trimmed = host.trim();
  const hasPort = /:\d+$/.test(trimmed);
  return {
    host: hasPort ? trimmed.replace(/:\d+$/, '') : trimmed,
    port: hasPort ? Number(trimmed.split(':').pop()) : port,
    sni,
  };
}

/**
 * A display-safe label for an endpoint.
 *
 * The resolved IP, port and SNI are operational details: showing them invites the user to
 * copy a value that only works from their current network, and it exposes which edge they
 * are pinned to. Screens show this label instead of the raw address.
 */
export function maskEndpoint(host: string): string {
  const trimmed = host.trim();
  if (!trimmed) return 'Hidden endpoint';
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(trimmed)) {
    const parts = trimmed.split('.');
    return `${parts[0]}.${parts[1]}.\u2022\u2022\u2022.\u2022\u2022\u2022`;
  }
  const dot = trimmed.indexOf('.');
  if (dot > 0) return `${trimmed.slice(0, Math.min(3, dot))}\u2022\u2022\u2022${trimmed.slice(trimmed.lastIndexOf('.'))}`;
  return '\u2022\u2022\u2022\u2022\u2022\u2022';
}

/**
 * Every address in the WARP ranges.
 *
 * 8 ranges × 254 usable addresses = 2032 endpoints. `.0` and `.255` are skipped: they are
 * the network and broadcast addresses of the range and are not announced as hosts.
 */
export function allWarpIps(): string[] {
  const out: string[] = [];
  for (const range of WARP_RANGES) {
    for (let i = 1; i <= 254; i += 1) {
      out.push(`${range}.${i}`);
    }
  }
  return out;
}

/** A single thing to probe: one address on one port. */
export type ScanTarget = { host: string; port: number };

/**
 * Build the full scan list: every address crossed with every port.
 *
 * `ports` defaults to all four. Passing a single port gives a much faster scan when the
 * user only wants a quick answer.
 */
export function buildScanTargets(hosts: string[] = allWarpIps(), ports: number[] = WARP_PORTS): ScanTarget[] {
  const targets: ScanTarget[] = [];
  for (const host of hosts) {
    for (const port of ports) {
      targets.push({ host, port });
    }
  }
  return targets;
}

/**
 * Countries the user asked to prefer, in order.
 *
 * These are used to **rank** measured results, not to force a route: an endpoint is only
 * marked with a country after the scanner has actually read that country from the edge
 * through that address. WARP cannot be pinned to a country, so this is a preference over
 * what was measured, never a promise.
 */
export const PREFERRED_COUNTRIES: string[] = [
  'GB', // United Kingdom
  'TR', // Turkey
  'US', // United States
  'DE', // Germany
  'NL', // Netherlands
  'FR', // France
  'SE', // Sweden
  'CH', // Switzerland
  'AT', // Austria
  'PL', // Poland
  'IT', // Italy
  'ES', // Spain
  'CA', // Canada
  'JP', // Japan
];

/** How many results the scanner keeps. */
export const TOP_RESULTS = 100;

/** The catalogue shown on the Nodes screen before any scan has run. */
export const NODES: NodeItem[] = [
  {
    id: 'warp-auto',
    name: 'WARP Auto',
    country: 'Global — automatic',
    countryCode: 'CF',
    flag: '\u{1F310}',
    protocol: 'warp',
    host: WARP_HOST,
    kind: 'host',
    basePing: 90,
    note: 'Cloudflare picks the nearest healthy edge',
  },
  {
    id: 'warp-ip-1',
    name: 'WARP 162.159.192.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F310}',
    protocol: 'ip',
    host: '162.159.192.1',
    kind: 'ip',
    basePing: 40,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-2',
    name: 'WARP 162.159.193.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F310}',
    protocol: 'ip',
    host: '162.159.193.1',
    kind: 'ip',
    basePing: 42,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-3',
    name: 'WARP 162.159.195.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F310}',
    protocol: 'ip',
    host: '162.159.195.1',
    kind: 'ip',
    basePing: 44,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-ip-4',
    name: 'WARP 162.159.204.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F310}',
    protocol: 'ip',
    host: '162.159.204.1',
    kind: 'ip',
    basePing: 46,
    note: 'Bare anycast IP — no DNS lookup',
  },
  {
    id: 'warp-psiphon-1',
    name: 'WARP 188.114.96.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F6E1}\u{FE0F}',
    protocol: 'psiphon',
    host: '188.114.96.1',
    kind: 'ip',
    basePing: 50,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-2',
    name: 'WARP 188.114.97.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F6E1}\u{FE0F}',
    protocol: 'psiphon',
    host: '188.114.97.1',
    kind: 'ip',
    basePing: 52,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-3',
    name: 'WARP 188.114.98.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F6E1}\u{FE0F}',
    protocol: 'psiphon',
    host: '188.114.98.1',
    kind: 'ip',
    basePing: 54,
    note: 'Alternative anycast range',
  },
  {
    id: 'warp-psiphon-4',
    name: 'WARP 188.114.99.1',
    country: 'Anycast — global',
    countryCode: 'CF',
    flag: '\u{1F6E1}\u{FE0F}',
    protocol: 'psiphon',
    host: '188.114.99.1',
    kind: 'ip',
    basePing: 56,
    note: 'Alternative anycast range',
  },
];

/** The endpoints the scanner probes when the user asks for a quick scan. */
export const SCAN_SEEDS: string[] = [WARP_HOST, ...WARP_RANGES.map((r) => `${r}.1`)];

/**
 * The ordered candidate list for a protocol.
 *
 * `connect()` walks this list when the selected endpoint fails, so one filtered anycast
 * address can never strand the user on an error.
 */
export function candidatesFor(protocol: Protocol, selectedHost?: string): string[] {
  const seeds = WARP_RANGES.map((r) => `${r}.1`);
  const pools: Record<Protocol, string[]> = {
    warp: [WARP_HOST, ...seeds],
    ip: [...seeds, WARP_HOST],
    psiphon: [...WARP_RANGES.slice(4).map((r) => `${r}.1`), ...seeds, WARP_HOST],
  };
  return dedupe([...(selectedHost ? [selectedHost] : []), ...pools[protocol]]);
}

/**
 * The `host:port` a tunnel dials.
 *
 * The port is a parameter, not a constant: the scanner reports the port it actually
 * completed a handshake on, and that is the port the tunnel must dial.
 */
export function endpointFor(host: string, port: number = WARP_PORT): string {
  if (host.includes(':')) return host;
  return `${host}:${port}`;
}

/** The catalogue entry for a host, when the scanner reports one it knows. */
export function nodeForHost(host: string): NodeItem | undefined {
  return NODES.find((n) => n.host === host);
}

function dedupe(list: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    const key = item.trim().toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item.trim());
  }
  return out;
}

/** Map an ISO country code to a flag emoji. */
export function flagFromCountryCode(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc)) return '\u{1F310}';
  return String.fromCodePoint(...[...cc].map((c) => 0x1f1e6 + c.charCodeAt(0) - 65));
}

/** A friendly country name for the common codes; falls back to the code itself. */
const COUNTRY_NAMES: Record<string, string> = {
  US: 'United States',
  GB: 'United Kingdom',
  DE: 'Germany',
  NL: 'Netherlands',
  FR: 'France',
  TR: 'Turkey',
  AE: 'United Arab Emirates',
  IN: 'India',
  SG: 'Singapore',
  JP: 'Japan',
  IR: 'Iran',
  CA: 'Canada',
  AU: 'Australia',
  BR: 'Brazil',
  RU: 'Russia',
  IT: 'Italy',
  ES: 'Spain',
  SE: 'Sweden',
  CH: 'Switzerland',
  PL: 'Poland',
  FI: 'Finland',
  NO: 'Norway',
  AT: 'Austria',
  BE: 'Belgium',
  IE: 'Ireland',
  PT: 'Portugal',
  RO: 'Romania',
  UA: 'Ukraine',
  IL: 'Israel',
  SA: 'Saudi Arabia',
  QA: 'Qatar',
  KW: 'Kuwait',
  OM: 'Oman',
  PK: 'Pakistan',
  AZ: 'Azerbaijan',
  AM: 'Armenia',
  GE: 'Georgia',
  CN: 'China',
  KR: 'South Korea',
  HK: 'Hong Kong',
  TW: 'Taiwan',
  TH: 'Thailand',
  MY: 'Malaysia',
  ID: 'Indonesia',
  VN: 'Vietnam',
  PH: 'Philippines',
  EG: 'Egypt',
  ZA: 'South Africa',
  NG: 'Nigeria',
  KE: 'Kenya',
  MA: 'Morocco',
  MX: 'Mexico',
  AR: 'Argentina',
  CL: 'Chile',
  CO: 'Colombia',
};

export function countryName(code: string): string {
  const cc = (code || '').trim().toUpperCase();
  return COUNTRY_NAMES[cc] ?? (cc || 'Unknown');
}

/** True when a measured country is one the user asked to prefer. */
export function isPreferredCountry(code: string | undefined): boolean {
  if (!code) return false;
  return PREFERRED_COUNTRIES.includes(code.trim().toUpperCase());
}
