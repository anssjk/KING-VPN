import { useCallback, useRef, useState } from 'react';

import { scanEndpoints, stopScan, type PingResult, type ScanSummary } from '@/lib/cloudflare';
import { probeManyReach, type ReachLevel } from '@/lib/reachability';
import type { ScanTarget } from '@/lib/nodes';

export type ScanPhase = 'idle' | 'running' | 'done' | 'cancelled';

/** Which probe the scan uses. */
export type ProbeKind = 'warp' | 'tcp' | 'tls';

export type ScannerState = {
  phase: ScanPhase;
  /** 0..1 */
  progress: number;
  done: number;
  total: number;
  /** Every endpoint measured so far, in completion order. */
  results: PingResult[];
  /** Endpoints that answered, fastest first. */
  reachable: PingResult[];
  summary: ScanSummary | null;
  error: string | null;
  /** Wall-clock duration of the last scan, in ms. */
  durationMs: number | null;
};

const INITIAL: ScannerState = {
  phase: 'idle',
  progress: 0,
  done: 0,
  total: 0,
  results: [],
  reachable: [],
  summary: null,
  error: null,
  durationMs: null,
};

export type ScanRequest = {
  targets: ScanTarget[];
  privateKey: string;
  peerPublicKey: string;
  samples?: number;
  concurrency?: number;
  timeoutMs?: number;
  resolveColo?: boolean;
  /**
   * Which probe to use.
   *
   *  - `warp` — a real WireGuard handshake. The right probe for a WARP endpoint, because
   *    WireGuard is UDP and a TCP connect to its ports is closed on every edge.
   *  - `tcp`  — a real TCP connect. The right first filter for a TCP-based transport.
   *  - `tls`  — a real TLS handshake presenting `sni`. Proves the address, the port and
   *    the server name all agree.
   */
  probe?: ProbeKind;
  /** The server name a TLS probe presents. */
  sni?: string;
};

/**
 * Drives a scan and exposes its live state.
 *
 * The scan itself lives in `scanEndpoints` (WARP handshakes) or `probeManyReach` (TCP/TLS);
 * this hook only owns the React state, the cancel flag and the progress maths, so the
 * screen stays a pure view. Results stream in as each endpoint finishes, which is what
 * makes a large scan feel alive instead of frozen behind a spinner.
 */
export function useScanner() {
  const [state, setState] = useState<ScannerState>(INITIAL);
  const stopRef = useRef(false);
  const runningRef = useRef(false);

  const start = useCallback(async (request: ScanRequest) => {
    if (runningRef.current) return;
    runningRef.current = true;
    stopRef.current = false;
    setState({ ...INITIAL, phase: 'running', total: request.targets.length });

    const started = Date.now();
    const probe = request.probe ?? 'warp';

    try {
      if (probe === 'warp') {
        const summary = await scanEndpoints(request.targets, {
          samples: request.samples ?? 1,
          concurrency: request.concurrency ?? 64,
          timeoutMs: request.timeoutMs ?? 3000,
          privateKey: request.privateKey,
          peerPublicKey: request.peerPublicKey,
          resolveColo: request.resolveColo ?? false,
          shouldStop: () => stopRef.current,
          onResult: (result, done, total) => {
            setState((prev) => {
              const results = [...prev.results, result];
              const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
              return {
                ...prev,
                results,
                reachable,
                done,
                total,
                progress: total > 0 ? done / total : 0,
              };
            });
          },
        });
        setState((prev) => ({
          ...prev,
          phase: summary.cancelled ? 'cancelled' : 'done',
          summary,
          reachable: summary.reachable,
          progress: 1,
          durationMs: summary.durationMs,
        }));
        return;
      }

      // TCP / TLS reachability scan.
      const level: ReachLevel = probe === 'tls' ? 'tls' : 'tcp';
      const results: PingResult[] = [];
      let done = 0;
      let cancelled = false;
      await probeManyReach(request.targets, level, request.sni ?? '', {
        concurrency: request.concurrency ?? 32,
        timeoutMs: request.timeoutMs ?? 3000,
        shouldStop: () => {
          if (stopRef.current) cancelled = true;
          return stopRef.current;
        },
        onResult: (r) => {
          const result: PingResult = {
            host: r.host,
            ok: r.ok,
            ms: r.ms,
            best: r.ms,
            jitter: 0,
            loss: r.ok ? 0 : 1,
            samples: 1,
            port: r.port,
            error: r.error ?? undefined,
          };
          results.push(result);
          done += 1;
          setState((prev) => {
            const all = [...prev.results, result];
            const reachable = all.filter((x) => x.ok).sort((a, b) => a.ms - b.ms);
            return {
              ...prev,
              results: all,
              reachable,
              done,
              total: request.targets.length,
              progress: request.targets.length > 0 ? done / request.targets.length : 0,
            };
          });
        },
      });
      const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
      setState((prev) => ({
        ...prev,
        phase: cancelled ? 'cancelled' : 'done',
        reachable,
        progress: 1,
        durationMs: Date.now() - started,
        summary: {
          results,
          reachable,
          total: request.targets.length,
          done,
          cancelled,
          durationMs: Date.now() - started,
        },
      }));
    } catch (e) {
      setState((prev) => ({
        ...prev,
        phase: 'done',
        error: e instanceof Error ? e.message : 'Scan failed',
      }));
    } finally {
      runningRef.current = false;
    }
  }, []);

  const cancel = useCallback(() => {
    stopRef.current = true;
    void stopScan();
  }, []);

  const reset = useCallback(() => {
    if (runningRef.current) return;
    setState(INITIAL);
  }, []);

  /** Replace the state with a previously saved scan. */
  const restore = useCallback((saved: { results: PingResult[]; durationMs: number | null }) => {
    if (runningRef.current) return;
    const reachable = saved.results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
    setState({
      ...INITIAL,
      phase: 'done',
      results: saved.results,
      reachable,
      done: saved.results.length,
      total: saved.results.length,
      progress: 1,
      durationMs: saved.durationMs,
    });
  }, []);

  return { ...state, start, cancel, reset, restore, running: state.phase === 'running' };
}
