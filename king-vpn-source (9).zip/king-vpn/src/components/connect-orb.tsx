import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useRef } from 'react';
import { ActivityIndicator, Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';

import { useColors } from '@/constants/theme';
import type { ConnStatus } from '@/lib/app-context';

type Props = {
  status: ConnStatus;
  label: string;
  hint: string;
  onPress: () => void;
};

const SIZE = 210;
const CORE = 150;

/**
 * The big connect control: a gradient sphere with three rings that expand outward while
 * the app is connecting or connected. Built with the core Animated API on the native
 * driver, so it stays smooth on a low-end phone.
 */
export function ConnectOrb({ status, label, hint, onPress }: Props) {
  const colors = useColors();
  const connected = status === 'connected';
  const connecting = status === 'connecting';
  const active = connected || connecting;

  // One value per ring, each started with its own delay so the pulses are evenly spaced.
  const rings = useRef([new Animated.Value(0), new Animated.Value(0), new Animated.Value(0)]).current;
  const breathe = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!active) {
      rings.forEach((r) => {
        r.stopAnimation();
        r.setValue(0);
      });
      breathe.stopAnimation();
      breathe.setValue(0);
      return;
    }
    const duration = connecting ? 1500 : 2800;
    const loops = rings.map((value, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay((duration / rings.length) * i),
          Animated.timing(value, {
            toValue: 1,
            duration,
            easing: Easing.out(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(value, { toValue: 0, duration: 0, useNativeDriver: true }),
        ]),
      ),
    );
    loops.forEach((l) => l.start());

    const breathLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, {
          toValue: 1,
          duration: 1700,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(breathe, {
          toValue: 0,
          duration: 1700,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );
    breathLoop.start();

    return () => {
      loops.forEach((l) => l.stop());
      breathLoop.stop();
    };
  }, [active, connecting, rings, breathe]);

  const accent = connected ? colors.success : colors.primary;
  const gradient = connected ? colors.gradientSuccess : colors.gradientConnect;
  const coreScale = breathe.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] });

  return (
    <View style={styles.wrap}>
      <View pointerEvents="none" style={styles.rings}>
        {rings.map((value, i) => (
          <Animated.View
            key={i}
            style={[
              styles.ring,
              {
                borderColor: accent,
                opacity: active
                  ? value.interpolate({ inputRange: [0, 0.1, 1], outputRange: [0, 0.5, 0] })
                  : 0.14,
                transform: [
                  { scale: active ? value.interpolate({ inputRange: [0, 1], outputRange: [1, 1.5] }) : 1 },
                ],
              },
            ]}
          />
        ))}
      </View>

      <View
        pointerEvents="none"
        style={[
          styles.glow,
          { backgroundColor: connected ? colors.glowSuccess : colors.glow, opacity: active ? 0.85 : 0.3 },
        ]}
      />

      <Animated.View style={{ transform: [{ scale: active ? coreScale : 1 }] }}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={label}
          accessibilityState={{ busy: connecting }}
          disabled={connecting}
          onPress={onPress}
          style={({ pressed }) => [styles.pressable, pressed && { transform: [{ scale: 0.97 }] }]}>
          <LinearGradient
            colors={gradient}
            start={{ x: 0.15, y: 0 }}
            end={{ x: 0.85, y: 1 }}
            style={[styles.core, { shadowColor: accent }]}>
            <LinearGradient
              colors={['rgba(255,255,255,0.40)', 'rgba(255,255,255,0)']}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={styles.gloss}
            />
            <View style={styles.coreInner}>
              {connecting ? (
                <ActivityIndicator size="large" color="#FFFFFF" />
              ) : (
                <Ionicons name="power" size={58} color="#FFFFFF" />
              )}
            </View>
          </LinearGradient>
        </Pressable>
      </Animated.View>

      <View style={styles.caption}>
        <Text style={[styles.label, { color: connected ? colors.success : colors.text }]}>{label}</Text>
        <Text style={[styles.hint, { color: colors.muted }]}>{hint}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center', paddingVertical: 6 },
  rings: { position: 'absolute', width: SIZE, height: SIZE, alignItems: 'center', justifyContent: 'center' },
  ring: { position: 'absolute', width: SIZE, height: SIZE, borderRadius: SIZE / 2, borderWidth: 1.5 },
  glow: {
    position: 'absolute',
    width: CORE + 44,
    height: CORE + 44,
    borderRadius: (CORE + 44) / 2,
  },
  pressable: { borderRadius: CORE / 2 },
  core: {
    width: CORE,
    height: CORE,
    borderRadius: CORE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    shadowOpacity: 0.6,
    shadowRadius: 26,
    shadowOffset: { width: 0, height: 14 },
    elevation: 18,
  },
  gloss: { position: 'absolute', top: 0, left: 0, right: 0, height: CORE * 0.55 },
  coreInner: { alignItems: 'center', justifyContent: 'center' },
  caption: { alignItems: 'center', gap: 3, marginTop: 20 },
  label: { fontSize: 20, fontWeight: '800', letterSpacing: 0.3 },
  hint: { fontSize: 13, fontWeight: '500' },
});
