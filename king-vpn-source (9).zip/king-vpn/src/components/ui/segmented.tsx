import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import type { ComponentProps } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { radius, spacing, useColors } from '@/constants/theme';
import { tapFeedback } from '@/lib/haptics';

export type SegmentOption<T extends string> = {
  value: T;
  label: string;
  icon?: ComponentProps<typeof Ionicons>['name'];
};

type Props<T extends string> = {
  options: SegmentOption<T>[];
  value: T;
  onChange: (value: T) => void;
  /** `grid` is the compact 3-across protocol picker; `row` is for two wide options. */
  layout?: 'row' | 'grid';
};

/**
 * A frosted track with a gradient pill under the active option. Used for the language
 * switch, theme switch and the protocol picker.
 */
export function Segmented<T extends string>({ options, value, onChange, layout = 'row' }: Props<T>) {
  const colors = useColors();
  return (
    <View style={[styles.track, { backgroundColor: colors.card, borderColor: colors.border }]}>
      {options.map((option) => {
        const active = option.value === value;
        return (
          <Pressable
            key={option.value}
            accessibilityRole="radio"
            accessibilityState={{ selected: active }}
            onPress={() => {
              tapFeedback();
              onChange(option.value);
            }}
            style={({ pressed }) => [styles.item, layout === 'grid' && styles.itemGrid, pressed && { opacity: 0.85 }]}>
            {active ? (
              <LinearGradient
                colors={colors.gradientBrand}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
            ) : null}
            <View style={styles.itemInner}>
              {option.icon ? (
                <Ionicons
                  name={option.icon}
                  size={layout === 'grid' ? 17 : 16}
                  color={active ? '#FFFFFF' : colors.muted}
                />
              ) : null}
              <Text
                numberOfLines={1}
                style={[styles.label, layout === 'grid' && styles.labelGrid, { color: active ? '#FFFFFF' : colors.text }]}>
                {option.label}
              </Text>
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    flexDirection: 'row',
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 4,
    gap: 4,
  },
  item: {
    flex: 1,
    minHeight: 44,
    borderRadius: radius.pill,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  itemGrid: { minHeight: 50 },
  itemInner: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, paddingHorizontal: spacing.sm },
  label: { fontSize: 14, fontWeight: '700', letterSpacing: 0.2 },
  labelGrid: { fontSize: 13 },
});
