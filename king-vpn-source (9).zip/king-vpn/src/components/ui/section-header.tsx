import type { ReactNode } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { spacing, useColors } from '@/constants/theme';

type Props = {
  title: string;
  subtitle?: string;
  /** Small element on the end side, e.g. a count or an action. */
  badge?: ReactNode;
};

/** A small uppercase section label with an optional hint underneath. */
export function SectionHeader({ title, subtitle, badge }: Props) {
  const colors = useColors();
  return (
    <View style={styles.wrap}>
      <View style={styles.row}>
        <Text style={[styles.title, { color: colors.muted }]}>{title}</Text>
        <View style={styles.grow} />
        {badge}
      </View>
      {subtitle ? <Text style={[styles.subtitle, { color: colors.faint }]}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 2, marginTop: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  grow: { flex: 1 },
  title: { fontSize: 12, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
  subtitle: { fontSize: 12.5, lineHeight: 17 },
});
