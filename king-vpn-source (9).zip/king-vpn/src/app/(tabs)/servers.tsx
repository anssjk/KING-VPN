import Ionicons from '@expo/vector-icons/Ionicons';
import { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  SectionHeader,
  Segmented,
  TextField,
  type SegmentOption,
} from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { tapFeedback } from '@/lib/haptics';
import { useSettings } from '@/lib/settings-context';
import { describeConfig, parseAny, parseSubscription } from '@/lib/xray-config';

type AddMode = 'link' | 'subscription';

/**
 * The Servers screen: the user's own VLESS / VMess / Trojan / Shadowsocks servers.
 *
 * ## What it does, and what it refuses to do
 *
 * A server only appears here after it has been parsed from something the user supplied —
 * a share link, a subscription URL, or a JSON config. Nothing is generated. The "Test"
 * button runs the real config test (start the core, fetch a page through it), so a green
 * "Verified" badge means traffic actually left through that server, not that a port was
 * open.
 *
 * The screen keeps the app's existing look: the same aurora background, frosted cards,
 * gradient buttons and typography as every other tab.
 */
export default function ServersScreen() {
  const colors = useColors();
  const { t, rtl } = useSettings();
  const {
    servers,
    addServers,
    removeServer,
    selectedServerId,
    setSelectedServerId,
    testServer,
    canTunnel,
  } = useApp();

  const [mode, setMode] = useState<AddMode>('link');
  const [input, setInput] = useState('');
  const [subUrl, setSubUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [pendingRemove, setPendingRemove] = useState<string | null>(null);

  const modeOptions: SegmentOption<AddMode>[] = [
    { value: 'link', label: t('addServer'), icon: 'link-outline' },
    { value: 'subscription', label: t('addSubscription'), icon: 'cloud-download-outline' },
  ];

  const sorted = useMemo(() => [...servers].sort((a, b) => b.addedAt - a.addedAt), [servers]);

  const addFromText = () => {
    tapFeedback();
    setMessage(null);
    const { configs, errors } = parseAny(input);
    if (configs.length === 0) {
      setMessage({ tone: 'error', text: errors[0] ?? t('serverInvalid') });
      return;
    }
    addServers(configs);
    setInput('');
    setMessage({ tone: 'ok', text: t('serverAdded') });
  };

  const addFromSubscription = async () => {
    tapFeedback();
    setMessage(null);
    const url = subUrl.trim();
    if (!url) {
      setMessage({ tone: 'error', text: t('serverInvalid') });
      return;
    }
    setBusy(true);
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 15000);
      const res = await fetch(url, {
        headers: { Accept: '*/*', 'User-Agent': 'KINGVPN/1.0' },
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (!res.ok) {
        setMessage({ tone: 'error', text: `${t('subscriptionFailed')} (${res.status})` });
        return;
      }
      const body = await res.text();
      const { configs, errors } = parseSubscription(body);
      if (configs.length === 0) {
        setMessage({ tone: 'error', text: errors[0] ?? t('subscriptionFailed') });
        return;
      }
      addServers(configs);
      setSubUrl('');
      setMessage({ tone: 'ok', text: t('subscriptionAdded').replace('{n}', String(configs.length)) });
    } catch (e) {
      setMessage({
        tone: 'error',
        text: `${t('subscriptionFailed')}: ${e instanceof Error ? e.message : String(e)}`,
      });
    } finally {
      setBusy(false);
    }
  };

  const runTest = async (id: string) => {
    tapFeedback();
    setTestingId(id);
    try {
      const result = await testServer(id);
      setMessage({
        tone: result.verified ? 'ok' : 'error',
        text: result.verified
          ? `${t('serverVerified')}${result.exitIp ? ` · ${t('serverExitIp')}: ${result.exitIp}` : ''}`
          : `${t('serverTestFailed')}: ${result.error ?? ''}`,
      });
    } finally {
      setTestingId(null);
    }
  };

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('serversTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('serversSubtitle')}</Text>
      </View>

      {!canTunnel ? (
        <Card>
          <Text style={[styles.note, { color: colors.warning }]}>{t('tunnelUnavailable')}</Text>
        </Card>
      ) : null}

      {/* Add a server */}
      <Card>
        <Segmented options={modeOptions} value={mode} onChange={setMode} layout="row" />

        {mode === 'link' ? (
          <>
            <Text style={[styles.hint, { color: colors.faint }]}>{t('addServerHint')}</Text>
            <TextField
              label={t('addServerTitle')}
              value={input}
              onChangeText={setInput}
              placeholder={t('addServerPlaceholder')}
              autoCapitalize="none"
              autoCorrect={false}
              multiline
              numberOfLines={3}
              style={styles.multiline}
            />
            <Button title={t('addServerButton')} icon="add" onPress={addFromText} disabled={!input.trim()} />
          </>
        ) : (
          <>
            <TextField
              label={t('subscriptionLabel')}
              value={subUrl}
              onChangeText={setSubUrl}
              placeholder={t('subscriptionPlaceholder')}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
            <Button
              title={busy ? t('subscriptionFetching') : t('subscriptionFetch')}
              icon="cloud-download-outline"
              onPress={addFromSubscription}
              loading={busy}
              disabled={!subUrl.trim()}
            />
          </>
        )}

        {message ? (
          <Text style={[styles.note, { color: message.tone === 'ok' ? colors.success : colors.danger }]}>
            {message.text}
          </Text>
        ) : null}
      </Card>

      {/* The list */}
      <SectionHeader
        title={t('serversTitle')}
        badge={
          <Text style={[styles.count, { color: colors.faint }]}>
            {t('serverCount').replace('{n}', String(servers.length))}
          </Text>
        }
      />

      {sorted.length === 0 ? (
        <EmptyState icon="server-outline" title={t('serversEmpty')} />
      ) : (
        <View style={styles.list}>
          {sorted.map((entry) => {
            const config = entry.config;
            const selected = selectedServerId === config.id;
            const testing = testingId === config.id;
            return (
              <Card
                key={config.id}
                glowColor={selected ? colors.primary : undefined}
                style={selected ? { borderColor: colors.primary } : undefined}>
                <View style={[styles.row, rtl && styles.rowReverse]}>
                  <View style={styles.info}>
                    <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>
                      {config.name}
                    </Text>
                    <Text style={[styles.meta, { color: colors.muted }]} numberOfLines={1}>
                      {describeConfig(config)}
                    </Text>
                    <Text style={[styles.meta, { color: colors.faint }]} numberOfLines={1}>
                      {t('serverTransport')}: {config.network.toUpperCase()}
                      {config.security !== 'none'
                        ? ` · ${t('serverSecurity')}: ${config.security.toUpperCase()}`
                        : ''}
                    </Text>
                    {entry.test ? (
                      <View style={[styles.testRow, rtl && styles.rowReverse]}>
                        <Ionicons
                          name={entry.test.verified ? 'checkmark-circle' : 'close-circle'}
                          size={13}
                          color={entry.test.verified ? colors.success : colors.danger}
                        />
                        <Text
                          style={[
                            styles.testText,
                            { color: entry.test.verified ? colors.success : colors.danger },
                          ]}
                          numberOfLines={1}>
                          {entry.test.verified
                            ? `${t('scanVerified')}${entry.test.exitIp ? ` · ${entry.test.exitIp}` : ''} · ${entry.test.ms} ${t('ms')}`
                            : `${t('serverTestFailed')}${entry.test.error ? `: ${entry.test.error}` : ''}`}
                        </Text>
                      </View>
                    ) : null}
                  </View>

                  {selected ? (
                    <View style={[styles.pill, { backgroundColor: colors.primary }]}>
                      <Ionicons name="checkmark" size={11} color="#FFFFFF" />
                      <Text style={styles.pillText}>{t('serverSelected')}</Text>
                    </View>
                  ) : null}
                </View>

                <View style={[styles.actions, rtl && styles.rowReverse]}>
                  <Pressable
                    onPress={() => {
                      tapFeedback();
                      setSelectedServerId(selected ? '' : config.id);
                    }}
                    style={({ pressed }) => [
                      styles.action,
                      { backgroundColor: colors.cardAlt, borderColor: colors.border },
                      pressed && { opacity: 0.8 },
                    ]}>
                    <Ionicons
                      name={selected ? 'radio-button-on' : 'radio-button-off'}
                      size={15}
                      color={selected ? colors.primary : colors.muted}
                    />
                    <Text style={[styles.actionText, { color: selected ? colors.primary : colors.text }]}>
                      {t('useServer')}
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={() => runTest(config.id)}
                    disabled={testing}
                    style={({ pressed }) => [
                      styles.action,
                      { backgroundColor: colors.cardAlt, borderColor: colors.border },
                      pressed && { opacity: 0.8 },
                      testing && { opacity: 0.6 },
                    ]}>
                    {testing ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <Ionicons name="pulse-outline" size={15} color={colors.primary} />
                    )}
                    <Text style={[styles.actionText, { color: colors.primary }]}>
                      {testing ? t('testingServer') : t('testServer')}
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={() => {
                      tapFeedback();
                      setPendingRemove(config.id);
                    }}
                    style={({ pressed }) => [
                      styles.action,
                      { backgroundColor: colors.cardAlt, borderColor: colors.border },
                      pressed && { opacity: 0.8 },
                    ]}>
                    <Ionicons name="trash-outline" size={15} color={colors.danger} />
                    <Text style={[styles.actionText, { color: colors.danger }]}>{t('removeServer')}</Text>
                  </Pressable>
                </View>
              </Card>
            );
          })}
        </View>
      )}

      <ConfirmDialog
        visible={pendingRemove != null}
        title={t('removeServerConfirm')}
        confirmTitle={t('removeServer')}
        cancelTitle={t('back')}
        destructive
        onCancel={() => setPendingRemove(null)}
        onConfirm={() => {
          if (pendingRemove) {
            removeServer(pendingRemove);
            if (selectedServerId === pendingRemove) setSelectedServerId('');
          }
          setPendingRemove(null);
        }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  hint: { fontSize: 12, lineHeight: 17 },
  multiline: { minHeight: 84, textAlignVertical: 'top', paddingTop: spacing.sm },
  note: { fontSize: 12.5, lineHeight: 18 },
  count: { fontSize: 11.5, fontWeight: '700' },
  list: { gap: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  info: { flex: 1, gap: 2 },
  name: { fontSize: 15.5, fontWeight: '800' },
  meta: { fontSize: 11.5 },
  testRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  testText: { fontSize: 11, fontWeight: '700', flex: 1 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    borderRadius: radius.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  pillText: { fontSize: 10, fontWeight: '800', color: '#FFFFFF' },
  actions: { flexDirection: 'row', gap: spacing.xs, marginTop: spacing.xs },
  action: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 9,
  },
  actionText: { fontSize: 11.5, fontWeight: '800' },
});
