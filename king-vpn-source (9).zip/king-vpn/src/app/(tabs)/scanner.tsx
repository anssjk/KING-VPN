import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { Card, FlagBadge, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import type { PingResult } from '@/lib/cloudflare';
import { fetchCloudflareRanges, hostsFromRanges } from '@/lib/cloudflare-ranges';
import { tapFeedback } from '@/lib/haptics';
import { useScanner, type ProbeKind } from '@/hooks/use-scanner';
import {
  PREFERRED_COUNTRIES,
  TOP_RESULTS,
  WARP_PORTS,
  WARP_SNI,
  allWarpIps,
  buildScanTargets,
  countryName,
  flagFromCountryCode,
  isPreferredCountry,
  maskEndpoint,
} from '@/lib/nodes';
import { useSettings } from '@/lib/settings-context';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { ensureRegistration } from '@/lib/warp';

type SortKey = 'latency' | 'jitter' | 'loss';
type FilterKey = 'all' | 'reachable' | 'failed' | 'preferred';
type Depth = 'quick' | 'full';

/** Latency bands, so a number becomes a judgement the user can act on. */
function quality(ms: number): { label: string; color: 'success' | 'warning' | 'danger' } {
  if (ms <= 80) return { label: 'fast', color: 'success' };
  if (ms <= 200) return { label: 'ok', color: 'warning' };
  return { label: 'slow', color: 'danger' };
}

export default function ScannerScreen() {
  const colors = useColors();
  const { t, rtl } = useSettings();
  const { selectHost, selectedNode, servers, selectedServer, testServerWithAddress } = useApp();
  const scanner = useScanner();

  const [testingThrough, setTestingThrough] = useState(false);

  const [sort, setSort] = useState<SortKey>('latency');
  const [filter, setFilter] = useState<FilterKey>('reachable');
  const [depth, setDepth] = useState<Depth>('full');
  const [probe, setProbe] = useState<ProbeKind>('warp');
  const [preferCountries, setPreferCountries] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // The Cloudflare range list, fetched live and cached on the device.
  const [ranges, setRanges] = usePersistentState<string[]>('cf_ranges', []);
  const [rangesLive, setRangesLive] = usePersistentState<boolean>('cf_ranges_live', false);
  const [rangesBusy, setRangesBusy] = useState(false);

  // The last scan, kept so a restart does not lose it.
  const [savedResults, setSavedResults] = usePersistentState<PingResult[]>('scan_results', []);
  const [savedDuration, setSavedDuration] = usePersistentState<number | null>('scan_duration', null);

  const sortOptions: SegmentOption<SortKey>[] = [
    { value: 'latency', label: t('sortLatency'), icon: 'speedometer-outline' },
    { value: 'jitter', label: t('sortJitter'), icon: 'pulse-outline' },
    { value: 'loss', label: t('sortLoss'), icon: 'trending-down-outline' },
  ];
  const filterOptions: SegmentOption<FilterKey>[] = [
    { value: 'reachable', label: t('filterReachable'), icon: 'checkmark-circle-outline' },
    { value: 'preferred', label: t('filterPreferred'), icon: 'star-outline' },
    { value: 'failed', label: t('filterFailed'), icon: 'close-circle-outline' },
    { value: 'all', label: t('filterAll'), icon: 'list-outline' },
  ];
  const depthOptions: SegmentOption<Depth>[] = [
    { value: 'full', label: t('scanDepthFull'), icon: 'layers-outline' },
    { value: 'quick', label: t('scanDepthQuick'), icon: 'flash-outline' },
  ];
  const probeOptions: SegmentOption<ProbeKind>[] = [
    { value: 'warp', label: t('protoWarp'), icon: 'shield-checkmark-outline' },
    { value: 'tcp', label: t('scanLevelTcp'), icon: 'git-network-outline' },
    { value: 'tls', label: t('scanLevelTls'), icon: 'lock-closed-outline' },
  ];

  // Fetch the official ranges once, and again whenever the user asks.
  const refreshRanges = useCallback(async () => {
    setRangesBusy(true);
    try {
      const result = await fetchCloudflareRanges();
      setRanges(result.ranges);
      setRangesLive(result.live);
      if (!result.live && result.error) {
        setNotice(`${t('scanRangesCached')} — ${result.error}`);
      } else {
        setNotice(null);
      }
    } finally {
      setRangesBusy(false);
    }
  }, [setRanges, setRangesLive, t]);

  useEffect(() => {
    if (ranges.length === 0) {
      void refreshRanges();
    }
    // Restore the last scan once, so the list is not empty after a restart.
    if (savedResults.length > 0 && scanner.phase === 'idle') {
      scanner.restore({ results: savedResults, durationMs: savedDuration });
      setNotice(t('scanRestored'));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * The visible list.
   *
   * A full scan measures thousands of endpoints; the screen shows the best `TOP_RESULTS`
   * of them. Preferred countries float to the top of a latency sort when the user asked
   * for that, but they are never *invented* — a row only carries a country the scanner
   * actually read from the edge through that address.
   */
  const visible = useMemo(() => {
    const base =
      filter === 'reachable'
        ? scanner.results.filter((r) => r.ok)
        : filter === 'failed'
          ? scanner.results.filter((r) => !r.ok)
          : filter === 'preferred'
            ? scanner.results.filter((r) => r.ok && isPreferredCountry(r.loc))
            : scanner.results;
    const sorted = [...base];
    sorted.sort((a, b) => {
      if (sort === 'jitter') return a.jitter - b.jitter;
      if (sort === 'loss') return a.loss - b.loss;
      if (a.ok !== b.ok) return a.ok ? -1 : 1;
      if (preferCountries) {
        const ap = isPreferredCountry(a.loc) ? 0 : 1;
        const bp = isPreferredCountry(b.loc) ? 0 : 1;
        if (ap !== bp) return ap - bp;
      }
      return a.ms - b.ms;
    });
    return sorted.slice(0, TOP_RESULTS);
  }, [scanner.results, filter, sort, preferCountries]);

  const best = scanner.reachable[0] ?? null;
  const reachableCount = scanner.results.filter((r) => r.ok).length;
  const preferredCount = scanner.results.filter((r) => r.ok && isPreferredCountry(r.loc)).length;

  const runScan = async () => {
    tapFeedback();
    setError(null);
    setNotice(null);
    try {
      // The host list comes from Cloudflare's own published ranges when they are
      // available, and from the built-in WARP ranges otherwise.
      const hosts =
        ranges.length > 0
          ? hostsFromRanges(ranges, depth === 'full' ? 254 : 32)
          : depth === 'full'
            ? allWarpIps()
            : allWarpIps().filter((_, i) => i % 8 === 0);
      const ports = depth === 'full' ? WARP_PORTS : [2408, 500];
      const targets = buildScanTargets(hosts, ports);

      if (probe === 'warp') {
        // The handshake probe must use this device's own registration, so the scan tests
        // exactly the key the tunnel will present.
        const registration = await ensureRegistration();
        void scanner.start({
          targets,
          privateKey: registration.privateKey,
          peerPublicKey: registration.peerPublicKey,
          samples: 1,
          concurrency: depth === 'full' ? 128 : 64,
          timeoutMs: 2500,
          resolveColo: true,
          probe: 'warp',
        });
      } else {
        // TCP/TLS reachability: no keys needed, and a tighter concurrency cap so the
        // network is not flooded.
        void scanner.start({
          targets,
          privateKey: '',
          peerPublicKey: '',
          concurrency: depth === 'full' ? 48 : 24,
          timeoutMs: 3000,
          probe,
          sni: WARP_SNI,
        });
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not start the scan.');
    }
  };

  const useBest = () => {
    if (!best) return;
    tapFeedback();
    selectHost(best.host, best.port, WARP_SNI);
  };

  /**
   * Test the user's own server through the best scanned address.
   *
   * Only the address is swapped: the port, SNI, UUID, transport and security stay exactly
   * as the user's config has them. This is the scanner-to-connection bridge, and the
   * narrowness is the point — changing any other field would silently turn a working
   * config into a different one.
   */
  const testThroughBest = async () => {
    if (!best || !selectedServer) return;
    tapFeedback();
    setTestingThrough(true);
    setNotice(null);
    try {
      const result = await testServerWithAddress(selectedServer.config.id, best.host);
      setNotice(
        result.verified
          ? `${t('serverVerified')}${result.exitIp ? ` · ${t('serverExitIp')}: ${result.exitIp}` : ''}`
          : `${t('serverTestFailed')}: ${result.error ?? ''}`,
      );
    } finally {
      setTestingThrough(false);
    }
  };

  const saveResults = () => {
    tapFeedback();
    setSavedResults(scanner.results);
    setSavedDuration(scanner.durationMs);
    setNotice(t('scanSaved'));
  };

  const exportResults = async () => {
    tapFeedback();
    try {
      const header = 'host,port,ok,ms,colo,loc,error';
      const lines = scanner.results.map((r) =>
        [r.host, r.port, r.ok ? 'ok' : 'fail', r.ms, r.colo ?? '', r.loc ?? '', (r.error ?? '').replace(/,/g, ';')].join(','),
      );
      const csv = [header, ...lines].join('\n');
      const Clipboard = await import('expo-clipboard').catch(() => null);
      if (Clipboard?.setStringAsync) {
        await Clipboard.setStringAsync(csv);
        setNotice(t('scanExported'));
      } else {
        setNotice(t('scanExportFailed'));
      }
    } catch {
      setNotice(t('scanExportFailed'));
    }
  };

  return (
    <Screen bottomInset={96}>
      <View style={styles.pageHead}>
        <Text style={[styles.pageTitle, { color: colors.text }]}>{t('scannerTitle')}</Text>
        <Text style={[styles.pageSubtitle, { color: colors.muted }]}>{t('scannerSubtitle')}</Text>
      </View>

      {/* Controls */}
      <Card>
        <View style={styles.controlBlock}>
          <Text style={[styles.controlLabel, { color: colors.text }]}>{t('scanLevel')}</Text>
          <Text style={[styles.controlHint, { color: colors.faint }]}>{t('scanLevelHint')}</Text>
          <Segmented options={probeOptions} value={probe} onChange={setProbe} layout="grid" />
        </View>

        <View style={styles.controlBlock}>
          <Text style={[styles.controlLabel, { color: colors.text }]}>{t('scanDepth')}</Text>
          <Text style={[styles.controlHint, { color: colors.faint }]}>{t('scanDepthHint')}</Text>
          <Segmented options={depthOptions} value={depth} onChange={setDepth} layout="grid" />
        </View>

        {/* Cloudflare ranges */}
        <View style={[styles.rangeRow, rtl && styles.rowReverse]}>
          <Ionicons
            name={rangesLive ? 'cloud-done-outline' : 'cloud-offline-outline'}
            size={16}
            color={rangesLive ? colors.success : colors.warning}
          />
          <View style={styles.rangeText}>
            <Text style={[styles.rangeLabel, { color: colors.text }]}>{t('scanRanges')}</Text>
            <Text style={[styles.rangeHint, { color: colors.faint }]} numberOfLines={1}>
              {rangesLive ? t('scanRangesLive') : t('scanRangesCached')} · {ranges.length}
            </Text>
          </View>
          <Pressable
            onPress={() => {
              tapFeedback();
              void refreshRanges();
            }}
            disabled={rangesBusy}
            style={({ pressed }) => [
              styles.refreshBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            {rangesBusy ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Ionicons name="refresh" size={14} color={colors.primary} />
            )}
          </Pressable>
        </View>

        <Pressable
          onPress={() => {
            tapFeedback();
            setPreferCountries((v) => !v);
          }}
          style={[styles.prefRow, rtl && styles.rowReverse]}>
          <Ionicons
            name={preferCountries ? 'checkbox' : 'square-outline'}
            size={19}
            color={preferCountries ? colors.primary : colors.faint}
          />
          <View style={styles.prefText}>
            <Text style={[styles.prefLabel, { color: colors.text }]}>{t('scanPreferCountries')}</Text>
            <Text style={[styles.prefHint, { color: colors.faint }]} numberOfLines={2}>
              {PREFERRED_COUNTRIES.slice(0, 8).map((c) => countryName(c)).join(' · ')}
            </Text>
          </View>
        </Pressable>

        <View style={[styles.actionRow, rtl && styles.rowReverse]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={scanner.running ? t('scanCancel') : t('scanStart')}
            onPress={scanner.running ? scanner.cancel : runScan}
            style={({ pressed }) => [styles.scanBtn, pressed && { opacity: 0.85 }]}>
            <LinearGradient
              colors={scanner.running ? ([colors.danger, '#B3261E'] as const) : colors.gradientBrand}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.scanBtnFill}>
              {scanner.running ? (
                <Ionicons name="stop" size={16} color="#FFFFFF" />
              ) : (
                <Ionicons name="scan" size={16} color="#FFFFFF" />
              )}
              <Text style={styles.scanBtnText}>{scanner.running ? t('scanCancel') : t('scanStart')}</Text>
            </LinearGradient>
          </Pressable>

          {best ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t('scanUseBest')}
              onPress={useBest}
              style={({ pressed }) => [
                styles.bestBtn,
                { backgroundColor: colors.cardAlt, borderColor: colors.border },
                pressed && { opacity: 0.8 },
              ]}>
              <Ionicons name="flash" size={15} color={colors.success} />
              <Text style={[styles.bestText, { color: colors.success }]}>{t('scanUseBest')}</Text>
            </Pressable>
          ) : null}
        </View>

        {scanner.running || scanner.phase === 'done' || scanner.phase === 'cancelled' ? (
          <View style={styles.progressWrap}>
            <View style={[styles.progressTrack, { backgroundColor: colors.cardAlt }]}>
              <View
                style={[
                  styles.progressFill,
                  {
                    backgroundColor: scanner.running ? colors.primary : colors.success,
                    width: `${Math.max(3, Math.round(scanner.progress * 100))}%`,
                  },
                ]}
              />
            </View>
            <Text style={[styles.progressText, { color: colors.muted }]}>
              {scanner.done}/{scanner.total || 0}
            </Text>
          </View>
        ) : null}

        {error ? <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text> : null}
        {notice ? <Text style={[styles.errorText, { color: colors.muted }]}>{notice}</Text> : null}
      </Card>

      {/* Summary */}
      {scanner.phase !== 'idle' ? (
        <View style={styles.statsRow}>
          <Stat label={t('statReachable')} value={`${reachableCount}`} tone="success" />
          <Stat label={t('statPreferred')} value={`${preferredCount}`} tone="primary" />
          <Stat label={t('statBest')} value={best ? `${best.ms} ${t('ms')}` : '—'} tone="primary" />
        </View>
      ) : null}

      {/* Best pick */}
      {best ? (
        <Card glowColor={colors.success}>
          <View style={[styles.bestCardRow, rtl && styles.rowReverse]}>
            <FlagBadge flag={best.loc ? flagFromCountryCode(best.loc) : '📡'} size={44} />
            <View style={styles.bestInfo}>
              <Text style={[styles.bestLabel, { color: colors.faint }]}>{t('scanBestPick')}</Text>
              <Text style={[styles.bestHost, { color: colors.text }]} numberOfLines={1}>
                {maskEndpoint(best.host)}
              </Text>
              <Text style={[styles.bestMeta, { color: colors.muted }]}>
                {best.loc ? countryName(best.loc) : t('scanAnycast')}
                {best.colo ? ` · ${best.colo}` : ''} · {best.ms} {t('ms')}
              </Text>
            </View>
            {selectedNode.host === best.host ? (
              <View style={[styles.selectedPill, { backgroundColor: colors.success }]}>
                <Ionicons name="checkmark" size={12} color="#FFFFFF" />
                <Text style={styles.selectedPillText}>{t('selected')}</Text>
              </View>
            ) : null}
          </View>

          {/* Scanner → server bridge: test the user's own config through this address. */}
          <Pressable
            onPress={testThroughBest}
            disabled={!selectedServer || testingThrough}
            style={({ pressed }) => [
              styles.throughBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
              (!selectedServer || testingThrough) && { opacity: 0.55 },
            ]}>
            {testingThrough ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Ionicons name="flask-outline" size={15} color={colors.primary} />
            )}
            <View style={styles.throughText}>
              <Text style={[styles.throughLabel, { color: colors.primary }]}>
                {t('scanTestThrough')}
              </Text>
              <Text style={[styles.throughHint, { color: colors.faint }]} numberOfLines={2}>
                {selectedServer ? t('scanTestThroughHint') : t('scanNoServer')}
              </Text>
            </View>
          </Pressable>
        </Card>
      ) : null}

      {/* Save / export */}
      {scanner.results.length > 0 && !scanner.running ? (
        <View style={[styles.actionRow, rtl && styles.rowReverse]}>
          <Pressable
            onPress={saveResults}
            style={({ pressed }) => [
              styles.smallBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="bookmark-outline" size={14} color={colors.primary} />
            <Text style={[styles.smallBtnText, { color: colors.primary }]}>{t('scanSave')}</Text>
          </Pressable>
          <Pressable
            onPress={exportResults}
            style={({ pressed }) => [
              styles.smallBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="share-outline" size={14} color={colors.primary} />
            <Text style={[styles.smallBtnText, { color: colors.primary }]}>{t('scanExport')}</Text>
          </Pressable>
        </View>
      ) : null}

      {/* Sort + filter */}
      {scanner.results.length > 0 ? (
        <>
          <SectionHeader title={t('scanSort')} />
          <Segmented options={sortOptions} value={sort} onChange={setSort} layout="grid" />
          <SectionHeader title={t('scanFilter')} />
          <Segmented options={filterOptions} value={filter} onChange={setFilter} layout="grid" />
          <Text style={[styles.listNote, { color: colors.faint }]}>
            {t('scanShowingTop').replace('{n}', String(visible.length))}
          </Text>
        </>
      ) : null}

      {/* Results */}
      {scanner.phase === 'idle' ? (
        <View style={styles.emptyWrap}>
          <Ionicons name="radio-outline" size={30} color={colors.faint} />
          <Text style={[styles.empty, { color: colors.faint }]}>{t('scanIdleHint')}</Text>
        </View>
      ) : null}

      {scanner.phase !== 'idle' && visible.length === 0 && !scanner.running ? (
        <View style={styles.emptyWrap}>
          <Ionicons name="cloud-offline-outline" size={30} color={colors.faint} />
          <Text style={[styles.empty, { color: colors.faint }]}>
            {filter === 'failed' ? t('scanNoFailed') : t('scanNone')}
          </Text>
        </View>
      ) : null}

      <View style={styles.list}>
        {visible.map((r) => (
          <ResultRow
            key={`${r.host}:${r.port}`}
            result={r}
            selected={selectedNode.host === r.host}
            onPress={() => {
              if (!r.ok) return;
              tapFeedback();
              selectHost(r.host, r.port, WARP_SNI);
            }}
          />
        ))}
      </View>

      {scanner.running ? (
        <View style={styles.scanningNote}>
          <ActivityIndicator size="small" color={colors.primary} />
          <Text style={[styles.scanningText, { color: colors.muted }]}>{t('scanRunning')}</Text>
        </View>
      ) : null}
    </Screen>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: 'success' | 'danger' | 'primary' }) {
  const colors = useColors();
  const color = tone === 'success' ? colors.success : tone === 'danger' ? colors.danger : colors.primary;
  return (
    <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.statValue, { color }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.faint }]}>{label}</Text>
    </View>
  );
}

function ResultRow({
  result,
  selected,
  onPress,
}: {
  result: PingResult;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  const { t, rtl } = useSettings();
  const q = result.ok ? quality(result.ms) : null;
  const qColor = q
    ? q.color === 'success'
      ? colors.success
      : q.color === 'warning'
        ? colors.warning
        : colors.danger
    : colors.danger;
  const preferred = isPreferredCountry(result.loc);

  return (
    <Pressable
      onPress={onPress}
      disabled={!result.ok}
      style={({ pressed }) => [
        styles.resultRow,
        {
          backgroundColor: selected ? colors.cardAlt : colors.card,
          borderColor: selected ? colors.primary : colors.border,
        },
        pressed && result.ok && { opacity: 0.8 },
      ]}>
      <View style={[styles.resultLeft, rtl && styles.rowReverse]}>
        <Ionicons
          name={result.ok ? (selected ? 'radio-button-on' : 'radio-button-off') : 'close-circle'}
          size={19}
          color={result.ok ? (selected ? colors.primary : colors.faint) : colors.danger}
        />
        <View style={styles.resultInfo}>
          <View style={[styles.hostRow, rtl && styles.rowReverse]}>
            {result.loc ? <Text style={styles.flag}>{flagFromCountryCode(result.loc)}</Text> : null}
            <Text style={[styles.resultHost, { color: colors.text }]} numberOfLines={1}>
              {maskEndpoint(result.host)}
            </Text>
            {preferred ? <Ionicons name="star" size={11} color={colors.warning} /> : null}
          </View>
          <Text style={[styles.resultMeta, { color: colors.faint }]} numberOfLines={1}>
            {result.ok
              ? `${result.loc ? countryName(result.loc) : t('scanAnycast')}${result.colo ? ` · ${result.colo}` : ''} · ${t('scanPortShort')} ${result.port}`
              : (result.error ?? t('scanUnreachable'))}
          </Text>
        </View>
      </View>

      <View style={styles.resultRight}>
        {result.ok ? (
          <>
            <Text style={[styles.resultMs, { color: qColor }]}>
              {result.ms} {t('ms')}
            </Text>
            <View style={[styles.qualityPill, { backgroundColor: `${qColor}22` }]}>
              <Text style={[styles.qualityText, { color: qColor }]}>{q ? t(`q_${q.label}` as 'q_fast') : ''}</Text>
            </View>
          </>
        ) : (
          <Text style={[styles.resultMs, { color: colors.danger }]}>{t('scanFailedShort')}</Text>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pageHead: { gap: 3, marginBottom: spacing.xs },
  pageTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -0.6 },
  pageSubtitle: { fontSize: 13.5, lineHeight: 19 },
  controlBlock: { gap: 4 },
  controlLabel: { fontSize: 14, fontWeight: '700' },
  controlHint: { fontSize: 11.5, marginBottom: 4 },
  rangeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 4 },
  rangeText: { flex: 1, gap: 1 },
  rangeLabel: { fontSize: 13, fontWeight: '700' },
  rangeHint: { fontSize: 10.5 },
  refreshBtn: {
    width: 34,
    height: 34,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prefRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: 4 },
  prefText: { flex: 1, gap: 1 },
  prefLabel: { fontSize: 13, fontWeight: '700' },
  prefHint: { fontSize: 10.5, lineHeight: 14 },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  scanBtn: { flex: 1, borderRadius: radius.pill, overflow: 'hidden' },
  scanBtnFill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  scanBtnText: { fontSize: 13.5, fontWeight: '800', color: '#FFFFFF' },
  bestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  bestText: { fontSize: 12.5, fontWeight: '800' },
  smallBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 10,
  },
  smallBtnText: { fontSize: 12, fontWeight: '800' },
  progressWrap: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  progressTrack: { flex: 1, height: 7, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: 7, borderRadius: 4 },
  progressText: { fontSize: 11.5, fontWeight: '800', minWidth: 60, textAlign: 'right' },
  errorText: { fontSize: 12, lineHeight: 17 },
  statsRow: { flexDirection: 'row', gap: spacing.sm },
  stat: {
    flex: 1,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: spacing.sm,
    alignItems: 'center',
    gap: 2,
  },
  statValue: { fontSize: 18, fontWeight: '900' },
  statLabel: { fontSize: 10.5, fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase' },
  bestCardRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  bestInfo: { flex: 1, gap: 2 },
  bestLabel: { fontSize: 10.5, fontWeight: '800', letterSpacing: 0.6, textTransform: 'uppercase' },
  bestHost: { fontSize: 15.5, fontWeight: '800' },
  bestMeta: { fontSize: 11.5 },
  selectedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    borderRadius: radius.pill,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  selectedPillText: { fontSize: 10, fontWeight: '800', color: '#FFFFFF' },
  throughBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 10,
    paddingHorizontal: spacing.sm,
    marginTop: spacing.xs,
  },
  throughText: { flex: 1, gap: 1 },
  throughLabel: { fontSize: 12.5, fontWeight: '800' },
  throughHint: { fontSize: 10.5, lineHeight: 14 },
  emptyWrap: { alignItems: 'center', gap: 8, paddingVertical: spacing.xl },
  empty: { fontSize: 13, textAlign: 'center', lineHeight: 19 },
  listNote: { fontSize: 11, textAlign: 'center' },
  list: { gap: spacing.xs },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingVertical: 10,
    paddingHorizontal: spacing.md,
  },
  resultLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 },
  resultInfo: { flex: 1, gap: 1 },
  hostRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  flag: { fontSize: 13 },
  resultHost: { fontSize: 14, fontWeight: '700' },
  resultMeta: { fontSize: 10.5 },
  resultRight: { alignItems: 'flex-end', gap: 3 },
  resultMs: { fontSize: 13, fontWeight: '800' },
  qualityPill: { borderRadius: radius.pill, paddingHorizontal: 7, paddingVertical: 2 },
  qualityText: { fontSize: 9.5, fontWeight: '800', textTransform: 'uppercase' },
  scanningNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: spacing.sm,
  },
  scanningText: { fontSize: 12.5 },
});
