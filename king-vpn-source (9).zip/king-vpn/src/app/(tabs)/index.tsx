import Ionicons from '@expo/vector-icons/Ionicons';
import Constants from 'expo-constants';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { ConnectOrb } from '@/components/connect-orb';
import { Screen } from '@/components/screen';
import { BrandMark, Card, FlagBadge, SectionHeader, Segmented, type SegmentOption } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { tapFeedback } from '@/lib/haptics';
import { maskEndpoint, type Protocol } from '@/lib/nodes';
import { useSettings } from '@/lib/settings-context';

const VERSION = Constants.expoConfig?.version ?? '1.0.0';

/** Human-readable byte count for the traffic cells. */
function formatBytes(bytes: number): string {
  if (!bytes || bytes < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value < 10 && unit > 0 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`;
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const {
    status,
    connect,
    disconnect,
    pingMs,
    runPing,
    error,
    errorDetail,
    attempt,
    fallbackLog,
    activeHost,
    protocol,
    setProtocol,
    selectedNode,
    tunnel,
    canTunnel,
    tunnelUnavailableReason,
    vpnGranted,
    requestVpn,
    publicIp,
  } = useApp();

  const [testing, setTesting] = useState(false);

  const connected = status === 'connected';
  const connecting = status === 'connecting';

  const onConnect = () => {
    tapFeedback();
    if (connected) {
      void disconnect();
    } else {
      void connect();
    }
  };

  const onTest = async () => {
    tapFeedback();
    setTesting(true);
    await runPing();
    setTesting(false);
  };

  // The tunnel's own counters are the honest source for "is it really up".
  const handshake = tunnel?.latestHandshakeMs ?? 0;
  const hasHandshake = handshake > 0;
  const rx = tunnel?.rxBytes ?? 0;
  const tx = tunnel?.txBytes ?? 0;

  const ip = activeHost ? maskEndpoint(activeHost) : '—';
  const flag = selectedNode.flag;
  const country = selectedNode.country;

  const protocolOptions: SegmentOption<Protocol>[] = [
    { value: 'ip', label: t('protoIp'), icon: 'server-outline' },
    { value: 'psiphon', label: t('protoPsiphon'), icon: 'shield-outline' },
    { value: 'warp', label: t('protoWarp'), icon: 'flash-outline' },
  ];

  const statusLabel = connecting ? t('connecting') : connected ? t('connected') : t('disconnected');
  const statusHint = connecting
    ? attempt
      ? `${t('tryingEndpoint')} ${attempt.index}/${attempt.total}`
      : t('connecting')
    : connected
      ? hasHandshake
        ? t('secureSession')
        : t('tunnelStarting')
      : t('tapToConnect');

  return (
    <Screen bottomInset={96}>
      {/* Header: brand on the start side, version pill opposite */}
      <View style={[styles.header, rtl && styles.rowReverse]}>
        <BrandMark size={40} withWordmark />
        <View style={[styles.versionPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.dot, { backgroundColor: colors.success }]} />
          <Text style={[styles.versionText, { color: colors.muted }]}>{VERSION}</Text>
        </View>
      </View>

      {/* Hero: the connect orb */}
      <View style={styles.hero}>
        <ConnectOrb status={status} label={statusLabel} hint={statusHint} onPress={onConnect} />
      </View>

      {/* This build cannot create a VPN (Expo Go / web) — say so instead of failing later. */}
      {!canTunnel ? (
        <View style={[styles.noticeBox, { backgroundColor: colors.card, borderColor: colors.warning }]}>
          <Ionicons name="information-circle" size={18} color={colors.warning} />
          <Text style={[styles.noticeText, { color: colors.muted }]}>
            {tunnelUnavailableReason ?? t('tunnelUnavailable')}
          </Text>
        </View>
      ) : null}

      {/* Android has not granted VPN permission yet — offer the real system dialog. */}
      {canTunnel && !vpnGranted ? (
        <Pressable
          onPress={() => {
            tapFeedback();
            void requestVpn();
          }}
          style={({ pressed }) => [
            styles.noticeBox,
            { backgroundColor: colors.card, borderColor: colors.primary },
            pressed && { opacity: 0.85 },
          ]}>
          <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
          <Text style={[styles.noticeText, { color: colors.text }]}>{t('vpnPermissionNeeded')}</Text>
          <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={16} color={colors.primary} />
        </Pressable>
      ) : null}

      {/* IP + country + ping */}
      <Card glowColor={connected ? colors.success : undefined}>
        <View style={[styles.infoRow, rtl && styles.rowReverse]}>
          <View style={styles.infoCol}>
            <Text style={[styles.infoLabel, { color: colors.faint }]}>{t('yourIp')}</Text>
            <Text style={[styles.ipValue, { color: colors.text }]} numberOfLines={1}>
              {publicIp ?? ip}
            </Text>
          </View>
          <View style={[styles.countryCol, rtl && styles.rowReverse]}>
            <FlagBadge flag={flag} size={40} />
            <View style={styles.countryText}>
              <Text style={[styles.infoLabel, { color: colors.faint }]}>{t('country')}</Text>
              <Text style={[styles.countryValue, { color: colors.text }]} numberOfLines={1}>
                {country}
              </Text>
            </View>
          </View>
        </View>

        <View style={[styles.divider, { backgroundColor: colors.border }]} />

        <View style={[styles.pingRow, rtl && styles.rowReverse]}>
          <View style={[styles.pingLeft, rtl && styles.rowReverse]}>
            <View style={[styles.pingIcon, { backgroundColor: colors.cardAlt }]}>
              <Ionicons name="pulse" size={18} color={colors.primary} />
            </View>
            <View>
              <Text style={[styles.infoLabel, { color: colors.faint }]}>{t('latency')}</Text>
              <Text style={[styles.pingValue, { color: pingMs != null ? colors.success : colors.muted }]}>
                {pingMs != null ? `${pingMs} ${t('ms')}` : '—'}
              </Text>
            </View>
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t('test')}
            disabled={testing}
            onPress={onTest}
            style={({ pressed }) => [
              styles.testBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.75 },
              testing && { opacity: 0.6 },
            ]}>
            <Ionicons
              name={testing ? 'hourglass-outline' : 'flash'}
              size={15}
              color={colors.primary}
            />
            <Text style={[styles.testText, { color: colors.primary }]}>
              {testing ? t('testing') : t('test')}
            </Text>
          </Pressable>
        </View>
      </Card>

      {/* Live tunnel traffic — only meaningful once the tunnel is really up. */}
      {connected ? (
        <View style={[styles.trafficRow, rtl && styles.rowReverse]}>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="arrow-down" size={14} color={colors.success} />
            <Text style={[styles.trafficValue, { color: colors.text }]}>{formatBytes(rx)}</Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('received')}</Text>
          </View>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="arrow-up" size={14} color={colors.primary} />
            <Text style={[styles.trafficValue, { color: colors.text }]}>{formatBytes(tx)}</Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('sent')}</Text>
          </View>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons
              name={hasHandshake ? 'checkmark-circle' : 'time-outline'}
              size={14}
              color={hasHandshake ? colors.success : colors.warning}
            />
            <Text style={[styles.trafficValue, { color: colors.text }]}>
              {hasHandshake ? t('handshakeOk') : t('handshakePending')}
            </Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('handshake')}</Text>
          </View>
        </View>
      ) : null}

      {/* Protocol picker */}
      <View style={styles.section}>
        <SectionHeader title={t('protocol')} />
        <Segmented options={protocolOptions} value={protocol} onChange={setProtocol} layout="grid" />
      </View>

      {/* Current node shortcut */}
      <Pressable
        onPress={() => router.push('/(tabs)/nodes')}
        style={({ pressed }) => [
          styles.nodeRow,
          { backgroundColor: colors.card, borderColor: colors.border },
          pressed && { opacity: 0.85 },
        ]}>
        <FlagBadge flag={selectedNode.flag} size={38} />
        <View style={styles.nodeInfo}>
          <Text style={[styles.infoLabel, { color: colors.faint }]}>{t('currentNode')}</Text>
          <Text style={[styles.nodeName, { color: colors.text }]} numberOfLines={1}>
            {selectedNode.name}
          </Text>
        </View>
        <View style={[styles.changePill, { backgroundColor: colors.cardAlt }]}>
          <Text style={[styles.changeText, { color: colors.primary }]}>{t('changeNode')}</Text>
          <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={14} color={colors.primary} />
        </View>
      </Pressable>

      {connected && activeHost && activeHost !== selectedNode.host ? (
        <View style={[styles.fallbackBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Ionicons name="swap-horizontal" size={16} color={colors.success} />
          <Text style={[styles.fallbackText, { color: colors.muted }]}>
            {t('fallbackNote')}: <Text style={{ color: colors.success }}>{maskEndpoint(activeHost)}</Text>
          </Text>
        </View>
      ) : null}

      {error ? (
        <View style={[styles.errorBox, { backgroundColor: colors.card, borderColor: colors.danger }]}>
          <Ionicons name="alert-circle" size={18} color={colors.danger} />
          <View style={styles.errorBody}>
            <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
            {errorDetail ? (
              <Text style={[styles.errorDetail, { color: colors.faint }]} numberOfLines={2}>
                {t('errorDetail')}: {errorDetail}
              </Text>
            ) : null}
            {fallbackLog.length > 0 ? (
              <Text style={[styles.errorDetail, { color: colors.faint }]} numberOfLines={2}>
                {fallbackLog.length} × {t('scanFailedShort')}
              </Text>
            ) : null}
          </View>
        </View>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowReverse: { flexDirection: 'row-reverse' },
  versionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  dot: { width: 6, height: 6, borderRadius: 3 },
  versionText: { fontSize: 12, fontWeight: '700', letterSpacing: 0.3 },
  hero: { alignItems: 'center', marginTop: spacing.sm, marginBottom: spacing.xs },
  infoRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
  infoCol: { flex: 1, gap: 3 },
  infoLabel: { fontSize: 11.5, fontWeight: '700', letterSpacing: 0.6, textTransform: 'uppercase' },
  ipValue: { fontSize: 19, fontWeight: '800', letterSpacing: 0.2 },
  countryCol: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  countryText: { gap: 3, alignItems: 'flex-end' },
  countryValue: { fontSize: 15, fontWeight: '700' },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 2 },
  pingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pingLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  pingIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  pingValue: { fontSize: 17, fontWeight: '800' },
  testBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  testText: { fontSize: 13, fontWeight: '800' },
  section: { gap: spacing.sm },
  nodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  nodeInfo: { flex: 1, gap: 2 },
  nodeName: { fontSize: 15, fontWeight: '700' },
  changePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  changeText: { fontSize: 12, fontWeight: '800' },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },
  errorBody: { flex: 1, gap: 3 },
  errorDetail: { fontSize: 10.5, lineHeight: 14 },
  fallbackBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 10,
  },
  fallbackText: { flex: 1, fontSize: 12, lineHeight: 17 },
  noticeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 11,
  },
  noticeText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
  trafficRow: { flexDirection: 'row', gap: spacing.sm },
  trafficCell: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 10,
  },
  trafficValue: { fontSize: 13, fontWeight: '800' },
  trafficLabel: { fontSize: 9.5, fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase' },
});
