import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AuroraBackground } from '@/components/aurora-background';
import { BrandMark, Button } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { successFeedback, tapFeedback } from '@/lib/haptics';
import {
  getNotificationPermission,
  getVpnPermission,
  permissionLabel,
  requestNotificationPermission,
  requestVpnPermissionState,
  type PermissionState,
} from '@/lib/permissions';
import { useSettings } from '@/lib/settings-context';
import { useApp } from '@/lib/app-context';

/**
 * The first screen a returning user sees.
 *
 * It asks for the two permissions a VPN client needs — notifications and the system VPN
 * connection — and shows the real state of each. The user can allow them here or skip;
 * the app is usable either way, but the gate makes the request explicit instead of
 * silently failing later.
 */
export default function PermissionsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const { permissionsDone, setPermissionsDone } = useApp();

  const [notifications, setNotifications] = useState<PermissionState>('undetermined');
  const [vpn, setVpn] = useState<PermissionState>('undetermined');
  const [busy, setBusy] = useState<'notifications' | 'vpn' | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let alive = true;
    Promise.all([getNotificationPermission(), getVpnPermission()]).then(([notif, vpnState]) => {
      if (alive) {
        setNotifications(notif);
        setVpn(vpnState);
        setLoaded(true);
      }
    });
    return () => {
      alive = false;
    };
  }, []);

  // Both permissions are already in place (granted on an earlier run, or restored by the
  // system): there is nothing to ask, so record the gate as passed and go straight in.
  // This is what stops the request screen from appearing on every launch.
  useEffect(() => {
    if (!loaded || permissionsDone) return;
    if (notifications === 'granted' && vpn === 'granted') {
      setPermissionsDone(true);
      router.replace('/(tabs)');
    }
  }, [loaded, notifications, vpn, permissionsDone, setPermissionsDone, router]);

  const askNotifications = useCallback(async () => {
    tapFeedback();
    setBusy('notifications');
    const state = await requestNotificationPermission();
    setNotifications(state);
    setBusy(null);
    if (state === 'granted') successFeedback();
  }, []);

  const askVpn = useCallback(async () => {
    tapFeedback();
    setBusy('vpn');
    // This opens Android's real "Connection request" dialog and records the answer.
    const state = await requestVpnPermissionState();
    setVpn(state);
    setBusy(null);
    if (state === 'granted') successFeedback();
  }, []);

  const enter = () => {
    tapFeedback();
    // Remember that the gate has been answered, so it is not shown again on the next
    // launch. A permission the user later revokes in Android settings is still enforced
    // by Android itself at connect time.
    setPermissionsDone(true);
    router.replace('/(tabs)');
  };

  const bothDone = notifications === 'granted' && vpn === 'granted';

  return (
    <SafeAreaView edges={['top', 'left', 'right', 'bottom']} style={styles.root}>
      <AuroraBackground />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BrandMark size={56} />
          <Text style={[styles.title, { color: colors.text }]}>{t('permTitle')}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>{t('permBody')}</Text>
        </View>

        {!loaded ? (
          <ActivityIndicator color={colors.primary} style={styles.loader} />
        ) : (
          <View style={styles.cards}>
            <PermissionCard
              icon="notifications"
              iconColors={['#4DA3FF', '#A78BFA']}
              title={t('permNotifications')}
              body={t('permNotificationsBody')}
              state={notifications}
              busy={busy === 'notifications'}
              actionLabel={notifications === 'granted' ? t('permAllowed') : t('permAllow')}
              onPress={askNotifications}
              disabled={notifications === 'granted' || notifications === 'unavailable'}
              rtl={rtl}
            />

            <PermissionCard
              icon="shield-checkmark"
              iconColors={['#00D6D6', '#0A84FF']}
              title={t('permVpn')}
              body={t('permVpnBody')}
              state={vpn}
              busy={busy === 'vpn'}
              actionLabel={vpn === 'granted' ? t('permAllowed') : t('permAllow')}
              onPress={askVpn}
              disabled={vpn === 'granted' || vpn === 'unavailable'}
              rtl={rtl}
            />
          </View>
        )}

        <View style={styles.footer}>
          <Button
            title={bothDone ? t('permContinue') : t('permSkip')}
            icon={bothDone ? 'arrow-forward' : 'chevron-forward'}
            onPress={enter}
          />
          <Text style={[styles.note, { color: colors.faint }]}>{t('permNote')}</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function PermissionCard({
  icon,
  iconColors,
  title,
  body,
  state,
  busy,
  actionLabel,
  onPress,
  disabled,
  rtl,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconColors: readonly [string, string, ...string[]];
  title: string;
  body: string;
  state: PermissionState;
  busy: boolean;
  actionLabel: string;
  onPress: () => void;
  disabled: boolean;
  rtl: boolean;
}) {
  const colors = useColors();
  const granted = state === 'granted';
  const blocked = state === 'denied' || state === 'unavailable';

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.cardTop, rtl && styles.rowReverse]}>
        <LinearGradient colors={iconColors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.icon}>
          <Ionicons name={icon} size={22} color="#FFFFFF" />
        </LinearGradient>
        <View style={styles.cardText}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>{title}</Text>
          <Text style={[styles.cardBody, { color: colors.muted }]}>{body}</Text>
        </View>
      </View>

      <View style={[styles.statusRow, rtl && styles.rowReverse]}>
        <View
          style={[
            styles.statusPill,
            {
              backgroundColor: granted ? 'rgba(61,214,140,0.16)' : blocked ? 'rgba(255,107,107,0.16)' : colors.cardAlt,
            },
          ]}>
          <Ionicons
            name={granted ? 'checkmark-circle' : blocked ? 'close-circle' : 'ellipse-outline'}
            size={14}
            color={granted ? colors.success : blocked ? colors.danger : colors.muted}
          />
          <Text
            style={[
              styles.statusText,
              { color: granted ? colors.success : blocked ? colors.danger : colors.muted },
            ]}>
            {permissionLabel(state)}
          </Text>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={actionLabel}
          disabled={disabled || busy}
          onPress={onPress}
          style={({ pressed }) => [
            styles.action,
            { backgroundColor: colors.cardAlt, borderColor: colors.border },
            (disabled || busy) && { opacity: 0.5 },
            pressed && { opacity: 0.75 },
          ]}>
          {busy ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Text style={[styles.actionText, { color: colors.primary }]}>{actionLabel}</Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { padding: spacing.lg, gap: spacing.lg, paddingBottom: spacing.xl },
  header: { alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  title: { fontSize: 24, fontWeight: '900', textAlign: 'center', letterSpacing: -0.4 },
  subtitle: { fontSize: 14.5, lineHeight: 22, textAlign: 'center' },
  loader: { marginTop: spacing.xl },
  cards: { gap: spacing.md },
  card: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.md,
  },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm },
  rowReverse: { flexDirection: 'row-reverse' },
  icon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  cardText: { flex: 1, gap: 3 },
  cardTitle: { fontSize: 16, fontWeight: '800' },
  cardBody: { fontSize: 13, lineHeight: 19 },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  statusText: { fontSize: 12, fontWeight: '800' },
  action: {
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 16,
    paddingVertical: 9,
    minWidth: 96,
    alignItems: 'center',
  },
  actionText: { fontSize: 13, fontWeight: '800' },
  footer: { gap: spacing.sm, marginTop: spacing.sm },
  note: { fontSize: 12, lineHeight: 17, textAlign: 'center' },
});
