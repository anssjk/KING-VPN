package com.kingvpn.tunnel

import com.wireguard.crypto.Curve25519
import java.math.BigInteger
import java.security.SecureRandom

/**
 * The cryptography a WireGuard handshake needs, implemented here so the scanner can
 * prove an endpoint really works.
 *
 * ## Why this file exists
 *
 * The previous scanner probed endpoints with a **TCP connect**. WireGuard is **UDP**, so
 * TCP on 2408/500/1701/4500 is closed on every WARP edge — the probe reported "unreachable"
 * for addresses that were perfectly healthy, and the few that "passed" were passing a test
 * that had nothing to do with the tunnel. That is why the scanner found almost nothing and
 * why the configs it produced did not connect.
 *
 * The only probe that proves an endpoint will carry the tunnel is a **real WireGuard
 * handshake**: build a Noise IK initiation, send it over UDP, and wait for the peer's
 * handshake response. A peer that answers has accepted our key, our MAC and our
 * ciphertext — so the address, the port and the peer key are all correct.
 *
 * That needs BLAKE2s, ChaCha20-Poly1305 and X25519. Android ships none of the first two
 * in a form available on every supported API level, so they are implemented here and
 * checked against the published test vectors (see `WgCryptoTest`).
 */
object WgCrypto {

  // ---------------------------------------------------------------- BLAKE2s (RFC 7693)

  private val BLAKE2S_IV = intArrayOf(
    0x6A09E667, 0xBB67AE85.toInt(), 0x3C6EF372, 0xA54FF53A.toInt(),
    0x510E527F, 0x9B05688C.toInt(), 0x1F83D9AB, 0x5BE0CD19,
  )

  private val SIGMA = arrayOf(
    intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
    intArrayOf(14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3),
    intArrayOf(11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4),
    intArrayOf(7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8),
    intArrayOf(9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13),
    intArrayOf(2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9),
    intArrayOf(12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11),
    intArrayOf(13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10),
    intArrayOf(6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5),
    intArrayOf(10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0),
  )

  private fun rotr(x: Int, n: Int): Int = (x ushr n) or (x shl (32 - n))

  private fun g(v: IntArray, a: Int, b: Int, c: Int, d: Int, x: Int, y: Int) {
    v[a] = v[a] + v[b] + x
    v[d] = rotr(v[d] xor v[a], 16)
    v[c] = v[c] + v[d]
    v[b] = rotr(v[b] xor v[c], 12)
    v[a] = v[a] + v[b] + y
    v[d] = rotr(v[d] xor v[a], 8)
    v[c] = v[c] + v[d]
    v[b] = rotr(v[b] xor v[c], 7)
  }

  private fun compress(h: IntArray, block: ByteArray, offset: Int, counter: Long, last: Boolean) {
    val m = IntArray(16)
    for (i in 0 until 16) {
      val o = offset + i * 4
      m[i] = (block[o].toInt() and 0xFF) or
        ((block[o + 1].toInt() and 0xFF) shl 8) or
        ((block[o + 2].toInt() and 0xFF) shl 16) or
        ((block[o + 3].toInt() and 0xFF) shl 24)
    }
    val v = IntArray(16)
    for (i in 0 until 8) v[i] = h[i]
    for (i in 0 until 8) v[8 + i] = BLAKE2S_IV[i]
    v[12] = v[12] xor counter.toInt()
    v[13] = v[13] xor (counter ushr 32).toInt()
    if (last) v[14] = v[14].inv()

    for (r in 0 until 10) {
      val s = SIGMA[r]
      g(v, 0, 4, 8, 12, m[s[0]], m[s[1]])
      g(v, 1, 5, 9, 13, m[s[2]], m[s[3]])
      g(v, 2, 6, 10, 14, m[s[4]], m[s[5]])
      g(v, 3, 7, 11, 15, m[s[6]], m[s[7]])
      g(v, 0, 5, 10, 15, m[s[8]], m[s[9]])
      g(v, 1, 6, 11, 12, m[s[10]], m[s[11]])
      g(v, 2, 7, 8, 13, m[s[12]], m[s[13]])
      g(v, 3, 4, 9, 14, m[s[14]], m[s[15]])
    }
    for (i in 0 until 8) h[i] = h[i] xor v[i] xor v[i + 8]
  }

  /** BLAKE2s with a 32-byte digest and no key. */
  fun blake2s(data: ByteArray): ByteArray = blake2sCore(data, null, 32)

  /**
   * BLAKE2s core, with an optional key and a configurable digest length.
   *
   * The digest length is part of the parameter block, so a 16-byte BLAKE2s is **not** the
   * first 16 bytes of a 32-byte one. WireGuard's `MAC1` is a 16-byte keyed BLAKE2s, so
   * getting this wrong makes every handshake fail its MAC check.
   */
  private fun blake2sCore(data: ByteArray, key: ByteArray?, outLen: Int): ByteArray {
    val h = BLAKE2S_IV.copyOf()
    // Parameter block, little-endian: digest length, key length, fanout 1, depth 1.
    h[0] = h[0] xor 0x01010000 xor ((key?.size ?: 0) shl 8) xor outLen
    var counter = 0L

    // Keyed mode: the key, zero-padded to one block, is the first block.
    if (key != null && key.isNotEmpty()) {
      val block = ByteArray(64)
      System.arraycopy(key, 0, block, 0, minOf(key.size, 64))
      counter = 64L
      // With no message the key block is also the final block.
      if (data.isEmpty()) {
        compress(h, block, 0, counter, true)
        return digest(h, outLen)
      }
      compress(h, block, 0, counter, false)
    }

    var offset = 0
    val len = data.size
    // Every full block except the last is compressed as a non-final block.
    while (len - offset > 64) {
      counter += 64
      compress(h, data, offset, counter, false)
      offset += 64
    }
    // Final block, zero-padded to 64 bytes.
    val last = ByteArray(64)
    val remaining = len - offset
    if (remaining > 0) System.arraycopy(data, offset, last, 0, remaining)
    counter += remaining.toLong()
    compress(h, last, 0, counter, true)
    return digest(h, outLen)
  }

  private fun digest(h: IntArray, outLen: Int): ByteArray {
    val out = ByteArray(outLen)
    for (i in 0 until outLen) {
      val word = h[i / 4]
      out[i] = ((word ushr (8 * (i % 4))) and 0xFF).toByte()
    }
    return out
  }

  /**
   * BLAKE2s used as a keyed MAC — WireGuard's `MAC()` (16-byte) and `HMAC()` (32-byte).
   */
  fun hmacBlake2s(key: ByteArray, data: ByteArray, outLen: Int = 32): ByteArray =
    blake2sCore(data, key, outLen)

  fun hash(a: ByteArray, b: ByteArray): ByteArray {
    val joined = ByteArray(a.size + b.size)
    System.arraycopy(a, 0, joined, 0, a.size)
    System.arraycopy(b, 0, joined, a.size, b.size)
    return blake2s(joined)
  }

  // ------------------------------------------------------- ChaCha20-Poly1305 (RFC 8439)

  private fun rotl(x: Int, n: Int): Int = (x shl n) or (x ushr (32 - n))

  private fun quarterRound(s: IntArray, a: Int, b: Int, c: Int, d: Int) {
    s[a] += s[b]; s[d] = rotl(s[d] xor s[a], 16)
    s[c] += s[d]; s[b] = rotl(s[b] xor s[c], 12)
    s[a] += s[b]; s[d] = rotl(s[d] xor s[a], 8)
    s[c] += s[d]; s[b] = rotl(s[b] xor s[c], 7)
  }

  private fun chachaBlock(key: ByteArray, counter: Int, nonce: ByteArray): ByteArray {
    val s = IntArray(16)
    s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574
    for (i in 0 until 8) {
      val o = i * 4
      s[4 + i] = (key[o].toInt() and 0xFF) or
        ((key[o + 1].toInt() and 0xFF) shl 8) or
        ((key[o + 2].toInt() and 0xFF) shl 16) or
        ((key[o + 3].toInt() and 0xFF) shl 24)
    }
    s[12] = counter
    for (i in 0 until 3) {
      val o = i * 4
      s[13 + i] = (nonce[o].toInt() and 0xFF) or
        ((nonce[o + 1].toInt() and 0xFF) shl 8) or
        ((nonce[o + 2].toInt() and 0xFF) shl 16) or
        ((nonce[o + 3].toInt() and 0xFF) shl 24)
    }
    val w = s.copyOf()
    for (i in 0 until 10) {
      quarterRound(w, 0, 4, 8, 12)
      quarterRound(w, 1, 5, 9, 13)
      quarterRound(w, 2, 6, 10, 14)
      quarterRound(w, 3, 7, 11, 15)
      quarterRound(w, 0, 5, 10, 15)
      quarterRound(w, 1, 6, 11, 12)
      quarterRound(w, 2, 7, 8, 13)
      quarterRound(w, 3, 4, 9, 14)
    }
    val out = ByteArray(64)
    for (i in 0 until 16) {
      val v = w[i] + s[i]
      out[i * 4] = (v and 0xFF).toByte()
      out[i * 4 + 1] = ((v ushr 8) and 0xFF).toByte()
      out[i * 4 + 2] = ((v ushr 16) and 0xFF).toByte()
      out[i * 4 + 3] = ((v ushr 24) and 0xFF).toByte()
    }
    return out
  }

  private fun chachaXor(key: ByteArray, counter: Int, nonce: ByteArray, input: ByteArray): ByteArray {
    val out = ByteArray(input.size)
    var c = counter
    var offset = 0
    while (offset < input.size) {
      val block = chachaBlock(key, c, nonce)
      val n = minOf(64, input.size - offset)
      for (i in 0 until n) out[offset + i] = (input[offset + i].toInt() xor block[i].toInt()).toByte()
      offset += n
      c += 1
    }
    return out
  }

  private val P1305 = BigInteger.ONE.shiftLeft(130).subtract(BigInteger.valueOf(5))

  private fun leToBig(bytes: ByteArray, offset: Int, len: Int): BigInteger {
    val be = ByteArray(len)
    for (i in 0 until len) be[len - 1 - i] = bytes[offset + i]
    return BigInteger(1, be)
  }

  private fun bigToLe(value: BigInteger, len: Int): ByteArray {
    val be = value.toByteArray()
    val out = ByteArray(len)
    // BigInteger.toByteArray() is big-endian and may carry a leading sign byte.
    val start = if (be.size > len) be.size - len else 0
    val n = minOf(len, be.size)
    for (i in 0 until n) out[i] = be[be.size - 1 - i]
    if (start > 0) { /* value was wider than len; low bytes already copied */ }
    return out
  }

  private fun poly1305(key: ByteArray, message: ByteArray): ByteArray {
    val rBytes = key.copyOfRange(0, 16)
    rBytes[3] = (rBytes[3].toInt() and 15).toByte()
    rBytes[7] = (rBytes[7].toInt() and 15).toByte()
    rBytes[11] = (rBytes[11].toInt() and 15).toByte()
    rBytes[15] = (rBytes[15].toInt() and 15).toByte()
    rBytes[4] = (rBytes[4].toInt() and 252).toByte()
    rBytes[8] = (rBytes[8].toInt() and 252).toByte()
    rBytes[12] = (rBytes[12].toInt() and 252).toByte()
    val r = leToBig(rBytes, 0, 16)
    val s = leToBig(key, 16, 16)

    var acc = BigInteger.ZERO
    var offset = 0
    while (offset < message.size) {
      val n = minOf(16, message.size - offset)
      val block = ByteArray(n + 1)
      System.arraycopy(message, offset, block, 0, n)
      block[n] = 1
      acc = acc.add(leToBig(block, 0, n + 1)).multiply(r).mod(P1305)
      offset += n
    }
    acc = acc.add(s)
    return bigToLe(acc, 16)
  }

  private fun pad16(len: Int): ByteArray = ByteArray((16 - (len % 16)) % 16)

  private fun le64(value: Long): ByteArray {
    val out = ByteArray(8)
    for (i in 0 until 8) out[i] = ((value ushr (8 * i)) and 0xFF).toByte()
    return out
  }

  /**
   * AEAD_CHACHA20_POLY1305 (RFC 8439 §2.8) with a 12-byte nonce.
   * Returns ciphertext followed by the 16-byte tag.
   */
  fun aeadEncrypt(key: ByteArray, nonce: ByteArray, plaintext: ByteArray, aad: ByteArray): ByteArray {
    val polyKey = chachaBlock(key, 0, nonce).copyOfRange(0, 32)
    val ciphertext = chachaXor(key, 1, nonce, plaintext)

    val mac = java.io.ByteArrayOutputStream()
    mac.write(aad)
    mac.write(pad16(aad.size))
    mac.write(ciphertext)
    mac.write(pad16(ciphertext.size))
    mac.write(le64(aad.size.toLong()))
    mac.write(le64(ciphertext.size.toLong()))
    val tag = poly1305(polyKey, mac.toByteArray())

    val out = ByteArray(ciphertext.size + 16)
    System.arraycopy(ciphertext, 0, out, 0, ciphertext.size)
    System.arraycopy(tag, 0, out, ciphertext.size, 16)
    return out
  }

  // ------------------------------------------------------------------------ X25519

  /**
   * X25519 scalar multiplication, using the WireGuard library's constant-time curve.
   *
   * `Curve25519.eval(out, outOff, scalar, point)` takes an *offset* into `out`, not a
   * length — passing 32 there writes past the end of a 32-byte array.
   */
  fun x25519(scalar: ByteArray, point: ByteArray): ByteArray {
    val out = ByteArray(32)
    Curve25519.eval(out, 0, scalar, point)
    return out
  }

  // ------------------------------------------------------------- WireGuard handshake

  private val CONSTRUCTION = "Noise_IKpsk2_25519_ChaChaPoly_BLAKE2s".toByteArray(Charsets.US_ASCII)
  private val IDENTIFIER = "WireGuard v1 zx2c4 Jason@zx2c4.com".toByteArray(Charsets.US_ASCII)
  private val LABEL_MAC1 = "mac1----".toByteArray(Charsets.US_ASCII)

  /** HKDF as WireGuard defines it: one or two 32-byte outputs. */
  private fun kdf(key: ByteArray, input: ByteArray, count: Int): Array<ByteArray> {
    val t0 = hmacBlake2s(key, input)
    val out = arrayOfNulls<ByteArray>(count)
    out[0] = hmacBlake2s(t0, byteArrayOf(1))
    for (i in 1 until count) {
      val prev = out[i - 1]!!
      val data = ByteArray(prev.size + 1)
      System.arraycopy(prev, 0, data, 0, prev.size)
      data[prev.size] = (i + 1).toByte()
      out[i] = hmacBlake2s(t0, data)
    }
    @Suppress("UNCHECKED_CAST")
    return out as Array<ByteArray>
  }

  fun kdf1(key: ByteArray, input: ByteArray): ByteArray = kdf(key, input, 1)[0]
  fun kdf2(key: ByteArray, input: ByteArray): Array<ByteArray> = kdf(key, input, 2)

  /** TAI64N timestamp — WireGuard's replay-protection clock. */
  fun tai64n(nowMillis: Long = System.currentTimeMillis()): ByteArray {
    val sec = nowMillis / 1000
    val nsec = (nowMillis % 1000) * 1_000_000
    val out = ByteArray(12)
    val base = 0x400000000000000aL + sec
    for (i in 0 until 8) out[i] = ((base ushr (8 * (7 - i))) and 0xFF).toByte()
    for (i in 0 until 4) out[8 + i] = ((nsec ushr (8 * (3 - i))) and 0xFF).toByte()
    return out
  }

  /**
   * Build a WireGuard handshake **initiation** message (type 1, 148 bytes).
   *
   * This is the exact message the tunnel's own handshake sends, so a peer that answers it
   * will also answer the tunnel. `ephemeral` and `timestamp` are parameters so the result
   * is reproducible in tests.
   */
  fun handshakeInitiation(
    privateKey: ByteArray,
    peerPublicKey: ByteArray,
    senderIndex: Int,
    ephemeralPrivate: ByteArray,
    timestamp: ByteArray,
  ): ByteArray {
    val staticPublic = x25519(privateKey, BASE_POINT)

    // WireGuard's Noise IK prologue, exactly as the spec defines it:
    //   chaining_key = HASH(CONSTRUCTION)
    //   hash         = HASH(HASH(chaining_key || IDENTIFIER) || responder_static_public)
    // The construction string is hashed on its own first — folding IDENTIFIER into the
    // same hash produces a different chaining key and every AEAD tag then fails.
    var ci = blake2s(CONSTRUCTION)
    var hi = hash(hash(ci, IDENTIFIER), peerPublicKey)

    val ephemeralPublic = x25519(ephemeralPrivate, BASE_POINT)
    // Noise IK step: C = KDF1(C, Epub), then H = HASH(H || Epub).
    ci = kdf(ci, ephemeralPublic, 1)[0]
    hi = hash(hi, ephemeralPublic)

    // Encrypt our static public key with the ephemeral-static DH.
    //
    // WireGuard's KDF2 returns (chaining_key, key) in that order. The *second* output is
    // the AEAD key; the first becomes the new chaining key for the next step. Using the
    // first output as the key — and not advancing the chaining key — produces a message
    // that looks well-formed but fails every peer's tag check.
    val es = kdf(ci, x25519(ephemeralPrivate, peerPublicKey), 2)
    ci = es[0]
    val encryptedStatic = aeadEncrypt(es[1], ByteArray(12), staticPublic, hi)
    hi = hash(hi, encryptedStatic)

    // Encrypt the timestamp with the static-static DH.
    val ss = kdf(ci, x25519(privateKey, peerPublicKey), 2)
    val encryptedTimestamp = aeadEncrypt(ss[1], ByteArray(12), timestamp, hi)

    val msg = ByteArray(148)
    msg[0] = 1
    // bytes 1..3 are reserved zeros
    msg[4] = (senderIndex and 0xFF).toByte()
    msg[5] = ((senderIndex ushr 8) and 0xFF).toByte()
    msg[6] = ((senderIndex ushr 16) and 0xFF).toByte()
    msg[7] = ((senderIndex ushr 24) and 0xFF).toByte()
    System.arraycopy(ephemeralPublic, 0, msg, 8, 32)
    System.arraycopy(encryptedStatic, 0, msg, 40, 48)
    System.arraycopy(encryptedTimestamp, 0, msg, 88, 28)

    // mac1 authenticates the message to the peer using a key derived from its public key.
    // WireGuard's MAC() is a 16-byte keyed BLAKE2s, not a truncated 32-byte one.
    val mac1Key = hash(LABEL_MAC1, peerPublicKey)
    val mac1 = hmacBlake2s(mac1Key, msg.copyOfRange(0, 116), 16)
    System.arraycopy(mac1, 0, msg, 116, 16)
    // mac2 stays zero: it is only required when the peer has a cookie requirement.
    return msg
  }

  private val BASE_POINT = ByteArray(32).also { it[0] = 9 }

  fun randomBytes(n: Int): ByteArray {
    val out = ByteArray(n)
    SecureRandom().nextBytes(out)
    return out
  }

  /** Clamp a raw 32-byte value into a valid X25519 private key. */
  fun clampPrivateKey(raw: ByteArray): ByteArray {
    val k = raw.copyOf(32)
    k[0] = (k[0].toInt() and 248).toByte()
    k[31] = ((k[31].toInt() and 127) or 64).toByte()
    return k
  }
}
