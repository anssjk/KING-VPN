package com.kingvpn.tunnel

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLContext
import javax.net.ssl.SNIHostName

/**
 * The scanner's real probe: a complete WireGuard handshake over UDP.
 *
 * ## Why the old probe was wrong
 *
 * The previous scanner opened a **TCP** connection to the endpoint. WireGuard is **UDP**,
 * so TCP on 2408/500/1701/4500 is closed on every WARP edge. The probe therefore reported
 * "unreachable" for healthy addresses, and the handful that passed were passing a test
 * that had nothing to do with the tunnel. That is why the scanner found almost nothing and
 * why the configs it produced did not connect.
 *
 * ## What this does instead
 *
 * It performs the same handshake the tunnel performs:
 *
 *   1. build a Noise IK **initiation** (type 1, 148 bytes) with a fresh ephemeral key,
 *   2. send it over UDP to the endpoint,
 *   3. wait for the peer's **response** (type 2, 92 bytes),
 *   4. verify the response is addressed to our sender index and that its `mac1` is correct.
 *
 * A peer that answers a valid initiation has accepted our key, our MAC and our ciphertext.
 * That is proof the address, the port and the peer key are all correct — the exact triple
 * the tunnel config is built from. Nothing weaker is reported as success.
 */
object WgProbe {

  /** WireGuard message types. */
  private const val TYPE_INITIATION = 1
  private const val TYPE_RESPONSE = 2

  private const val INITIATION_SIZE = 148
  private const val RESPONSE_SIZE = 92

  private val LABEL_MAC1 = "mac1----".toByteArray(Charsets.US_ASCII)

  data class Result(
    val host: String,
    val port: Int,
    val ok: Boolean,
    /** Handshake round-trip in ms — the latency of the path the tunnel will take. */
    val ms: Int?,
    val error: String?,
    /** Cloudflare data centre the endpoint routes to, when it could be read. */
    val colo: String?,
    /** Country the edge reports for this path, when it could be read. */
    val loc: String?,
  )

  /**
   * Probe one endpoint with a real handshake.
   *
   * `privateKey` and `peerPublicKey` are the device's own registration, so the handshake is
   * the one the tunnel will actually use — not a synthetic one that might be accepted where
   * the real one would not.
   */
  fun probeOne(
    host: String,
    port: Int,
    privateKey: ByteArray,
    peerPublicKey: ByteArray,
    timeoutMs: Int,
  ): Result {
    val started = System.currentTimeMillis()
    var socket: DatagramSocket? = null
    try {
      val senderIndex = WgCrypto.randomBytes(4).let {
        (it[0].toInt() and 0xFF) or ((it[1].toInt() and 0xFF) shl 8) or
          ((it[2].toInt() and 0xFF) shl 16) or ((it[3].toInt() and 0xFF) shl 24)
      }
      val ephemeral = WgCrypto.clampPrivateKey(WgCrypto.randomBytes(32))
      val initiation = WgCrypto.handshakeInitiation(
        privateKey = privateKey,
        peerPublicKey = peerPublicKey,
        senderIndex = senderIndex,
        ephemeralPrivate = ephemeral,
        timestamp = WgCrypto.tai64n(),
      )

      socket = DatagramSocket()
      socket.soTimeout = timeoutMs
      val address = InetAddress.getByName(host)
      socket.send(DatagramPacket(initiation, initiation.size, InetSocketAddress(address, port)))

      val buffer = ByteArray(256)
      val packet = DatagramPacket(buffer, buffer.size)
      socket.receive(packet)

      val ms = (System.currentTimeMillis() - started).toInt()
      val reply = buffer.copyOf(packet.length)

      if (reply.size < RESPONSE_SIZE || reply[0].toInt() != TYPE_RESPONSE) {
        return Result(host, port, false, ms, "Unexpected reply (not a handshake response)", null, null)
      }
      // The response must be addressed to the index we chose, or it belongs to another session.
      val receiverIndex = (reply[8].toInt() and 0xFF) or ((reply[9].toInt() and 0xFF) shl 8) or
        ((reply[10].toInt() and 0xFF) shl 16) or ((reply[11].toInt() and 0xFF) shl 24)
      if (receiverIndex != senderIndex) {
        return Result(host, port, false, ms, "Reply was for a different session", null, null)
      }
      // mac1 proves the peer processed our initiation: it is keyed with our own public key.
      val ourPublic = WgCrypto.x25519(privateKey, ByteArray(32).also { it[0] = 9 })
      val expectedMac1 = WgCrypto.hmacBlake2s(
        WgCrypto.hash(LABEL_MAC1, ourPublic),
        reply.copyOfRange(0, 60),
        16,
      )
      val actualMac1 = reply.copyOfRange(60, 76)
      if (!expectedMac1.contentEquals(actualMac1)) {
        return Result(host, port, false, ms, "Handshake reply failed its MAC check", null, null)
      }

      return Result(host, port, true, ms, null, null, null)
    } catch (e: java.net.SocketTimeoutException) {
      return Result(host, port, false, null, "No handshake reply (port filtered or host down)", null, null)
    } catch (e: Exception) {
      return Result(host, port, false, null, e.message ?: e.javaClass.simpleName, null, null)
    } finally {
      try {
        socket?.close()
      } catch (_: Exception) {
      }
    }
  }

  /**
   * Read the Cloudflare data centre an endpoint routes to, through that exact address.
   *
   * This is a real per-endpoint measurement: the TLS connection is opened to `host` with the
   * edge's server name, and `/cdn-cgi/trace` reports the `colo` (the data centre that
   * answered) and `loc` (the country the edge sees). Because it is measured from the user's
   * own network, two addresses in the same anycast range can legitimately report different
   * data centres — which is exactly the information the scanner needs to rank them.
   */
  fun resolveColo(host: String, timeoutMs: Int): Pair<String?, String?> {
    var socket: Socket? = null
    try {
      val raw = Socket()
      socket = raw
      raw.connect(InetSocketAddress(host, 443), timeoutMs)
      raw.soTimeout = timeoutMs
      val factory = SSLContext.getDefault().socketFactory
      val ssl = factory.createSocket(raw, "engage.cloudflareclient.com", 443, true) as SSLSocket
      ssl.sslParameters = ssl.sslParameters.apply {
        serverNames = listOf(SNIHostName("engage.cloudflareclient.com"))
        endpointIdentificationAlgorithm = "HTTPS"
      }
      ssl.startHandshake()
      val request = "GET /cdn-cgi/trace HTTP/1.1\r\nHost: engage.cloudflareclient.com\r\n" +
        "User-Agent: KINGVPN/1.0\r\nAccept: text/plain\r\nConnection: close\r\n\r\n"
      ssl.outputStream.write(request.toByteArray(Charsets.US_ASCII))
      ssl.outputStream.flush()

      val body = StringBuilder()
      val reader = ssl.inputStream.bufferedReader()
      var line: String?
      var inBody = false
      while (true) {
        line = reader.readLine() ?: break
        if (!inBody) {
          if (line.isEmpty()) inBody = true
          continue
        }
        body.append(line).append('\n')
        if (body.length > 4096) break
      }
      var colo: String? = null
      var loc: String? = null
      for (l in body.toString().split('\n')) {
        val idx = l.indexOf('=')
        if (idx <= 0) continue
        val key = l.substring(0, idx).trim()
        val value = l.substring(idx + 1).trim()
        if (key == "colo") colo = value
        if (key == "loc") loc = value
      }
      try {
        ssl.close()
      } catch (_: Exception) {
      }
      return colo to loc
    } catch (e: Exception) {
      return null to null
    } finally {
      try {
        socket?.close()
      } catch (_: Exception) {
      }
    }
  }

  /**
   * Probe many endpoints concurrently.
   *
   * Runs on a fixed thread pool so a scan of thousands of endpoints finishes in seconds
   * rather than minutes, and reports each result as it lands so the UI can stream.
   */
  fun probeMany(
    endpoints: List<Pair<String, Int>>,
    privateKey: ByteArray,
    peerPublicKey: ByteArray,
    timeoutMs: Int,
    concurrency: Int,
    resolveColo: Boolean,
    onResult: (Result) -> Unit,
    shouldStop: () -> Boolean,
  ): List<Result> {
    val pool = Executors.newFixedThreadPool(concurrency.coerceIn(1, 256))
    val results = java.util.Collections.synchronizedList(mutableListOf<Result>())
    try {
      val tasks = endpoints.map { (host, port) ->
        Callable {
          if (shouldStop()) return@Callable null
          var r = probeOne(host, port, privateKey, peerPublicKey, timeoutMs)
          if (r.ok && resolveColo) {
            val (colo, loc) = resolveColo(host, timeoutMs)
            r = r.copy(colo = colo, loc = loc)
          }
          results.add(r)
          onResult(r)
          r
        }
      }
      val futures = pool.invokeAll(tasks)
      // Surface a task that threw rather than silently dropping it.
      for (f in futures) {
        try {
          f.get()
        } catch (_: Exception) {
        }
      }
    } finally {
      pool.shutdownNow()
      try {
        pool.awaitTermination(2, TimeUnit.SECONDS)
      } catch (_: Exception) {
      }
    }
    return results.toList()
  }
}
