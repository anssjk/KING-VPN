package com.kingvpn.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Keeps the VPN process alive while the tunnel is up.
 *
 * A `VpnService` started from an Activity runs fine in the foreground, but Android
 * reclaims background services aggressively — and a reclaimed process takes the tunnel
 * with it. A foreground service with a persistent notification is the supported way to
 * say "this is doing something the user asked for, keep it running", which is exactly
 * what a VPN is.
 *
 * The notification is also the honest place to show the tunnel is active: it appears
 * when the tunnel comes up and disappears when it goes down.
 */
class KingVpnForegroundService : Service() {

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val notification = buildNotification()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      // `specialUse` is the type Android 14 requires for a service that does not fit a
      // narrower category; a VPN tunnel is exactly that.
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
    // Not sticky: if the process dies the tunnel is gone anyway, and silently restarting
    // a VPN the user did not ask for would be wrong.
    return START_NOT_STICKY
  }

  private fun buildNotification(): Notification {
    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "VPN connection",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Shown while the VPN tunnel is active"
        setShowBadge(false)
      }
      manager.createNotificationChannel(channel)
    }

    // Tapping the notification reopens the app.
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val pending = if (launch != null) {
      PendingIntent.getActivity(
        this,
        0,
        launch,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    } else {
      null
    }

    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      Notification.Builder(this, CHANNEL_ID)
    } else {
      @Suppress("DEPRECATION")
      Notification.Builder(this)
    }

    builder
      .setContentTitle("KING VPN is connected")
      .setContentText("Your traffic is routed through the tunnel")
      // A public SDK icon: `stat_sys_vpn_ic` is a hidden system resource and is not
      // available to third-party apps.
      .setSmallIcon(android.R.drawable.ic_lock_lock)
      .setOngoing(true)
      .setShowWhen(false)

    if (pending != null) {
      builder.setContentIntent(pending)
    }

    return builder.build()
  }

  companion object {
    private const val CHANNEL_ID = "kingvpn_tunnel"
    private const val NOTIFICATION_ID = 4711

    /** Start the keep-alive service. Safe to call when it is already running. */
    fun start(context: Context) {
      val intent = Intent(context, KingVpnForegroundService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    /** Stop the keep-alive service and remove its notification. */
    fun stop(context: Context) {
      context.stopService(Intent(context, KingVpnForegroundService::class.java))
    }
  }
}
