package com.kingvpn.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * The real Android VPN service.
 *
 * This is the class that makes KING VPN an actual VPN client. It extends
 * `android.net.VpnService`, which is the only way an app can create a TUN interface and
 * route the device's traffic through it. Everything else in the app is a client of this
 * service.
 *
 * ## The data path
 *
 * ```
 *   apps ──► TUN (this service) ──► hev-socks5-tunnel ──► Xray SOCKS5 (127.0.0.1:1080)
 *                                                              │
 *                                                              ▼
 *                                          VLESS / VMess / Trojan / Shadowsocks
 *                                          over TCP / WS / gRPC / XHTTP / TLS / REALITY
 *                                                              │
 *                                                              ▼
 *                                                          the server
 * ```
 *
 * The service owns the TUN file descriptor and hands it to the bridge; the bridge hands
 * packets to Xray; Xray speaks the configured protocol to the server. Nothing here
 * reports success it did not observe: `start` only returns once the TUN exists, the core
 * is running and the bridge is up, and any failure tears the whole chain down again.
 */
class KingVpnService : VpnService() {

  override fun onBind(intent: Intent?) = super.onBind(intent)

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_START -> handleStart(intent)
      ACTION_STOP -> {
        teardown()
        stopSelf()
      }
    }
    return START_NOT_STICKY
  }

  private fun handleStart(intent: Intent) {
    val configJson = intent.getStringExtra(EXTRA_CONFIG) ?: run {
      fail("No core config was supplied.")
      return
    }
    val mtu = intent.getIntExtra(EXTRA_MTU, DEFAULT_MTU)

    // A previous session must be fully down before a new one starts, or the old TUN
    // would keep the interface and the new one would silently do nothing.
    teardown()

    // Android requires a service started with startForegroundService() to call
    // startForeground() within a few seconds, or it kills the process. The tunnel takes
    // longer than that to come up, so the notification goes up first and is updated once
    // the chain is running.
    startForegroundNotification()

    try {
      // 1. The TUN interface. `Builder` is the VpnService API that creates it; the
      //    addresses and routes here are what make the device send its traffic to us.
      val builder = Builder()
        .setSession("KING VPN")
        .setMtu(mtu)
        .addAddress(TUN_ADDRESS, 32)
        .addRoute("0.0.0.0", 0)
        .addDnsServer(DNS_PRIMARY)
        .addDnsServer(DNS_SECONDARY)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        builder.setMetered(false)
      }
      // Keep our own traffic to the proxy out of the tunnel, or it would loop.
      try {
        builder.addDisallowedApplication(packageName)
      } catch (_: Exception) {
        // Not fatal: the SOCKS port is loopback, which the TUN does not capture anyway.
      }

      val descriptor: ParcelFileDescriptor = builder.establish()
        ?: run {
          fail("Android refused to create the VPN interface.")
          return
        }
      tunDescriptor = descriptor

      // 2. The core. It listens on the loopback SOCKS port; the bridge feeds it.
      if (!XrayEngine.start(this, configJson)) {
        fail(XrayEngine.lastError ?: "The core did not start.")
        return
      }

      // 3. The bridge, on the TUN fd. This is what actually moves packets.
      if (!HevTunnel.start(this, descriptor.fd, mtu)) {
        fail(HevTunnel.lastError ?: "The TUN bridge did not start.")
        return
      }

      running = true
      sendBroadcast(Intent(ACTION_STATE).putExtra(EXTRA_STATE, "UP").setPackage(packageName))
    } catch (e: Throwable) {
      fail(e.message ?: e.javaClass.simpleName)
    }
  }

  /** Tear the whole chain down, in reverse order, tolerating any part already being down. */
  private fun teardown() {
    running = false
    HevTunnel.stop()
    XrayEngine.stop()
    try {
      tunDescriptor?.close()
    } catch (_: Throwable) {
    }
    tunDescriptor = null
    stopForegroundNotification()
    sendBroadcast(Intent(ACTION_STATE).putExtra(EXTRA_STATE, "DOWN").setPackage(packageName))
  }

  private fun fail(reason: String) {
    lastError = reason
    teardown()
    stopSelf()
  }

  override fun onRevoke() {
    // Android calls this when another VPN takes over or the user revokes consent.
    teardown()
    stopSelf()
  }

  override fun onDestroy() {
    teardown()
    super.onDestroy()
  }

  // ---- Foreground notification -------------------------------------------------------

  private fun startForegroundNotification() {
    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        "VPN connection",
        NotificationManager.IMPORTANCE_LOW
      ).apply {
        description = "Shown while the VPN tunnel is active"
        setShowBadge(false)
      }
      manager.createNotificationChannel(channel)
    }

    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val pending = if (launch != null) {
      PendingIntent.getActivity(
        this,
        0,
        launch,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    } else {
      null
    }

    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      Notification.Builder(this, CHANNEL_ID)
    } else {
      @Suppress("DEPRECATION")
      Notification.Builder(this)
    }

    builder
      .setContentTitle("KING VPN is connected")
      .setContentText("Your traffic is routed through the tunnel")
      .setSmallIcon(android.R.drawable.ic_lock_lock)
      .setOngoing(true)
      .setShowWhen(false)
    if (pending != null) builder.setContentIntent(pending)

    val notification = builder.build()
    // `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` only exists from API 34; passing it to
    // startForeground on an older release throws. Below 34 the two-argument form is used,
    // which takes the type from the manifest.
    if (Build.VERSION.SDK_INT >= 34) {
      startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun stopForegroundNotification() {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        stopForeground(STOP_FOREGROUND_REMOVE)
      } else {
        @Suppress("DEPRECATION")
        stopForeground(true)
      }
    } catch (_: Throwable) {
    }
  }

  companion object {
    const val ACTION_START = "com.kingvpn.tunnel.START"
    const val ACTION_STOP = "com.kingvpn.tunnel.STOP"
    const val ACTION_STATE = "com.kingvpn.tunnel.STATE"
    const val EXTRA_CONFIG = "config"
    const val EXTRA_MTU = "mtu"
    const val EXTRA_STATE = "state"

    private const val CHANNEL_ID = "kingvpn_tunnel"
    private const val NOTIFICATION_ID = 4711
    private const val DEFAULT_MTU = 1500
    private const val TUN_ADDRESS = "198.18.0.1"
    private const val DNS_PRIMARY = "1.1.1.1"
    private const val DNS_SECONDARY = "1.0.0.1"

    /** The live TUN descriptor, or null when the tunnel is down. */
    @Volatile
    private var tunDescriptor: ParcelFileDescriptor? = null

    @Volatile
    var running: Boolean = false
      private set

    /** The last failure, so the UI can show the real reason. */
    @Volatile
    var lastError: String? = null

    /** Start the tunnel with a full Xray JSON config. */
    fun start(context: Context, configJson: String, mtu: Int = DEFAULT_MTU) {
      lastError = null
      val intent = Intent(context, KingVpnService::class.java).apply {
        action = ACTION_START
        putExtra(EXTRA_CONFIG, configJson)
        putExtra(EXTRA_MTU, mtu)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    /** Stop the tunnel. Safe to call when it is already down. */
    fun stop(context: Context) {
      // `stopService` rather than a START intent: starting a service from the background
      // is refused on Android 8+, and stopping does not need a command.
      try {
        context.stopService(Intent(context, KingVpnService::class.java))
      } catch (_: Exception) {
        // Already stopped.
      }
    }

    /** Real traffic counters from the bridge: `[txPackets, txBytes, rxPackets, rxBytes]`. */
    fun stats(): LongArray = HevTunnel.stats()

    fun isRunning(): Boolean = running && HevTunnel.isRunning()
  }
}
