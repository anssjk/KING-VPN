/**
 * Entry point for the `king-vpn-tunnel` local Expo module.
 *
 * The module is Android-only and has no JavaScript implementation of its own: the
 * TypeScript bridge lives in `src/lib/tunnel.ts`, which talks to the native module
 * through `requireOptionalNativeModule('KingVpnTunnel')`. This file exists because
 * `package.json` names it as `main`, and Expo's autolinking expects it to resolve.
 */
export {};
