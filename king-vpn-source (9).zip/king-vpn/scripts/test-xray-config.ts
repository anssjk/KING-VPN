/**
 * Real tests for the config parser and the Xray JSON builder.
 *
 * These run in Node (no Android needed) because both files are pure TypeScript. They
 * check the things that actually break in the field: a link whose fields are silently
 * dropped, a transport that is emitted without its required settings, and a routing rule
 * that would loop the connection to the server back into the proxy.
 *
 * Build and run:
 *   npx tsc src/lib/xray-config.ts scripts/test-xray-config.ts \
 *     --outDir /tmp/xtest --module commonjs --target es2020 --skipLibCheck --ignoreConfig
 *   node /tmp/xtest/scripts/test-xray-config.js
 */
import {
  buildXrayConfig,
  describeConfig,
  isIpLiteral,
  parseLink,
  parseSubscription,
  withAddressOverride,
  type ServerConfig,
} from '../src/lib/xray-config';

let passed = 0;
let failed = 0;

function check(name: string, condition: boolean, detail?: string) {
  if (condition) {
    passed += 1;
    console.log(`  ok   ${name}`);
  } else {
    failed += 1;
    console.log(`  FAIL ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function eq(name: string, actual: unknown, expected: unknown) {
  check(
    name,
    JSON.stringify(actual) === JSON.stringify(expected),
    `got ${JSON.stringify(actual)}, want ${JSON.stringify(expected)}`,
  );
}

console.log('\n== VLESS over REALITY ==');
{
  const link =
    'vless://11111111-2222-3333-4444-555555555555@example.com:443' +
    '?type=tcp&security=reality&sni=www.microsoft.com&fp=chrome' +
    '&pbk=abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJ&sid=ab12&flow=xtls-rprx-vision#My%20Node';
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    const c = r.config;
    eq('protocol', c.protocol, 'vless');
    eq('address', c.address, 'example.com');
    eq('port', c.port, 443);
    eq('uuid', c.uuid, '11111111-2222-3333-4444-555555555555');
    eq('network', c.network, 'tcp');
    eq('security', c.security, 'reality');
    eq('sni', c.sni, 'www.microsoft.com');
    eq('fingerprint', c.fingerprint, 'chrome');
    eq('publicKey', c.publicKey, 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJ');
    eq('shortId', c.shortId, 'ab12');
    eq('flow', c.flow, 'xtls-rprx-vision');
    eq('name', c.name, 'My Node');

    const json = JSON.parse(buildXrayConfig(c));
    eq('inbound port', json.inbounds[0].port, 1080);
    eq('outbound protocol', json.outbounds[0].protocol, 'vless');
    eq('stream security', json.outbounds[0].streamSettings.security, 'reality');
    eq(
      'reality publicKey',
      json.outbounds[0].streamSettings.realitySettings.publicKey,
      'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJ',
    );
    eq('reality shortId', json.outbounds[0].streamSettings.realitySettings.shortId, 'ab12');
    eq(
      'reality serverName',
      json.outbounds[0].streamSettings.realitySettings.serverName,
      'www.microsoft.com',
    );
    eq('user flow', json.outbounds[0].settings.vnext[0].users[0].flow, 'xtls-rprx-vision');
    // A hostname must be routed by `domain`, not `ip`.
    eq('routing uses domain', json.routing.rules[0].domain, ['full:example.com']);
    check('routing has no ip field', json.routing.rules[0].ip === undefined);
  }
}

console.log('\n== VLESS over WebSocket + TLS ==');
{
  const link =
    'vless://aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee@1.2.3.4:8443' +
    '?type=ws&security=tls&sni=cdn.example.org&host=cdn.example.org&path=%2Fws%3Fed%3D2048&fp=firefox#WS';
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    const c = r.config;
    eq('network', c.network, 'ws');
    eq('security', c.security, 'tls');
    eq('path decoded', c.path, '/ws?ed=2048');
    eq('host', c.host, 'cdn.example.org');
    eq('fingerprint', c.fingerprint, 'firefox');

    const json = JSON.parse(buildXrayConfig(c));
    eq('ws path', json.outbounds[0].streamSettings.wsSettings.path, '/ws?ed=2048');
    eq('ws Host header', json.outbounds[0].streamSettings.wsSettings.headers.Host, 'cdn.example.org');
    eq('tls serverName', json.outbounds[0].streamSettings.tlsSettings.serverName, 'cdn.example.org');
    // A literal IP must be routed by `ip`, not `domain`.
    eq('routing uses ip', json.routing.rules[0].ip, ['1.2.3.4']);
    check('routing has no domain field', json.routing.rules[0].domain === undefined);
  }
}

console.log('\n== VMess (base64 JSON) ==');
{
  const inner = {
    v: '2',
    ps: 'VM Node',
    add: 'vm.example.net',
    port: '443',
    id: '99999999-8888-7777-6666-555555555555',
    aid: '0',
    net: 'grpc',
    type: 'none',
    host: '',
    path: 'mygrpc',
    tls: 'tls',
    sni: 'vm.example.net',
  };
  const link = `vmess://${Buffer.from(JSON.stringify(inner)).toString('base64')}`;
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    const c = r.config;
    eq('protocol', c.protocol, 'vmess');
    eq('address', c.address, 'vm.example.net');
    eq('port', c.port, 443);
    eq('uuid', c.uuid, '99999999-8888-7777-6666-555555555555');
    eq('network', c.network, 'grpc');
    eq('security', c.security, 'tls');
    eq('grpc serviceName', c.path, 'mygrpc');

    const json = JSON.parse(buildXrayConfig(c));
    eq('grpc serviceName emitted', json.outbounds[0].streamSettings.grpcSettings.serviceName, 'mygrpc');
    eq('vmess alterId', json.outbounds[0].settings.vnext[0].users[0].alterId, 0);
  }
}

console.log('\n== Trojan over gRPC + TLS ==');
{
  const link =
    'trojan://secretpass@trojan.example.com:443?type=grpc&security=tls&sni=trojan.example.com&serviceName=svc#Trojan';
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    const c = r.config;
    eq('protocol', c.protocol, 'trojan');
    eq('password', c.password, 'secretpass');
    eq('network', c.network, 'grpc');
    eq('serviceName', c.path, 'svc');
    const json = JSON.parse(buildXrayConfig(c));
    eq('trojan password', json.outbounds[0].settings.servers[0].password, 'secretpass');
  }
}

console.log('\n== Shadowsocks (SIP002) ==');
{
  const userinfo = Buffer.from('aes-256-gcm:sspassword').toString('base64').replace(/=+$/, '');
  const link = `ss://${userinfo}@ss.example.com:8388#SS`;
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    const c = r.config;
    eq('protocol', c.protocol, 'shadowsocks');
    eq('method', c.method, 'aes-256-gcm');
    eq('password', c.password, 'sspassword');
    eq('port', c.port, 8388);
    const json = JSON.parse(buildXrayConfig(c));
    eq('ss method', json.outbounds[0].settings.servers[0].method, 'aes-256-gcm');
  }
}

console.log('\n== XHTTP transport ==');
{
  const link =
    'vless://11111111-2222-3333-4444-555555555555@x.example.com:443?type=xhttp&security=tls&sni=x.example.com&path=%2Fx&host=x.example.com#X';
  const r = parseLink(link);
  check('parses', r.ok, r.ok ? '' : r.error);
  if (r.ok) {
    eq('network', r.config.network, 'xhttp');
    const json = JSON.parse(buildXrayConfig(r.config));
    eq('xhttp path', json.outbounds[0].streamSettings.xhttpSettings.path, '/x');
  }
}

console.log('\n== Subscription (base64 of many links) ==');
{
  const links = [
    'vless://11111111-2222-3333-4444-555555555555@a.example.com:443?type=tcp&security=tls&sni=a.example.com#A',
    'trojan://pw@b.example.com:443?type=ws&security=tls&sni=b.example.com&path=%2Fb#B',
  ].join('\n');
  const sub = Buffer.from(links).toString('base64');
  const r = parseSubscription(sub);
  eq('two servers', r.configs.length, 2);
  eq('no errors', r.errors.length, 0);
  eq('first protocol', r.configs[0]?.protocol, 'vless');
  eq('second protocol', r.configs[1]?.protocol, 'trojan');
}

console.log('\n== Address override keeps everything else ==');
{
  const r = parseLink(
    'vless://11111111-2222-3333-4444-555555555555@real.example.com:443?type=ws&security=tls&sni=real.example.com&path=%2Fp#N',
  );
  check('parses', r.ok);
  if (r.ok) {
    const over = withAddressOverride(r.config, '9.9.9.9');
    eq('address changed', over.address, '9.9.9.9');
    eq('port kept', over.port, r.config.port);
    eq('sni kept', over.sni, r.config.sni);
    eq('uuid kept', over.uuid, r.config.uuid);
    eq('path kept', over.path, r.config.path);
    eq('id kept', over.id, r.config.id);
  }
}

console.log('\n== Rejections ==');
{
  check('rejects garbage', !parseLink('not a link').ok);
  check('rejects empty', !parseLink('').ok);
  check('rejects vless without uuid', !parseLink('vless://@a.com:443').ok);
  check('rejects bad port', !parseLink('vless://11111111-2222-3333-4444-555555555555@a.com:99999').ok);
}

console.log('\n== Helpers ==');
{
  check('isIpLiteral v4', isIpLiteral('1.2.3.4'));
  check('isIpLiteral v6', isIpLiteral('2001:db8::1'));
  check('isIpLiteral hostname false', !isIpLiteral('example.com'));
  const cfg: ServerConfig = {
    id: 'x',
    name: 'n',
    protocol: 'vless',
    address: 'a.com',
    port: 443,
    uuid: 'u',
    password: '',
    method: '',
    network: 'ws',
    security: 'tls',
    sni: 'a.com',
    host: '',
    path: '/',
    fingerprint: '',
    flow: '',
    publicKey: '',
    shortId: '',
    allowInsecure: false,
    raw: '',
  };
  eq('describeConfig', describeConfig(cfg), 'VLESS · WS · TLS');
}

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed === 0 ? 0 : 1);
