package com.kingvpn.tunnel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import expo.modules.kotlin.activityresult.AppContextActivityResultContract
import expo.modules.kotlin.activityresult.AppContextActivityResultLauncher
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.functions.Coroutine
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.KeyPair
import java.net.InetAddress

/**
 * The real Android VPN tunnel.
 *
 * This module is what makes KING VPN an actual VPN client instead of a connectivity
 * tester. It owns three things the JavaScript layer cannot do on its own:
 *
 *  1. **The system consent dialog.** Android only grants VPN rights through
 *     `VpnService.prepare()`, which returns an Intent the *activity* must launch. That
 *     Intent is the "Connection request" dialog the user sees. We launch it through
 *     Expo's activity-result registry so the answer comes back to JavaScript.
 *  2. **The tunnel itself.** `GoBackend` from `com.wireguard.android:tunnel` creates a
 *     real TUN interface through `android.net.VpnService` and runs the userspace
 *     WireGuard implementation (`libwg-go`) inside it. Traffic genuinely leaves the
 *     phone through the peer endpoint.
 *  3. **Live tunnel state.** Handshake time and byte counters come from the backend, so
 *     the UI can show whether the tunnel is really up rather than assuming it.
 *
 * Nothing here reports success it did not observe: `connectAsync` resolves only after
 * the backend reports the tunnel UP, and every failure is surfaced with its real reason.
 */
class KingVpnTunnelModule : Module() {

  private val context: Context
    get() = appContext.reactContext ?: throw CodedException("React context is not available")

  /** The single tunnel this app manages. WireGuard allows one active tunnel per backend. */
  private val tunnel = KingTunnel()

  private var backend: Backend? = null

  /** Set by `cancelScanAsync` so a running scan stops at the next endpoint. */
  @Volatile
  private var scanCancelled = false

  /** Assigned by the activity-result registry once an Activity is available. */
  private var vpnPermissionLauncher: AppContextActivityResultLauncher<String, Boolean>? = null

  /** Lazily created so a missing native library surfaces as a clean error, not a crash. */
  private fun backend(): Backend {
    backend?.let { return it }
    val created = GoBackend(context)
    backend = created
    return created
  }

  override fun definition() = ModuleDefinition {
    Name("KingVpnTunnel")

    Events("onTunnelStateChange", "onScanProgress")

    /**
     * Register the consent-dialog launcher. `VpnService.prepare()`'s Intent must be
     * started from an Activity, so it goes through Expo's activity-result registry.
     */
    RegisterActivityContracts {
      vpnPermissionLauncher = registerForActivityResult(VpnPermissionContract())
    }

    /** True when Android has already granted this app the VPN permission. */
    AsyncFunction("isPreparedAsync") {
      // null means "already authorized"; a non-null Intent means consent is still needed.
      VpnService.prepare(context) == null
    }

    /**
     * Show the real system VPN consent dialog and resolve with the user's answer.
     * Resolves `true` only when Android actually granted the permission.
     */
    AsyncFunction("requestPermissionAsync") Coroutine { ->
      if (VpnService.prepare(context) == null) {
        return@Coroutine true
      }
      val launcher = vpnPermissionLauncher
        ?: throw CodedException("The VPN consent dialog is not ready yet. Try again in a moment.")
      launcher.launch("")
    }

    /** Generate a WireGuard key pair with the library's constant-time implementation. */
    AsyncFunction("generateKeyPairAsync") {
      val pair = KeyPair()
      mapOf(
        "privateKey" to pair.privateKey.toBase64(),
        "publicKey" to pair.publicKey.toBase64()
      )
    }

    /**
     * Bring the tunnel up.
     *
     * `config` carries the WireGuard parameters (private key, addresses, peer). The call
     * resolves only once the backend reports the tunnel UP; if the permission is missing
     * or the config is rejected, it rejects with the real reason.
     */
    AsyncFunction("connectAsync") Coroutine { config: Map<String, Any?> ->
      if (VpnService.prepare(context) != null) {
        throw VpnPermissionMissingException()
      }
      val wgConfig = buildConfig(config)
      val state = backend().setState(tunnel, Tunnel.State.UP, wgConfig)
      if (state != Tunnel.State.UP) {
        throw TunnelStartException("The tunnel did not come up (state: $state).")
      }
      // Keep the process alive so Android does not reclaim the tunnel in the background.
      try {
        KingVpnForegroundService.start(context)
      } catch (e: Exception) {
        // The tunnel is up; a missing notification must not tear it down.
      }
      sendEvent("onTunnelStateChange", mapOf("state" to "UP"))
      true
    }

    /** Tear the tunnel down. Safe to call when it is already down. */
    AsyncFunction("disconnectAsync") Coroutine { ->
      try {
        backend().setState(tunnel, Tunnel.State.DOWN, null)
      } finally {
        try {
          KingVpnForegroundService.stop(context)
        } catch (e: Exception) {
          // Already stopped.
        }
        sendEvent("onTunnelStateChange", mapOf("state" to "DOWN"))
      }
      true
    }

    /**
     * The tunnel's real state plus traffic counters.
     *
     * `latestHandshakeMs` is the strongest signal that the tunnel is genuinely working:
     * it only becomes non-zero after a successful cryptographic handshake with the peer.
     */
    AsyncFunction("getStatusAsync") {
      val be = backend()
      val state = be.getState(tunnel)
      val stats = try {
        be.getStatistics(tunnel)
      } catch (e: Exception) {
        null
      }
      val peerKey = try {
        stats?.peers()?.firstOrNull()
      } catch (e: Exception) {
        null
      }
      val peerStats = if (peerKey != null) {
        try {
          stats?.peer(peerKey)
        } catch (e: Exception) {
          null
        }
      } else {
        null
      }
      mapOf(
        "state" to state.name,
        "rxBytes" to (peerStats?.rxBytes ?: 0L),
        "txBytes" to (peerStats?.txBytes ?: 0L),
        "latestHandshakeMs" to (peerStats?.latestHandshakeEpochMillis ?: 0L),
        "version" to (try { be.version } catch (e: Exception) { "" })
      )
    }

    /**
     * Measure one endpoint's reachability and round-trip time.
     *
     * A WARP endpoint does not answer HTTPS on a bare IP (the edge needs the right SNI),
     * so an HTTP probe reports a false failure. A TCP connect to the tunnel port measures
     * what actually matters — whether this anycast range is reachable from the current
     * network — and its handshake time is a fair latency figure. Runs off the JS thread.
     */
    AsyncFunction("probeAsync") Coroutine { host: String, port: Int, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        socket = java.net.Socket()
        socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        mapOf(
          "ok" to true,
          "ms" to (System.currentTimeMillis() - started).toInt(),
          "error" to null
        )
      } catch (e: Exception) {
        mapOf(
          "ok" to false,
          "ms" to 0,
          "error" to (e.message ?: e.javaClass.simpleName)
        )
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    /**
     * Measure an endpoint with a real TLS handshake that presents `sni`.
     *
     * This is the probe that proves the *server name* is right, not just the address.
     * A bare anycast IP only completes a TLS handshake when the ClientHello carries the
     * name the edge serves; without it the edge resets the connection. So a successful
     * result here means the address, the port and the SNI all agree — exactly the three
     * values the tunnel config is built from.
     */
    AsyncFunction("probeTlsAsync") Coroutine { host: String, port: Int, sni: String, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        val raw = java.net.Socket()
        socket = raw
        raw.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        raw.soTimeout = timeoutMs
        val factory = javax.net.ssl.SSLContext.getDefault().socketFactory
        val ssl = factory.createSocket(raw, sni, port, true) as javax.net.ssl.SSLSocket
        ssl.sslParameters = ssl.sslParameters.apply {
          // Present the name the edge serves; this is the SNI the tunnel config carries.
          serverNames = listOf(javax.net.ssl.SNIHostName(sni))
          endpointIdentificationAlgorithm = "HTTPS"
        }
        ssl.startHandshake()
        val ms = (System.currentTimeMillis() - started).toInt()
        try {
          ssl.close()
        } catch (_: Exception) {
        }
        mapOf("ok" to true, "ms" to ms, "error" to null)
      } catch (e: Exception) {
        mapOf(
          "ok" to false,
          "ms" to 0,
          "error" to (e.message ?: e.javaClass.simpleName)
        )
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    /**
     * Probe one endpoint with a **real WireGuard handshake**.
     *
     * This is the scanner's probe. It sends a genuine Noise IK initiation over UDP and
     * waits for the peer's response, so a success means the address, the port and the peer
     * key are all correct — the exact triple the tunnel config is built from.
     *
     * A TCP connect (what the previous build used) cannot work here: WireGuard is UDP, so
     * TCP on 2408/500/1701/4500 is closed on every WARP edge and every healthy endpoint
     * was reported as unreachable.
     */
    AsyncFunction("probeWgAsync") Coroutine { host: String, port: Int, privateKey: String, peerPublicKey: String, timeoutMs: Int ->
      val result = WgProbe.probeOne(
        host = host,
        port = port,
        privateKey = decodeKey(privateKey),
        peerPublicKey = decodeKey(peerPublicKey),
        timeoutMs = timeoutMs
      )
      mapOf(
        "ok" to result.ok,
        "ms" to (result.ms ?: 0),
        "error" to result.error,
        "port" to result.port,
        "colo" to result.colo,
        "loc" to result.loc
      )
    }

    /**
     * Probe many endpoints concurrently with real handshakes, streaming each result.
     *
     * `endpoints` is a list of `{ host, port }`. Every result is emitted as an
     * `onScanProgress` event as soon as it lands, so the list fills in live instead of
     * appearing all at once at the end.
     */
    AsyncFunction("probeManyAsync") Coroutine { endpoints: List<Map<String, Any?>>, privateKey: String, peerPublicKey: String, timeoutMs: Int, concurrency: Int, resolveColo: Boolean ->
      scanCancelled = false
      val priv = decodeKey(privateKey)
      val peer = decodeKey(peerPublicKey)
      val list = endpoints.mapNotNull { entry ->
        val h = (entry["host"] as? String)?.trim().orEmpty()
        if (h.isEmpty()) null else h to ((entry["port"] as? Number)?.toInt() ?: 2408)
      }
      val results = WgProbe.probeMany(
        endpoints = list,
        privateKey = priv,
        peerPublicKey = peer,
        timeoutMs = timeoutMs,
        concurrency = concurrency,
        resolveColo = resolveColo,
        onResult = { r ->
          sendEvent(
            "onScanProgress",
            mapOf(
              "host" to r.host,
              "port" to r.port,
              "ok" to r.ok,
              "ms" to (r.ms ?: 0),
              "error" to r.error,
              "colo" to r.colo,
              "loc" to r.loc
            )
          )
        },
        shouldStop = { scanCancelled }
      )
      results.map { r ->
        mapOf(
          "host" to r.host,
          "port" to r.port,
          "ok" to r.ok,
          "ms" to (r.ms ?: 0),
          "error" to r.error,
          "colo" to r.colo,
          "loc" to r.loc
        )
      }
    }

    /** Stop a running scan at the next endpoint. */
    AsyncFunction("cancelScanAsync") {
      scanCancelled = true
      true
    }

    /**
     * Read the Cloudflare data centre an endpoint routes to, through that exact address.
     * Returns `{ colo, loc }`; both are null when the trace could not be read.
     */
    AsyncFunction("resolveColoAsync") Coroutine { host: String, timeoutMs: Int ->
      val (colo, loc) = WgProbe.resolveColo(host, timeoutMs)
      mapOf("colo" to colo, "loc" to loc)
    }

    OnDestroy {
      try {
        backend?.setState(tunnel, Tunnel.State.DOWN, null)
      } catch (_: Exception) {
        // Nothing to do: the process is going away and the system drops the tunnel.
      }
      try {
        KingVpnForegroundService.stop(context)
      } catch (_: Exception) {
        // Already stopped.
      }
    }
  }

  /** Decode a base64 WireGuard key, with a clear error when it is malformed. */
  private fun decodeKey(value: String): ByteArray {
    return try {
      java.util.Base64.getDecoder().decode(value.trim())
    } catch (e: Exception) {
      throw CodedException("A WireGuard key was not valid base64: ${e.message}")
    }
  }

  /**
   * Turn the JavaScript config map into a WireGuard `Config`.
   *
   * Every field is validated by the library, so a malformed key or address produces a
   * precise `BadConfigException` instead of a tunnel that silently fails to pass traffic.
   */
  private fun buildConfig(raw: Map<String, Any?>): Config {
    val privateKey = raw["privateKey"] as? String
      ?: throw CodedException("privateKey is required")
    val peerPublicKey = raw["peerPublicKey"] as? String
      ?: throw CodedException("peerPublicKey is required")
    val endpoint = raw["endpoint"] as? String
      ?: throw CodedException("endpoint is required")

    val addresses = (raw["addresses"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val dns = (raw["dns"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val allowedIps = (raw["allowedIps"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val mtu = (raw["mtu"] as? Number)?.toInt() ?: 1280
    val keepalive = (raw["persistentKeepalive"] as? Number)?.toInt() ?: 25
    // The server name the endpoint was validated against. WireGuard itself is not TLS,
    // so this is not part of the handshake — it is logged so a support report shows the
    // exact address/port/SNI triple the tunnel was built from.
    val sni = (raw["sni"] as? String)?.trim().orEmpty()
    if (sni.isNotEmpty()) {
      android.util.Log.i("KingVpnTunnel", "tunnel endpoint=$endpoint sni=$sni")
    }

    try {
      val ifaceBuilder = Interface.Builder()
        .parsePrivateKey(privateKey)
        .setMtu(mtu)

      for (address in addresses) {
        ifaceBuilder.addAddress(InetNetwork.parse(address))
      }
      for (server in dns) {
        ifaceBuilder.addDnsServer(InetAddress.getByName(server))
      }

      val peerBuilder = Peer.Builder()
        .parsePublicKey(peerPublicKey)
        .parseEndpoint(endpoint)
        .setPersistentKeepalive(keepalive)

      for (allowed in allowedIps) {
        peerBuilder.addAllowedIp(InetNetwork.parse(allowed))
      }

      return Config.Builder()
        .setInterface(ifaceBuilder.build())
        .addPeer(peerBuilder.build())
        .build()
    } catch (e: BadConfigException) {
      throw CodedException("Invalid WireGuard configuration: ${e.message}")
    } catch (e: Exception) {
      throw CodedException("Could not build the tunnel configuration: ${e.message}")
    }
  }
}

/** The tunnel identity the backend tracks. One instance, one name. */
private class KingTunnel : Tunnel {
  override fun getName(): String = "kingvpn"

  override fun onStateChange(newState: Tunnel.State) {
    // The module pushes state to JavaScript from connect/disconnect, where the call
    // context is known; this callback exists because the interface requires it.
  }
}

/**
 * Launches `VpnService.prepare()`'s Intent and reports whether the user allowed it.
 *
 * `Activity.RESULT_OK` is the only outcome that means the permission was granted; a
 * back-press or "Cancel" comes back as `RESULT_CANCELED` and must not be treated as
 * success.
 */
private class VpnPermissionContract : AppContextActivityResultContract<String, Boolean> {

  override fun createIntent(context: Context, input: String): Intent {
    // prepare() is guaranteed non-null here: the caller checks it before launching.
    return VpnService.prepare(context) ?: Intent()
  }

  override fun parseResult(input: String, resultCode: Int, intent: Intent?): Boolean {
    return resultCode == Activity.RESULT_OK
  }
}

class VpnPermissionMissingException :
  CodedException("Android has not granted VPN permission. Accept the system connection request first.")

class TunnelStartException(message: String) : CodedException(message)
