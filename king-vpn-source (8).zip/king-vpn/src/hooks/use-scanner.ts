import { useCallback, useRef, useState } from 'react';

import { scanEndpoints, stopScan, type PingResult, type ScanSummary } from '@/lib/cloudflare';
import type { ScanTarget } from '@/lib/nodes';

export type ScanPhase = 'idle' | 'running' | 'done' | 'cancelled';

export type ScannerState = {
  phase: ScanPhase;
  /** 0..1 */
  progress: number;
  done: number;
  total: number;
  /** Every endpoint measured so far, in completion order. */
  results: PingResult[];
  /** Endpoints that answered, fastest first. */
  reachable: PingResult[];
  summary: ScanSummary | null;
  error: string | null;
  /** Wall-clock duration of the last scan, in ms. */
  durationMs: number | null;
};

const INITIAL: ScannerState = {
  phase: 'idle',
  progress: 0,
  done: 0,
  total: 0,
  results: [],
  reachable: [],
  summary: null,
  error: null,
  durationMs: null,
};

export type ScanRequest = {
  targets: ScanTarget[];
  privateKey: string;
  peerPublicKey: string;
  samples?: number;
  concurrency?: number;
  timeoutMs?: number;
  resolveColo?: boolean;
};

/**
 * Drives a scan and exposes its live state.
 *
 * The scan itself lives in `scanEndpoints`; this hook only owns the React state, the
 * cancel flag and the progress maths, so the screen stays a pure view. Results stream in
 * as each endpoint finishes, which is what makes a 2000-endpoint scan feel alive instead
 * of frozen behind a spinner.
 */
export function useScanner() {
  const [state, setState] = useState<ScannerState>(INITIAL);
  const stopRef = useRef(false);
  const runningRef = useRef(false);

  const start = useCallback(async (request: ScanRequest) => {
    if (runningRef.current) return;
    runningRef.current = true;
    stopRef.current = false;
    setState({ ...INITIAL, phase: 'running', total: request.targets.length });

    try {
      const summary = await scanEndpoints(request.targets, {
        samples: request.samples ?? 1,
        concurrency: request.concurrency ?? 64,
        timeoutMs: request.timeoutMs ?? 3000,
        privateKey: request.privateKey,
        peerPublicKey: request.peerPublicKey,
        resolveColo: request.resolveColo ?? false,
        shouldStop: () => stopRef.current,
        onResult: (result, done, total) => {
          setState((prev) => {
            const results = [...prev.results, result];
            const reachable = results.filter((r) => r.ok).sort((a, b) => a.ms - b.ms);
            return {
              ...prev,
              results,
              reachable,
              done,
              total,
              progress: total > 0 ? done / total : 0,
            };
          });
        },
      });
      setState((prev) => ({
        ...prev,
        phase: summary.cancelled ? 'cancelled' : 'done',
        summary,
        reachable: summary.reachable,
        progress: 1,
        durationMs: summary.durationMs,
      }));
    } catch (e) {
      setState((prev) => ({
        ...prev,
        phase: 'done',
        error: e instanceof Error ? e.message : 'Scan failed',
      }));
    } finally {
      runningRef.current = false;
    }
  }, []);

  const cancel = useCallback(() => {
    stopRef.current = true;
    void stopScan();
  }, []);

  const reset = useCallback(() => {
    if (runningRef.current) return;
    setState(INITIAL);
  }, []);

  return { ...state, start, cancel, reset, running: state.phase === 'running' };
}
