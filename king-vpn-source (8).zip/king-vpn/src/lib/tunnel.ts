/**
 * Typed bridge to the native Android tunnel module (`modules/king-vpn-tunnel`).
 *
 * The native side owns the real `android.net.VpnService`; this file only describes its
 * shape and degrades cleanly on platforms that have no tunnel (web, iOS, Expo Go).
 *
 * `isAvailable` is the single source of truth for "can this build actually create a
 * VPN?". Expo Go and the web preview cannot, because they have no custom native code —
 * so the UI must say so instead of pretending to connect.
 */
import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';

export type TunnelState = 'UP' | 'DOWN' | 'TOGGLE';

export type TunnelStatus = {
  state: TunnelState;
  rxBytes: number;
  txBytes: number;
  /** Epoch millis of the last successful handshake; 0 means none yet. */
  latestHandshakeMs: number;
  version: string;
};

export type WireGuardConfig = {
  privateKey: string;
  peerPublicKey: string;
  /** `host:port` of the peer. */
  endpoint: string;
  /**
   * TLS server name for the peer address.
   *
   * WireGuard itself is not TLS, so this is not part of the tunnel handshake. It is
   * carried here because the same resolved endpoint is used for the TLS reachability
   * probe and for any TLS-based transport, and because the native side logs it so a
   * support report shows which name the address was validated against.
   */
  sni?: string;
  /** Interface addresses, e.g. `172.16.0.2/32`. */
  addresses: string[];
  dns: string[];
  allowedIps: string[];
  mtu?: number;
  persistentKeepalive?: number;
};

/**
 * The result of a real WireGuard handshake probe.
 *
 * `ok` is only true when the peer answered a valid initiation and the reply passed its
 * MAC check — so a success means the address, the port and the peer key are all correct.
 */
export type ProbeResult = {
  ok: boolean;
  ms: number;
  error: string | null;
  /** The port that actually answered, when one did. */
  port?: number;
  /** Cloudflare data centre the endpoint routes to, when it could be read. */
  colo?: string | null;
  /** Country the edge reports for this path, when it could be read. */
  loc?: string | null;
};

export type ScanTarget = { host: string; port: number };

type NativeTunnelModule = {
  isPreparedAsync(): Promise<boolean>;
  requestPermissionAsync(): Promise<boolean>;
  generateKeyPairAsync(): Promise<{ privateKey: string; publicKey: string }>;
  connectAsync(config: WireGuardConfig): Promise<boolean>;
  disconnectAsync(): Promise<boolean>;
  getStatusAsync(): Promise<TunnelStatus>;
  probeWgAsync(
    host: string,
    port: number,
    privateKey: string,
    peerPublicKey: string,
    timeoutMs: number,
  ): Promise<ProbeResult>;
  probeManyAsync(
    endpoints: ScanTarget[],
    privateKey: string,
    peerPublicKey: string,
    timeoutMs: number,
    concurrency: number,
    resolveColo: boolean,
  ): Promise<ProbeResult[]>;
  cancelScanAsync(): Promise<boolean>;
  resolveColoAsync(host: string, timeoutMs: number): Promise<{ colo: string | null; loc: string | null }>;
  addListener(event: string, listener: (payload: unknown) => void): { remove: () => void };
};

const native = requireOptionalNativeModule<NativeTunnelModule>('KingVpnTunnel');

/** True only on an Android build that actually contains the tunnel module. */
export const isAvailable = Platform.OS === 'android' && native != null;

/** Why the tunnel is unavailable, for the UI to explain instead of failing silently. */
export function unavailableReason(): string | null {
  if (isAvailable) return null;
  if (Platform.OS === 'android') {
    return 'This build has no native VPN module. Build a development or release APK (Expo Go cannot create a VPN).';
  }
  return 'The VPN tunnel is Android-only in this build.';
}

function requireModule(): NativeTunnelModule {
  if (!native) {
    throw new Error(unavailableReason() ?? 'The VPN module is not available.');
  }
  return native;
}

/** True when Android has already granted the VPN permission. */
export async function isPrepared(): Promise<boolean> {
  if (!native) return false;
  try {
    return await native.isPreparedAsync();
  } catch {
    return false;
  }
}

/**
 * Show the real system "Connection request" dialog.
 * Resolves true only when the user actually allowed it.
 */
export async function requestVpnPermission(): Promise<boolean> {
  if (!native) return false;
  return native.requestPermissionAsync();
}

export async function generateKeyPair(): Promise<{ privateKey: string; publicKey: string }> {
  return requireModule().generateKeyPairAsync();
}

/** Bring the tunnel up. Resolves only once the backend reports it UP. */
export async function connectTunnel(config: WireGuardConfig): Promise<boolean> {
  return requireModule().connectAsync(config);
}

export async function disconnectTunnel(): Promise<boolean> {
  if (!native) return true;
  return native.disconnectAsync();
}

export async function getTunnelStatus(): Promise<TunnelStatus | null> {
  if (!native) return null;
  try {
    return await native.getStatusAsync();
  } catch {
    return null;
  }
}

/**
 * Probe one endpoint with a **real WireGuard handshake**.
 *
 * This is the scanner's probe, and it is the only one that means anything here. WireGuard
 * is UDP, so a TCP connect to 2408/500/1701/4500 is closed on every WARP edge — the
 * previous build used exactly that and reported healthy endpoints as unreachable.
 *
 * A success here means the peer accepted our key, our MAC and our ciphertext, which is
 * proof the address, the port and the peer key are all correct.
 */
export async function probeEndpoint(
  host: string,
  port: number,
  privateKey: string,
  peerPublicKey: string,
  timeoutMs = 3000,
): Promise<ProbeResult> {
  if (!native) {
    return { ok: false, ms: 0, error: 'The native probe is unavailable in this build.', port };
  }
  try {
    const result = await native.probeWgAsync(host, port, privateKey, peerPublicKey, timeoutMs);
    return { ...result, port };
  } catch (e) {
    return { ok: false, ms: 0, error: e instanceof Error ? e.message : String(e), port };
  }
}

/**
 * Probe many endpoints concurrently with real handshakes.
 *
 * `onProgress` is called for each result as it lands, so the UI can stream results instead
 * of waiting for the whole scan.
 */
export async function probeMany(
  targets: ScanTarget[],
  privateKey: string,
  peerPublicKey: string,
  options: {
    timeoutMs?: number;
    concurrency?: number;
    resolveColo?: boolean;
    onProgress?: (result: ProbeResult & { host: string }) => void;
  } = {},
): Promise<(ProbeResult & { host: string })[]> {
  if (!native) return [];
  const { timeoutMs = 3000, concurrency = 64, resolveColo = false, onProgress } = options;

  let subscription: { remove: () => void } | null = null;
  if (onProgress) {
    subscription = native.addListener('onScanProgress', (payload) => {
      const p = payload as { host?: string; port?: number; ok?: boolean; ms?: number; error?: string | null; colo?: string | null; loc?: string | null };
      if (!p?.host) return;
      onProgress({
        host: p.host,
        ok: Boolean(p.ok),
        ms: p.ms ?? 0,
        error: p.error ?? null,
        port: p.port,
        colo: p.colo ?? null,
        loc: p.loc ?? null,
      });
    });
  }

  try {
    const results = await native.probeManyAsync(
      targets,
      privateKey,
      peerPublicKey,
      timeoutMs,
      concurrency,
      resolveColo,
    );
    return results.map((r, i) => ({ ...r, host: targets[i]?.host ?? '' }));
  } finally {
    subscription?.remove();
  }
}

/** Stop a running scan at the next endpoint. */
export async function cancelScan(): Promise<void> {
  if (!native) return;
  try {
    await native.cancelScanAsync();
  } catch {
    // Nothing running.
  }
}

/** Read the Cloudflare data centre an endpoint routes to, through that exact address. */
export async function resolveColo(host: string, timeoutMs = 4000): Promise<{ colo: string | null; loc: string | null }> {
  if (!native) return { colo: null, loc: null };
  try {
    return await native.resolveColoAsync(host, timeoutMs);
  } catch {
    return { colo: null, loc: null };
  }
}
